module.exports = {
  docs: [
    {
      type: 'doc',
      id: 'index',
      label: 'Docker 介绍',
    },
    {
      type: 'category',
      label: 'Docker 教程',
      collapsible: true,
      collapsed: false,
      items: [
        {
          type: 'doc',
          id: 'tutorials/introduction',
          label: '基础概念',
        },
        {
          type: 'doc',
          id: 'tutorials/architecture',
          label: '架构介绍',
        },
        {
          type: 'category',
          label: '命令参考',
          items: [
            {
              type: 'doc',
              id: 'tutorials/commands/general',
              label: '通用命令',
            },
            {
              type: 'doc',
              id: 'tutorials/commands/images',
              label: '镜像命令',
            },
            {
              type: 'doc',
              id: 'tutorials/commands/containers',
              label: '容器命令',
            },
            {
              type: 'doc',
              id: 'tutorials/commands/networks',
              label: '网络命令',
            },
            {
              type: 'doc',
              id: 'tutorials/commands/volumes',
              label: '存储命令',
            },
            {
              type: 'doc',
              id: 'tutorials/commands/compose',
              label: 'Docker Compose',
            },
          ],
        },
      ],
    },
    {
      type: 'category',
      label: '安装指南',
      collapsible: true,
      collapsed: true,
      items: [
        {
          type: 'doc',
          id: 'installation/index',
          label: '安装概览',
        },
        {
          type: 'category',
          label: 'Linux 安装',
          items: [
            {
              type: 'doc',
              id: 'installation/linux/ubuntu',
              label: 'Ubuntu/Debian',
            },
            {
              type: 'doc',
              id: 'installation/linux/centos',
              label: 'CentOS/RHEL',
            },
            {
              type: 'doc',
              id: 'installation/linux/fedora',
              label: 'Fedora',
            },
            {
              type: 'doc',
              id: 'installation/linux/arch',
              label: 'Arch Linux',
            },
          ],
        },
        {
          type: 'category',
          label: 'Windows 安装',
          items: [
            {
              type: 'doc',
              id: 'installation/windows/desktop',
              label: 'Docker Desktop',
            },
            {
              type: 'doc',
              id: 'installation/windows/wsl2',
              label: 'WSL2 后端',
            },
          ],
        },
        {
          type: 'category',
          label: 'macOS 安装',
          items: [
            {
              type: 'doc',
              id: 'installation/macos/intel',
              label: 'Intel 芯片',
            },
            {
              type: 'doc',
              id: 'installation/macos/apple-silicon',
              label: 'Apple Silicon',
            },
          ],
        },
        {
          type: 'doc',
          id: 'installation/script',
          label: '一键安装脚本',
        },
        {
          type: 'doc',
          id: 'installation/verification',
          label: '安装验证',
        },
        {
          type: 'doc',
          id: 'installation/uninstall',
          label: '卸载 Docker',
        },
      ],
    },
    {
      type: 'category',
      label: '使用指南',
      collapsible: true,
      collapsed: true,
      items: [
        {
          type: 'doc',
          id: 'usage/index',
          label: '使用概览',
        },
        {
          type: 'category',
          label: '镜像管理',
          items: [
            {
              type: 'doc',
              id: 'usage/images/search',
              label: '搜索镜像',
            },
            {
              type: 'doc',
              id: 'usage/images/pull',
              label: '拉取镜像',
            },
            {
              type: 'doc',
              id: 'usage/images/build',
              label: '构建镜像',
            },
            {
              type: 'doc',
              id: 'usage/images/push',
              label: '推送镜像',
            },
            {
              type: 'doc',
              id: 'usage/images/distribute',
              label: '分发镜像',
            },
          ],
        },
        {
          type: 'category',
          label: '容器操作',
          items: [
            {
              type: 'doc',
              id: 'usage/containers/run',
              label: '运行容器',
            },
            {
              type: 'doc',
              id: 'usage/containers/manage',
              label: '管理容器',
            },
            {
              type: 'doc',
              id: 'usage/containers/logs',
              label: '日志管理',
            },
            {
              type: 'doc',
              id: 'usage/containers/inspect',
              label: '容器检查',
            },
            {
              type: 'doc',
              id: 'usage/containers/resource',
              label: '资源限制',
            },
          ],
        },
        {
          type: 'category',
          label: '网络配置',
          items: [
            {
              type: 'doc',
              id: 'usage/networks/overview',
              label: '网络概述',
            },
            {
              type: 'doc',
              id: 'usage/networks/bridge',
              label: '桥接网络',
            },
            {
              type: 'doc',
              id: 'usage/networks/host',
              label: '主机网络',
            },
            {
              type: 'doc',
              id: 'usage/networks/overlay',
              label: '覆盖网络',
            },
            {
              type: 'doc',
              id: 'usage/networks/macvlan',
              label: 'MACVLAN',
            },
          ],
        },
        {
          type: 'category',
          label: '存储解决方案',
          items: [
            {
              type: 'doc',
              id: 'usage/storage/volumes',
              label: '数据卷',
            },
            {
              type: 'doc',
              id: 'usage/storage/bind-mounts',
              label: '绑定挂载',
            },
            {
              type: 'doc',
              id: 'usage/storage/tmpfs',
              label: '临时文件系统',
            },
            {
              type: 'doc',
              id: 'usage/storage/backup',
              label: '备份与恢复',
            },
          ],
        },
      ],
    },
    {
      type: 'category',
      label: '实战案例',
      collapsible: true,
      collapsed: true,
      items: [
        {
          type: 'doc',
          id: 'cases/index',
          label: '案例概览',
        },
        {
          type: 'category',
          label: 'Web 应用部署',
          items: [
            {
              type: 'doc',
              id: 'cases/web/nginx',
              label: 'Nginx',
            },
            {
              type: 'doc',
              id: 'cases/web/apache',
              label: 'Apache',
            },
            {
              type: 'doc',
              id: 'cases/web/nodejs',
              label: 'Node.js',
            },
            {
              type: 'doc',
              id: 'cases/web/python',
              label: 'Python Flask/Django',
            },
          ],
        },
        {
          type: 'category',
          label: '数据库应用',
          items: [
            {
              type: 'doc',
              id: 'cases/database/mysql',
              label: 'MySQL',
            },
            {
              type: 'doc',
              id: 'cases/database/postgresql',
              label: 'PostgreSQL',
            },
            {
              type: 'doc',
              id: 'cases/database/mongodb',
              label: 'MongoDB',
            },
            {
              type: 'doc',
              id: 'cases/database/redis',
              label: 'Redis',
            },
          ],
        },
        {
          type: 'category',
          label: '微服务架构',
          items: [
            {
              type: 'doc',
              id: 'cases/microservices/intro',
              label: '架构设计',
            },
            {
              type: 'doc',
              id: 'cases/microservices/frontend',
              label: '前端服务',
            },
            {
              type: 'doc',
              id: 'cases/microservices/backend',
              label: '后端服务',
            },
            {
              type: 'doc',
              id: 'cases/microservices/database',
              label: '数据库服务',
            },
            {
              type: 'doc',
              id: 'cases/microservices/gateway',
              label: 'API 网关',
            },
            {
              type: 'doc',
              id: 'cases/microservices/compose',
              label: 'Docker Compose 部署',
            },
          ],
        },
      ],
    },
    {
      type: 'category',
      label: '镜像源配置',
      collapsible: true,
      collapsed: true,
      items: [
        {
          type: 'doc',
          id: 'mirror/index',
          label: '镜像源概览',
        },
        {
          type: 'doc',
          id: 'mirror/docker-hub',
          label: 'Docker Hub',
        },
        {
          type: 'doc',
          id: 'mirror/npm',
          label: 'npm 镜像',
        },
        {
          type: 'doc',
          id: 'mirror/pip',
          label: 'pip 镜像',
        },
        {
          type: 'doc',
          id: 'mirror/homebrew',
          label: 'Homebrew 镜像',
        },
        {
          type: 'doc',
          id: 'mirror/yum',
          label: 'YUM 镜像',
        },
        {
          type: 'doc',
          id: 'mirror/apt',
          label: 'APT 镜像',
          },
      ],
    },
    {
      type: 'category',
      label: '帮助中心',
      collapsible: true,
      collapsed: true,
      items: [
        {
          type: 'doc',
          id: 'help/index',
          label: '帮助概览',
        },
        {
          type: 'doc',
          id: 'help/faq',
          label: '常见问题',
        },
        {
          type: 'doc',
          id: 'help/troubleshooting',
          label: '故障排除',
        },
        {
          type: 'doc',
          id: 'help/performance',
          label: '性能优化',
        },
        {
          type: 'doc',
          id: 'help/security',
          label: '安全最佳实践',
        },
        {
          type: 'doc',
          id: 'help/resources',
          label: '学习资源',
        },
      ],
    },
  ],
};