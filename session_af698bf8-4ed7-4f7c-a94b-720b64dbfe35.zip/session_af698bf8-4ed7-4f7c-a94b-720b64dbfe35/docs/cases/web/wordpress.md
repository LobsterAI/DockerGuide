---
id: wordpress
title: WordPress + MySQL 动态网站
sidebar_label: WordPress 动态网站
description: 使用 Docker Compose 部署 WordPress 动态网站，包括 MySQL 数据库、SSL 配置和备份策略
---

# WordPress + MySQL 动态网站

## 场景描述

本案例演示如何使用 Docker Compose 部署完整的 WordPress 网站，包括 Web 服务器、PHP 处理器和 MySQL 数据库。

### 应用场景

- 🌐 部署个人博客或企业网站
- 📊 内容管理系统（CMS）
- 🔧 电子商务网站（WooCommerce）
- 🎨 主题和插件开发测试
- 📱 多站点网络配置

### 学习目标

通过本案例，你将学会：

- 使用 Docker Compose 编排多容器应用
- 配置 WordPress 和 MySQL 连接
- 设置数据持久化和备份
- 配置 SSL 证书实现 HTTPS
- 实现网站性能优化
- 部署和管理 WordPress 插件

## 系统架构

### 架构图

```
                    Internet
                        |
                        v
                   [ Nginx Container ]
                   |   Port 80/443   |
                   +--------------------+
                   |   Nginx Web Server |
                   +--------------------+
                        |   Proxy to
                        v
                [ WordPress Container ]
                |   Port 8080       |
                +--------------------+
                | PHP + WordPress     |
                +--------------------+
                        |
                        v
                [ MySQL Container ]
                |   Port 3306       |
                +--------------------+
                |   MySQL Database    |
                +--------------------+
                        |
                [ Data Volume ]
```

### 组件说明

- **Nginx**: 反向代理和静态文件服务
- **WordPress**: PHP 应用程序，提供 CMS 功能
- **MySQL**: 关系型数据库，存储内容和配置
- **数据卷**: 持久化数据库和文件

## Dockerfile

### WordPress Dockerfile

```dockerfile title="Dockerfile.wordpress"
FROM wordpress:latest

# 安装必要的 PHP 扩展
RUN docker-php-ext-install mysqli \
    && docker-php-ext-enable mysqli

# 安装 wp-cli（WordPress 命令行工具）
RUN curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar \
    && chmod +x wp-cli.phar \
    && mv wp-cli.phar /usr/local/bin/wp

# 创建 WordPress 上传目录
RUN mkdir -p /var/www/html/wp-content/uploads \
    && chown -R www-data:www-data /var/www/html

# 设置工作目录
WORKDIR /var/www/html

# 暴露端口
EXPOSE 80

# 启动 PHP-FPM
CMD ["php-fpm"]
```

### Nginx Dockerfile

```dockerfile title="Dockerfile.nginx"
FROM nginx:alpine

# 安装必要的工具
RUN apk add --no-cache curl

# 复制 Nginx 配置
COPY nginx.conf /etc/nginx/nginx.conf
COPY wordpress.conf /etc/nginx/conf.d/wordpress.conf

# 创建日志目录
RUN mkdir -p /var/log/nginx

# 暴露端口
EXPOSE 80 443

# 启动 Nginx
CMD ["nginx", "-g", "daemon off;"]
```

## 配置文件

### docker-compose.yml

```yaml title="docker-compose.yml"
version: '3.8'

services:
  # MySQL 数据库
  db:
    image: mysql:8.0
    container_name: wordpress-db
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD:-wordpress}
      MYSQL_DATABASE: ${MYSQL_DATABASE:-wordpress}
      MYSQL_USER: ${MYSQL_USER:-wordpress}
      MYSQL_PASSWORD: ${MYSQL_PASSWORD:-wordpress}
    volumes:
      - db_data:/var/lib/mysql
      - ./backups:/var/backups
    networks:
      - wordpress-net
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
      timeout: 20s
      retries: 10

  # WordPress 应用
  wordpress:
    depends_on:
      db:
        condition: service_healthy
    image: wordpress:latest
    container_name: wordpress-app
    restart: unless-stopped
    ports:
      - "8080:80"
    environment:
      WORDPRESS_DB_HOST: db:3306
      WORDPRESS_DB_USER: ${MYSQL_USER:-wordpress}
      WORDPRESS_DB_PASSWORD: ${MYSQL_PASSWORD:-wordpress}
      WORDPRESS_DB_NAME: ${MYSQL_DATABASE:-wordpress}
      WORDPRESS_TABLE_PREFIX: ${WP_TABLE_PREFIX:-wp_}
      WORDPRESS_DEBUG: ${WP_DEBUG:-false}
    volumes:
      - wordpress_data:/var/www/html
    networks:
      - wordpress-net

  # Nginx 反向代理
  nginx:
    depends_on:
      - wordpress
    image: nginx:alpine
    container_name: wordpress-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/wordpress.conf:/etc/nginx/conf.d/wordpress.conf:ro
      - wordpress_data:/var/www/html:ro
      - ./ssl:/etc/nginx/ssl:ro
      - ./logs/nginx:/var/log/nginx
    networks:
      - wordpress-net

  # phpMyAdmin（可选）
  phpmyadmin:
    depends_on:
      - db
    image: phpmyadmin:latest
    container_name: wordpress-phpmyadmin
    restart: unless-stopped
    ports:
      - "8081:80"
    environment:
      PMA_HOST: db
      PMA_PORT: 3306
      UPLOAD_LIMIT: 100M
    networks:
      - wordpress-net

networks:
  wordpress-net:
    driver: bridge

volumes:
  db_data:
    driver: local
  wordpress_data:
    driver: local
```

### Nginx 配置

```nginx title="nginx.conf"
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    access_log /var/log/nginx/access.log main;
    sendfile on;
    tcp_nopush on;
    keepalive_timeout 65;
    include /etc/nginx/conf.d/*.conf;
}
```

### WordPress 配置

```nginx title="wordpress.conf"
# HTTP to HTTPS redirect
server {
    listen 80;
    server_name ${DOMAIN_NAME} www.${DOMAIN_NAME};
    return 301 https://$server_name$request_uri;
}

# HTTPS Server
server {
    listen 443 ssl http2;
    server_name ${DOMAIN_NAME} www.${DOMAIN_NAME};

    # SSL 配置
    ssl_certificate /etc/nginx/ssl/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # 上传文件大小限制
    client_max_body_size 100M;

    # WordPress 配置
    root /var/www/html;
    index index.php index.html index.htm;

    location / {
        try_files $uri $uri/ /index.php?$args;
    }

    location ~ \.php$ {
        fastcgi_pass wordpress:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # 静态文件缓存
    location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # 禁止访问隐藏文件
    location ~ /\. {
        deny all;
    }
}
```

## 部署步骤

### 1. 准备环境变量

```bash
# 创建 .env 文件
cat > .env << 'EOF'
MYSQL_ROOT_PASSWORD=your_secure_root_password
MYSQL_DATABASE=wordpress
MYSQL_USER=wordpress
MYSQL_PASSWORD=your_secure_password
WP_TABLE_PREFIX=wp_
WP_DEBUG=false
DOMAIN_NAME=your-domain.com
