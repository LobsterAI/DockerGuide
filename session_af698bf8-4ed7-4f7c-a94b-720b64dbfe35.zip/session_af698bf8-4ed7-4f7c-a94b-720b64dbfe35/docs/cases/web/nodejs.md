---
id: nodejs
title: 使用 Node.js 部署 Express 应用
sidebar_label: Node.js 应用
description: 使用 Docker 容器化部署 Node.js Express 应用，包括多阶段构建、进程管理和性能优化
---

# 使用 Node.js 部署 Express 应用

## 场景描述

本案例演示如何使用 Docker 容器化部署 Node.js Express 应用，涵盖开发、测试和生产环境的最佳实践。

### 应用场景

- 🌐 部署 RESTful API 服务
- 🚀 部署全栈 Web 应用
- 🔧 部署 GraphQL 服务器
- 📡 部署 WebSocket 服务器
- 🔄 部署微服务架构
- 📊 部署实时数据处理服务

### 学习目标

通过本案例，你将学会：

- Node.js 应用的多阶段构建
- 使用 PM2 进行进程管理
- 优化 Node.js 应用性能
- 配置环境变量和配置管理
- 实现健康检查和优雅关闭
- 设置日志管理和监控

## Dockerfile

### 基础 Node.js Dockerfile

```dockerfile title="Dockerfile.basic"
# 使用官方 Node.js 镜像
FROM node:18-alpine

# 设置工作目录
WORKDIR /app

# 复制 package 文件
COPY package*.json ./

# 安装依赖
RUN npm ci --only=production

# 复制应用代码
COPY . .

# 暴露端口
EXPOSE 3000

# 设置环境变量
ENV NODE_ENV=production
ENV PORT=3000

# 使用非 root 用户
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001
RUN chown -R nodejs:nodejs /app
USER nodejs

# 启动应用
CMD ["node", "app.js"]
```

### 多阶段构建 Dockerfile

```dockerfile title="Dockerfile.multi-stage"
# 构建阶段
FROM node:18-alpine AS builder

WORKDIR /app

# 复制 package 文件
COPY package*.json ./

# 安装所有依赖（包括开发依赖）
RUN npm ci

# 复制源代码
COPY . .

# 构建应用（如果需要）
# RUN npm run build

# 生产阶段
FROM node:18-alpine

WORKDIR /app

# 从构建阶段复制依赖
COPY --from=builder /app/node_modules ./node_modules

# 复制应用代码
COPY --from=builder /app/package*.json ./
COPY --from=builder /app/ ./

# 创建非 root 用户
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001
RUN chown -R nodejs:nodejs /app

# 切换到非 root 用户
USER nodejs

# 暴露端口
EXPOSE 3000

# 设置环境变量
ENV NODE_ENV=production
ENV PORT=3000

# 健康检查
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD node healthcheck.js || exit 1

# 启动应用
CMD ["node", "app.js"]
```

### PM2 Dockerfile

```dockerfile title="Dockerfile.pm2"
FROM node:18-alpine

WORKDIR /app

# 复制 package 文件
COPY package*.json ./

# 安装依赖和 PM2
RUN npm ci && npm install -g pm2

# 复制应用代码
COPY . .

# 创建非 root 用户
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001
RUN chown -R nodejs:nodejs /app

# 切换到非 root 用户
USER nodejs

# 暴露端口
EXPOSE 3000

# 设置环境变量
ENV NODE_ENV=production
ENV PORT=3000

# PM2 配置文件
COPY ecosystem.config.js ./

# 使用 PM2 启动应用
CMD ["pm2-runtime", "start", "ecosystem.config.js"]
```

## 配置文件

### Express 应用示例

```javascript title="app.js"
const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');

const app = express();
const PORT = process.env.PORT || 3000;

// 安全中间件
app.use(helmet());

// 压缩中间件
app.use(compression());

// 日志中间件
app.use(morgan('combined'));

// JSON 解析
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 路由
app.get('/', (req, res) => {
  res.json({
    message: 'Hello from Docker!',
    version: process.env.npm_package_version
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date() });
});

// 错误处理
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something broke!' });
});

// 启动服务器
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// 优雅关闭
const gracefulShutdown = () => {
  console.log('Received shutdown signal');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

module.exports = app;
```

### 健康检查脚本

```javascript title="healthcheck.js"
const http = require('http');

const options = {
  hostname: 'localhost',
  port: process.env.PORT || 3000,
  path: '/health',
  method: 'GET',
  timeout: 2000
};

const request = http.request(options, (res) => {
  if (res.statusCode === 200) {
    process.exit(0);
  } else {
    process.exit(1);
  }
});

request.on('error', () => {
  process.exit(1);
});

request.end();
```

### PM2 配置文件

```javascript title="ecosystem.config.js"
module.exports = {
  apps: [{
    name: 'nodejs-app',
    script: 'app.js',
    instances: 'max',
    exec_mode: 'cluster',
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/var/log/nodejs-app/error.log',
    out_file: '/var/log/nodejs-app/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true
  }]
};
```

## Docker Compose 配置

### 基础 docker-compose.yml

```yaml title="docker-compose.yml"
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: nodejs-app
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PORT=3000
    restart: unless-stopped
    networks:
      - appnet
    healthcheck:
      test: ["CMD", "node", "healthcheck.js"]
      interval: 30s
      timeout: 3s
      retries: 3
      start_period: 10s

networks:
  appnet:
    driver: bridge
```

### 生产环境 docker-compose.yml

```yaml title="docker-compose.prod.yml"
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      target: production
    container_name: nodejs-prod
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PORT=3000
    env_file:
      - .env.prod
    restart: unless-stopped
    networks:
      - appnet
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s

networks:
  appnet:
    driver: bridge
    ipam:
      config:
        - subnet: 172.28.0.0/16
```

### 开发环境 docker-compose.yml

```yaml title="docker-compose.dev.yml"
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: nodejs-dev
    ports:
      - "3000:3000"
      - "9229:9229"  # Node.js 调试端口
    volumes:
      # 热重载：挂载源代码
      - .:/app
      - /app/node_modules  # 防止覆盖 node_modules
    environment:
      - NODE_ENV=development
      - PORT=3000
    command: npm run dev
    restart: unless-stopped

  # Redis 缓存（开发环境）
  redis:
    image: redis:alpine
    container_name: nodejs-redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped

  # MongoDB（开发环境）
  mongodb:
    image: mongo:latest
    container_name: nodejs-mongo
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db
    environment:
      - MONGO_INITDB_DATABASE=devdb
    restart: unless-stopped

networks:
  appnet:
    driver: bridge

volumes:
  redis_data:
  mongo_data:
```

## 部署步骤

### 1. 准备项目

```bash
# 创建项目目录
mkdir nodejs-docker && cd nodejs-docker

# 初始化项目
npm init -y

# 安装依赖
npm install express helmet morgan compression

# 创建应用文件
cat > app.js << 'EOF'
const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.json({ message: 'Hello from Docker!' });
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
