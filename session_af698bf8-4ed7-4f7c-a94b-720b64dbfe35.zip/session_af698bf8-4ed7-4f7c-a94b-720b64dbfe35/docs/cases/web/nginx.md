---
id: nginx
title: 使用 Nginx 部署静态网站
sidebar_label: Nginx 静态网站
description: 使用 Docker 容器化部署 Nginx 静态网站，包括反向代理配置、SSL 证书部署和性能优化
---

# 使用 Nginx 部署静态网站

## 场景描述

本案例演示如何使用 Docker 容器化部署 Nginx 静态网站。Nginx 是一个高性能的 HTTP 和反向代理服务器，特别适合部署静态网站、作为 API 网关或负载均衡器。

### 应用场景

- 🌐 部署个人或企业静态网站
- 🔒 配置 HTTPS 加密访问
- 🚀 使用 Nginx 作为反向代理
- ⚡ 高性能静态文件服务
- 📊 简单的负载均衡配置
- 🎨 SPA（单页应用）部署

### 学习目标

通过本案例，你将学会：

- 使用官方 Nginx 镜像部署网站
- 配置 Nginx 作为反向代理
- 设置 SSL/TLS 证书
- 优化 Nginx 性能
- 实现基本的负载均衡
- 配置日志和监控

## 系统架构

### 架构图

```
                    Internet
                        |
                        v
                   [ Nginx Container ]
                   |    Port 80/443 |
                   +------------------+
                   |   Nginx Server  |
                   |  (Static Files) |
                   +------------------+
                        |    |
           +------------+    +------------+
           |                             |
    [ HTML Files ]              [ CSS/JS Assets ]
```

### 组件说明

- **Nginx 容器**: 提供静态文件服务
- **配置文件**: Nginx 配置卷挂载
- **静态文件**: 网站内容卷挂载
- **SSL 证书**: HTTPS 加密证书（可选）

## Dockerfile

### 基础 Nginx Dockerfile

创建 `Dockerfile` 文件：

```dockerfile title="Dockerfile"
# 使用官方 Nginx 镜像
FROM nginx:alpine

# 删除默认的 Nginx 配置和网站
RUN rm /etc/nginx/conf.d/default.conf \
    && rm -rf /usr/share/nginx/html/*

# 复制自定义配置
COPY nginx.conf /etc/nginx/nginx.conf
COPY site.conf /etc/nginx/conf.d/

# 复制网站文件
COPY . /usr/share/nginx/html/

# 暴露端口
EXPOSE 80 443

# 使用 Nginx 信号处理器
STOPSIGNAL SIGTERM

# 启动 Nginx
CMD ["nginx", "-g", "daemon off;"]
```

### 多阶段构建 Dockerfile

对于需要构建前端应用的情况：

```dockerfile title="Dockerfile.multi-stage"
# 构建阶段
FROM node:18-alpine AS builder

WORKDIR /app

# 复制 package 文件
COPY package*.json ./

# 安装依赖
RUN npm ci

# 复制源代码
COPY . .

# 构建应用
RUN npm run build

# 生产阶段
FROM nginx:alpine

# 复制自定义 Nginx 配置
COPY nginx.conf /etc/nginx/nginx.conf
COPY site.conf /etc/nginx/conf.d/

# 从构建阶段复制构建产物
COPY --from=builder /app/dist /usr/share/nginx/html

# 暴露端口
EXPOSE 80 443

# 启动 Nginx
CMD ["nginx", "-g", "daemon off;"]
```

## 配置文件

### Nginx 主配置文件

创建 `nginx.conf` 文件：

```nginx title="nginx.conf"
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # 日志格式
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    # 性能优化
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 20M;

    # Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript 
               application/json application/javascript application/xml+rss 
               application/rss+xml font/truetype font/opentype 
               application/vnd.ms-fontobject image/svg+xml;

    # 包含站点配置
    include /etc/nginx/conf.d/*.conf;
}
```

### 站点配置文件

创建 `site.conf` 文件：

```nginx title="site.conf"
server {
    listen 80;
    server_name example.com www.example.com;
    
    # 网站根目录
    root /usr/share/nginx/html;
    index index.html index.htm;
    
    # 字符集
    charset utf-8;
    
    # 日志配置
    access_log /var/log/nginx/example.com.access.log main;
    error_log /var/log/nginx/example.com.error.log warn;
    
    # 静态资源缓存
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    # SPA 路由支持
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # 安全头
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # 禁止访问隐藏文件
    location ~ /\. {
        deny all;
    }
}
```

## Docker Compose 配置

### 基础 docker-compose.yml

```yaml title="docker-compose.yml"
version: '3.8'

services:
  nginx:
    image: nginx:alpine
    container_name: nginx-web
    ports:
      - "80:80"
      - "443:443"
    volumes:
      # 网站文件
      - ./html:/usr/share/nginx/html
      # Nginx 配置
      - ./conf/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./conf/site.conf:/etc/nginx/conf.d/site.conf:ro
      # SSL 证书（可选）
      - ./ssl:/etc/nginx/ssl:ro
      # 日志目录
      - ./logs:/var/log/nginx
    restart: unless-stopped
    networks:
      - webnet
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

networks:
  webnet:
    driver: bridge
```

## 部署步骤

### 1. 准备项目结构

```bash
# 创建项目目录
mkdir nginx-docker && cd nginx-docker

# 创建必要的目录
mkdir -p html conf ssl logs

# 创建示例 HTML 文件
cat > html/index.html << 'EOF'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Docker Nginx Site</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #3498db;
        }
    </style>
</head>
<body>
    <h1>Welcome to Docker Nginx!</h1>
    <p>This site is running in a Docker container.</p>
</body>
</html>
