---
id: local-env
title: 使用 Docker 搭建本地开发环境
sidebar_label: 本地开发环境
description: 使用 Docker 容器化构建一致的本地开发环境，包括多服务编排、数据持久化和开发工具配置
---

# 使用 Docker 搭建本地开发环境

## 场景描述

本案例演示如何使用 Docker 搭建一致且高效的本地开发环境，支持前端、后端、数据库和缓存服务的容器化开发。

### 应用场景

- 💻 Web 全栈开发
- 🔧 微服务开发调试
- 📦 多技术栈并行开发
- 🔄 团队协作环境统一
- 🚀 快速环境搭建和切换

### 学习目标

通过本案例，你将学会：

- 构建多容器开发环境
- 配置服务间通信
- 实现数据持久化和备份
- 配置代码热重载
- 集成开发调试工具
- 优化开发工作流程

## 系统架构

### 开发环境架构

```
    开发者主机
         |
         | 代码编辑器
         |  Git 客户端
         |  终端/Docker CLI
         |
         v
    Docker Daemon
         |
    +----+----+----+----+
    |    |    |    |    |
 [Front] [Backend] [DB] [Cache]
    |    |    |    |    |
    +----+----+----+----+
         |
         v
    [ 开发网络 ]
```

### 组件说明

- **前端容器**: React/Vue/Angular 开发服务器
- **后端容器**: Node.js/Python/Java API 服务
- **数据库容器**: MySQL/PostgreSQL 数据库
- **缓存容器**: Redis/Memcached 缓存
- **工具容器**: 数据库管理、监控等
- **开发网络**: 容器间通信网络

## 项目结构

```
dev-env/
├── docker-compose.yml       # 主编排文件
├── docker-compose.dev.yml   # 开发环境配置
├── .env                    # 环境变量
├── .gitignore
├── frontend/              # 前端项目
│   ├── Dockerfile
│   ├── package.json
│   └── src/
├── backend/               # 后端项目
│   ├── Dockerfile
│   ├── package.json
│   └── src/
├── database/              # 数据库配置
│   ├── init/
│   └── my.cnf
└── scripts/               # 辅助脚本
    ├── setup.sh
    ├── backup.sh
    └── clean.sh
```

## Docker Compose 配置

### 开发环境 docker-compose.yml

```yaml title="docker-compose.yml"
version: '3.8'

services:
  # 前端开发服务器
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.dev
    container_name: frontend-dev
    ports:
      - "3000:3000"
      - "9229:9229"  # 调试端口
    volumes:
      # 代码热重载
      - ./frontend:/app:cached
      - /app/node_modules  # 防止覆盖
    environment:
      - NODE_ENV=development
      - CHOKIDAR_USEPOLLING=true
      - API_URL=http://backend:8000
    command: npm run dev
    networks:
      - dev-net
    stdin_open: true
    tty: true

  # 后端 API 服务
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile.dev
    container_name: backend-dev
    ports:
      - "8000:8000"
      - "9230:9230"  # 调试端口
    volumes:
      # 代码热重载
      - ./backend:/app:cached
      - /app/node_modules
    environment:
      - NODE_ENV=development
      - DATABASE_URL=mysql://${DB_USER}:${DB_PASSWORD}@db:3306/${DB_NAME}
      - REDIS_URL=redis://redis:6379
      - JWT_SECRET=${JWT_SECRET}
    command: npm run dev
    networks:
      - dev-net
    depends_on:
      - db
      - redis
    stdin_open: true
    tty: true

  # MySQL 数据库
  db:
    image: mysql:8.0
    container_name: mysql-dev
    ports:
      - "3306:3306"
    environment:
      - MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD}
      - MYSQL_DATABASE=${DB_NAME}
      - MYSQL_USER=${DB_USER}
      - MYSQL_PASSWORD=${DB_PASSWORD}
      - TZ=Asia/Shanghai
    volumes:
      - mysql_data:/var/lib/mysql
      - ./database/init:/docker-entrypoint-initdb.d:ro
      - ./database/my.cnf:/etc/mysql/conf.d/custom.cnf:ro
    networks:
      - dev-net
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Redis 缓存
  redis:
    image: redis:alpine
    container_name: redis-dev
    ports:
      - "6379:6379"
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
      - ./database/redis.conf:/usr/local/etc/redis/redis.conf:ro
    networks:
      - dev-net
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  # phpMyAdmin（数据库管理）
  phpmyadmin:
    image: phpmyadmin:latest
    container_name: phpmyadmin-dev
    ports:
      - "8080:80"
    environment:
      - PMA_HOST=db
      - PMA_PORT=3306
      - PMA_USER=${DB_USER}
      - PMA_PASSWORD=${DB_PASSWORD}
      - UPLOAD_LIMIT=100M
    networks:
      - dev-net
    depends_on:
      - db

  # Redis Commander（Redis 管理）
  redis-commander:
    image: rediscommander/redis-commander:latest
    container_name: redis-commander-dev
    ports:
      - "8081:8081"
    environment:
      - REDIS_HOSTS=local:redis:6379
    networks:
      - dev-net
    depends_on:
      - redis

networks:
  dev-net:
    driver: bridge
    ipam:
      config:
        - subnet: 172.28.0.0/16

volumes:
  mysql_data:
    driver: local
  redis_data:
    driver: local
```

### .env 文件

```bash title=".env"
# MySQL 配置
MYSQL_ROOT_PASSWORD=rootdev
DB_NAME=devdb
DB_USER=devuser
DB_PASSWORD=devpass

# Redis 配置
REDIS_PASSWORD=

# 应用配置
NODE_ENV=development
API_URL=http://localhost:8000
FRONTEND_URL=http://localhost:3000

# 认证配置
JWT_SECRET=dev_secret_key_change_in_production
JWT_EXPIRATION=7d

# 端口配置
FRONTEND_PORT=3000
BACKEND_PORT=8000
DB_PORT=3306
REDIS_PORT=6379
```

## Dockerfile

### 前端 Dockerfile.dev

```dockerfile title="frontend/Dockerfile.dev"
FROM node:18-alpine

WORKDIR /app

# 安装依赖
COPY package*.json ./
RUN npm ci

# 暴露端口
EXPOSE 3000 9229

# 安装开发工具
RUN npm install -g nodemon

# 开发服务器
CMD ["npm", "run", "dev"]
```

### 后端 Dockerfile.dev

```dockerfile title="backend/Dockerfile.dev"
FROM node:18-alpine

WORKDIR /app

# 安装依赖
COPY package*.json ./
RUN npm ci

# 暴露端口
EXPOSE 8000 9230

# 开发服务器
CMD ["npm", "run", "dev"]
```

## 部署步骤

### 1. 初始化项目

```bash
# 创建项目目录
mkdir dev-env && cd dev-env

# 初始化 Git
git init

# 创建项目结构
mkdir -p frontend backend database/init scripts
```

### 2. 创建配置文件

```bash
# 创建 .env 文件
cat > .env << 'EOF'
MYSQL_ROOT_PASSWORD=rootdev
DB_NAME=devdb
DB_USER=devuser
DB_PASSWORD=devpass
NODE_ENV=development
JWT_SECRET=dev_secret_key
