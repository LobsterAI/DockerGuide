---
id: redis
title: Redis 缓存容器化
sidebar_label: Redis 缓存
description: 使用 Docker 容器化部署 Redis 缓存，包括持久化配置、集群搭建和性能优化
---

# Redis 缓存容器化

## 场景描述

本案例演示如何使用 Docker 容器化部署 Redis 内存数据库，涵盖单机部署、主从复制、哨兵模式和集群配置。

### 应用场景

- 🚀 应用缓存层
- 📊 会话存储
- 🔍 消息队列
- 📈 计数器和排行榜
- 💾 发布订阅系统
- 🔄 分布式锁

### 学习目标

通过本案例，你将学会：

- 部署和配置 Redis 容器
- 实现数据持久化
- 配置主从复制架构
- 搭建哨兵高可用方案
- 优化 Redis 性能
- 管理 Redis 集群

## 系统架构

### 单机架构

```
        Application
              |
              v
      [ Redis Container ]
      |    Port 6379     |
      +-------------------+
      |   Redis Server     |
      +-------------------+
              |
      [ Data Volume ]
```

### 主从复制架构

```
        Application
              |
      +------+------+
      |             |
      v             v
   [ Master ]    [ Slave ]
      |             |
      +------+------+------+
              |
      [ Data Volume ]
```

## Docker Compose 配置

### 基础配置

```yaml title="docker-compose.yml"
version: '3.8'

services:
  redis:
    image: redis:7-alpine
    container_name: redis-server
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
      - ./redis.conf:/usr/local/etc/redis/redis.conf:ro
    command: redis-server /usr/local/etc/redis/redis.conf
    restart: unless-stopped
    networks:
      - redis-net
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 3s
      retries: 3

  redis-commander:
    image: rediscommander/redis-commander:latest
    container_name: redis-commander
    ports:
      - "8081:8081"
    environment:
      - REDIS_HOSTS=local:redis:6379
    networks:
      - redis-net
    depends_on:
      - redis

networks:
  redis-net:
    driver: bridge

volumes:
  redis_data:
    driver: local
```

### 主从复制配置

```yaml title="docker-compose.replication.yml"
version: '3.8'

services:
  redis-master:
    image: redis:7-alpine
    container_name: redis-master
    ports:
      - "6379:6379"
    command: redis-server --appendonly yes --requirepass masterpassword
    volumes:
      - master_data:/data
    networks:
      - redis-net
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "masterpassword", "ping"]
      interval: 10s
      timeout: 3s
      retries: 3

  redis-slave:
    image: redis:7-alpine
    container_name: redis-slave
    ports:
      - "6380:6379"
    command: redis-server --appendonly yes --slaveof redis-master 6379 --masterauth masterpassword --requirepass slavepassword
    volumes:
      - slave_data:/data
    networks:
      - redis-net
    depends_on:
      - redis-master
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "slavepassword", "ping"]
      interval: 10s
      timeout: 3s
      retries: 3

networks:
  redis-net:
    driver: bridge

volumes:
  master_data:
  slave_data:
```

## 配置文件

### Redis 配置

创建 `redis.conf` 文件：

```ini title="redis.conf"
# 网络配置
bind 0.0.0.0
protected-mode no
port 6379
tcp-backlog 511

# 超时配置
timeout 0
tcp-keepalive 300

# 持久化配置
appendonly yes
appendfilename "appendonly.aof"
appendfsync everysec
no-appendfsync-on-rewrite no
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb

# RDB 配置
save 900 1
save 300 10
save 60 10000
stop-writes-on-bgsave-error yes
rdbcompression yes
rdbchecksum yes
dbfilename dump.rdb

# 日志配置
loglevel notice
logfile ""
syslog-enabled no

# 内存管理
maxmemory 256mb
maxmemory-policy allkeys-lru
maxmemory-samples 5

# 慢查询日志
slowlog-log-slower-than 10000
slowlog-max-len 128

# 密码配置
requirepass yourpassword

# 数据库数量
databases 16

```

## 性能优化

### 1. 内存优化

```ini
# 设置最大内存
maxmemory 2gb

# 内存淘汰策略
# allkeys-lru: 移除最少使用的键
# volatile-lru: 移除设置了TTL的最少使用键
# allkeys-random: 随机删除键
maxmemory-policy allkeys-lru

# 采样值
maxmemory-samples 5
```

### 2. 持久化优化

```ini
# AOF 配置
appendonly yes
appendfsync everysec  # 每秒同步一次
no-appendfsync-on-rewrite no  # 重写时不同步

# RDB 配置
save 900 1      # 15分钟且至少1次变化
save 300 10     # 5分钟且至少10次变化
save 60 10000   # 1分钟且至少10000次变化
```

### 3. 网络优化

```ini
# TCP 配置
tcp-keepalive 300
tcp-backlog 511

# 禁用保护模式（仅受信任网络）
protected-mode no
```

## 常见问题

### Q1: 内存不足

**症状**: Redis 被操作系统杀掉。

**解决方案**:

```bash
# 设置最大内存
maxmemory 512mb
maxmemory-policy allkeys-lru

# 在 Docker Compose 中限制内存
deploy:
  resources:
    limits:
      memory: 512M
```

### Q2: 持久化失败

**症状**: 数据未正确保存。

**解决方案**:

```bash
# 检查权限
docker-compose exec redis ls -la /data

# 检查配置
docker-compose exec redis redis-cli CONFIG GET appendonly

# 手动保存
docker-compose exec redis redis-cli BGSAVE
```

## 最佳实践

### 1. 安全配置

```ini
# 设置密码
requirepass yourstrongpassword

# 禁用危险命令
rename-command FLUSH ""
rename-command CONFIG ""
rename-command DEBUG ""

# 限制访问
bind 127.0.0.1
protected-mode yes
```

### 2. 监控配置

```bash
# 使用 Redis Exporter
docker run -d \
  --name redis-exporter \
  -p 9121:9121 \
  --network redis-net \
  oliver006/redis_exporter \
  --redis.addr=redis://redis:6379 \
  --redis.password=yourpassword
```

## 下一步

完成 Redis 部署后，你可以继续学习：

1. 🗄️ [MySQL 数据库容器化](/docs/cases/database/mysql)
2. 🐍 [PostgreSQL 数据库](/docs/cases/database/postgresql)
3. 📝 [Node.js 应用部署](/docs/cases/web/nodejs)

:::tip 提示

在生产环境中使用 Redis 前，建议：

1. 配置合适的内存策略
2. 启用持久化保护数据
3. 设置密码保护
4. 配置监控和告警
5. 定期备份

:::

:::info 相关资源

- [Redis 官方文档](https://redis.io/documentation)
- [Redis Docker Hub](https://hub.docker.com/_/redis)
- [Redis Commander](https://rediscommander.com/)

:::
