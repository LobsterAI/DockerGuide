---
id: mysql
title: MySQL 数据库容器化
sidebar_label: MySQL 数据库
description: 使用 Docker 容器化部署 MySQL 数据库，包括数据持久化、备份恢复和性能优化
---

# MySQL 数据库容器化

## 场景描述

本案例演示如何使用 Docker 容器化部署 MySQL 数据库，涵盖数据持久化、备份恢复、性能优化和集群配置。

### 应用场景

- 💾 Web 应用后端数据库
- 📊 数据仓库和分析平台
- 🔧 开发和测试环境
- 📈 高可用数据库集群
- 🔄 主从复制架构

### 学习目标

通过本案例，你将学会：

- 使用官方 MySQL 镜像部署数据库
- 配置数据持久化和备份
- 优化 MySQL 性能参数
- 实现主从复制架构
- 配置数据库监控
- 处理常见数据库问题

## 系统架构

### 单机架构

```
                    Application
                          |
                          v
                [ MySQL Container ]
                |   Port 3306      |
                +-------------------+
                |   MySQL Server    |
                +-------------------+
                          |
                [ Data Volume ]
```

### 主从复制架构

```
                    Application
                    |      |
                    v      v
              [ Master ]  [ Slave ]
                |   |        |
                |   v        |
                | [ Data ]    |
                |             |
                +-------------+
                     Replication
```

## Dockerfile

### 基础 MySQL Dockerfile

```dockerfile title="Dockerfile"
FROM mysql:8.0

# 设置环境变量
ENV MYSQL_ROOT_PASSWORD=rootpassword
ENV MYSQL_DATABASE=mydb
ENV MYSQL_USER=myuser
ENV MYSQL_PASSWORD=mypassword

# 创建数据目录
RUN mkdir -p /var/lib/mysql && \
    chown -R mysql:mysql /var/lib/mysql

# 复制自定义配置
COPY my.cnf /etc/mysql/conf.d/

# 暴露端口
EXPOSE 3306

# 健康检查
HEALTHCHECK --interval=30s --timeout=10s --start-period=10s --retries=3 \
  CMD mysqladmin ping -h localhost -u root -p${MYSQL_ROOT_PASSWORD} || exit 1
```

### 自定义配置 Dockerfile

```dockerfile title="Dockerfile.custom"
FROM mysql:8.0

# 安装必要工具
RUN apt-get update && \
    apt-get install -y \
    vim \
    net-tools \
    iputils-ping \
    && rm -rf /var/lib/apt/lists/*

# 设置环境变量
ENV MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD}
ENV MYSQL_DATABASE=${MYSQL_DATABASE}
ENV MYSQL_USER=${MYSQL_USER}
ENV MYSQL_PASSWORD=${MYSQL_PASSWORD}

# 复制配置文件
COPY my.cnf /etc/mysql/conf.d/
COPY init-scripts/ /docker-entrypoint-initdb.d/

# 创建数据和日志目录
RUN mkdir -p /var/lib/mysql /var/log/mysql && \
    chown -R mysql:mysql /var/lib/mysql /var/log/mysql

# 暴露端口
EXPOSE 3306 33060

VOLUME ["/var/lib/mysql", "/var/log/mysql"]
```

## 配置文件

### MySQL 配置文件

创建 `my.cnf` 文件：

```ini title="my.cnf"
[mysqld]
# 基本设置
default-storage-engine=InnoDB
default-table-type=InnoDB
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci

# 连接设置
max_connections=200
max_connect_errors=10000
connect_timeout=10

# InnoDB 设置
innodb_buffer_pool_size=1G
innodb_log_file_size=256M
innodb_log_buffer_size=16M
innodb_flush_log_at_trx_commit=2
innodb_flush_method=O_DIRECT
innodb_file_per_table=1

# 查询缓存
query_cache_type=1
query_cache_size=64M
query_cache_limit=2M

# 日志设置
slow_query_log=1
slow_query_log_file=/var/log/mysql/slow-query.log
long_query_time=2
log_error=/var/log/mysql/error.log

# 二进制日志
log_bin=/var/log/mysql/mysql-bin.log
expire_logs_days=7
max_binlog_size=100M

# 安全设置
local_infile=0
symbolic-links=0
skip_name_resolve=1

[mysql]
default-character-set=utf8mb4

[client]
default-character-set=utf8mb4
```

## Docker Compose 配置

### 基础 docker-compose.yml

```yaml title="docker-compose.yml"
version: '3.8'

services:
  mysql:
    image: mysql:8.0
    container_name: mysql-server
    restart: unless-stopped
    ports:
      - "3306:3306"
    environment:
      MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD}
      MYSQL_DATABASE: ${MYSQL_DATABASE}
      MYSQL_USER: ${MYSQL_USER}
      MYSQL_PASSWORD: ${MYSQL_PASSWORD}
      TZ: Asia/Shanghai
    volumes:
      - mysql_data:/var/lib/mysql
      - mysql_logs:/var/log/mysql
      - ./my.cnf:/etc/mysql/conf.d/my.cnf:ro
    networks:
      - mysql-net
    command: --default-authentication-plugin=mysql_native_password
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-u", "root", "-p${MYSQL_ROOT_PASSWORD}"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

networks:
  mysql-net:
    driver: bridge

volumes:
  mysql_data:
    driver: local
  mysql_logs:
    driver: local
```

### 主从复制 docker-compose.yml

```yaml title="docker-compose.master-slave.yml"
version: '3.8'

services:
  mysql-master:
    image: mysql:8.0
    container_name: mysql-master
    restart: unless-stopped
    ports:
      - "3306:3306"
    environment:
      MYSQL_ROOT_PASSWORD: rootpassword
      MYSQL_REPLICATION_USER: repl
      MYSQL_REPLICATION_PASSWORD: replpassword
    volumes:
      - master_data:/var/lib/mysql
      - ./master.cnf:/etc/mysql/conf.d/custom.cnf:ro
    networks:
      - mysql-net
    command: --server-id=1 --log-bin=mysql-bin --binlog-format=ROW

  mysql-slave:
    image: mysql:8.0
    container_name: mysql-slave
    restart: unless-stopped
    ports:
      - "3307:3306"
    environment:
      MYSQL_ROOT_PASSWORD: rootpassword
      MYSQL_MASTER_HOST: mysql-master
      MYSQL_REPLICATION_USER: repl
      MYSQL_REPLICATION_PASSWORD: replpassword
    volumes:
      - slave_data:/var/lib/mysql
      - ./slave.cnf:/etc/mysql/conf.d/custom.cnf:ro
    networks:
      - mysql-net
    depends_on:
      - mysql-master
    command: --server-id=2 --relay-log=relay-bin --read-only=1

  phpmyadmin:
    image: phpmyadmin/phpmyadmin:latest
    container_name: phpmyadmin
    restart: unless-stopped
    ports:
      - "8080:80"
    environment:
      PMA_HOST: mysql-master
      PMA_PORT: 3306
      PMA_USER: root
      PMA_PASSWORD: rootpassword
      UPLOAD_LIMIT: 100M
    networks:
      - mysql-net

networks:
  mysql-net:
    driver: bridge

volumes:
  master_data:
  slave_data:
```

## 部署步骤

### 1. 准备环境

```bash
# 创建项目目录
mkdir mysql-docker && cd mysql-docker

# 创建配置文件
cat > my.cnf << 'EOF'
[mysqld]
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
innodb_buffer_pool_size=1G
innodb_log_file_size=256M
max_connections=200
