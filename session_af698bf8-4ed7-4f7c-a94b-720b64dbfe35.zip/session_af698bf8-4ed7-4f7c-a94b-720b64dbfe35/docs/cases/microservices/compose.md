---
id: compose
title: 使用 Docker Compose 编排微服务
sidebar_label: Docker Compose 编排
description: 使用 Docker Compose 编排和管理微服务架构，包括服务依赖、网络配置和负载均衡
---

# 使用 Docker Compose 编排微服务

## 场景描述

本案例演示如何使用 Docker Compose 编排复杂的微服务架构，涵盖服务依赖管理、网络配置、数据持久化和负载均衡。

### 应用场景

- 🌐 全栈 Web 应用
- 🔧 微服务架构系统
- 📊 数据密集型应用
- 🚀 CI/CD 环境部署
- 🔄 多环境配置管理

### 学习目标

通过本案例，你将学会：

- 使用 Docker Compose 编排多容器应用
- 配置服务依赖和启动顺序
- 实现服务间通信和负载均衡
- 配置数据持久化和共享卷
- 管理多环境配置
- 实现服务健康检查和自愈

## 系统架构

### 微服务架构

```
                         Internet
                             |
                             v
                      [ Nginx Gateway ]
                             |
        +----------------------+----------------------+
        |                      |                      |
   [ Web App ]         [ API Gateway ]       [ Admin Panel ]
        |                      |                      |
        v                      v                      v
   [ Backend API ]       [ Auth Service ]       [ Analytics ]
        |                      |                      |
        +----------------------+----------------------+
                             |
                             v
                      [ Redis Cache ]
                             |
                             v
                      [ PostgreSQL DB ]
```

### 组件说明

- **Nginx 网关**: 反向代理和负载均衡
- **Web 应用**: 前端 React/Vue 应用
- **API 网关**: 统一 API 入口
- **后端服务**: 核心 API 服务
- **认证服务**: 用户认证和授权
- **分析服务**: 数据收集和分析
- **Redis**: 缓存和会话存储
- **PostgreSQL**: 主数据库

## 项目结构

```
microservices-app/
├── docker-compose.yml          # 主编排文件
├── docker-compose.dev.yml      # 开发环境配置
├── docker-compose.prod.yml     # 生产环境配置
├── .env                      # 环境变量
├── .env.example              # 环境变量示例
├── nginx/
│   ├── nginx.conf            # Nginx 主配置
│   ├── sites-available/      # 站点配置
│   └── ssl/                # SSL 证书
├── frontend/                 # 前端应用
│   ├── Dockerfile
│   └── src/
├── backend/                  # 后端 API
│   ├── Dockerfile
│   └── src/
├── auth/                     # 认证服务
│   ├── Dockerfile
│   └── src/
├── analytics/               # 分析服务
│   ├── Dockerfile
│   └── src/
└── scripts/                  # 辅助脚本
    ├── backup.sh
    └── deploy.sh
```

## Docker Compose 配置

### 主配置文件

```yaml title="docker-compose.yml"
version: '3.8'

services:
  # Nginx 网关
  nginx:
    image: nginx:alpine
    container_name: nginx-gateway
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/sites-available:/etc/nginx/conf.d:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
      - nginx_logs:/var/log/nginx
    networks:
      - frontend
      - backend
      - internal
    depends_on:
      - web
      - api
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # 前端应用
  web:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: web-app
    restart: unless-stopped
    environment:
      - NODE_ENV=${NODE_ENV:-production}
      - API_URL=http://api:8000
    networks:
      - frontend
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:3000"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # API 网关
  api-gateway:
    build:
      context: ./api-gateway
      dockerfile: Dockerfile
    container_name: api-gateway
    restart: unless-stopped
    ports:
      - "8000:8000"
    environment:
      - NODE_ENV=${NODE_ENV:-production}
      - AUTH_SERVICE=http://auth:5000
      - BACKEND_SERVICE=http://backend:5001
      - ANALYTICS_SERVICE=http://analytics:5002
      - REDIS_URL=redis://redis:6379
    networks:
      - frontend
      - backend
    depends_on:
      - auth
      - backend
      - analytics
      - redis
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # 后端 API
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: backend-api
    restart: unless-stopped
    environment:
      - NODE_ENV=${NODE_ENV:-production}
      - DATABASE_URL=postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
      - REDIS_URL=redis://redis:6379
      - AUTH_SERVICE_URL=http://auth:5000
    networks:
      - backend
      - internal
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:5001/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # 认证服务
  auth:
    build:
      context: ./auth
      dockerfile: Dockerfile
    container_name: auth-service
    restart: unless-stopped
    environment:
      - NODE_ENV=${NODE_ENV:-production}
      - DATABASE_URL=postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
      - REDIS_URL=redis://redis:6379
      - JWT_SECRET=${JWT_SECRET}
      - JWT_EXPIRATION=${JWT_EXPIRATION:-7d}
    networks:
      - backend
      - internal
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:5000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # 分析服务
  analytics:
    build:
      context: ./analytics
      dockerfile: Dockerfile
    container_name: analytics-service
    restart: unless-stopped
    environment:
      - NODE_ENV=${NODE_ENV:-production}
      - DATABASE_URL=postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
      - REDIS_URL=redis://redis:6379
    networks:
      - backend
      - internal
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:5002/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # Redis 缓存
  redis:
    image: redis:alpine
    container_name: redis-cache
    restart: unless-stopped
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
      - redis_conf:/usr/local/etc/redis
    networks:
      - internal
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # PostgreSQL 数据库
  postgres:
    image: postgres:15-alpine
    container_name: postgres-db
    restart: unless-stopped
    environment:
      - POSTGRES_DB=${POSTGRES_DB}
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
      - POSTGRES_INITDB_ARGS=--encoding=UTF-8 --lc-collate=en_US.utf8
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - postgres_backup:/var/lib/postgresql/backup
      - ./db/init:/docker-entrypoint-initdb.d:ro
    networks:
      - internal
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # pgAdmin（数据库管理工具）
  pgadmin:
    image: dpage/pgadmin4:latest
    container_name: pgadmin
    restart: unless-stopped
    ports:
      - "5050:80"
    environment:
      - PGADMIN_DEFAULT_EMAIL=${PGADMIN_EMAIL}
      - PGADMIN_DEFAULT_PASSWORD=${PGADMIN_PASSWORD}
      - PGADMIN_CONFIG_SERVER_MODE=False
    volumes:
      - pgadmin_data:/var/lib/pgadmin
    networks:
      - internal
    depends_on:
      - postgres

networks:
  frontend:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
  backend:
    driver: bridge
    ipam:
      config:
        - subnet: 172.21.0.0/16
  internal:
    driver: bridge
    internal: true
    ipam:
      config:
        - subnet: 172.22.0.0/16

volumes:
  postgres_data:
    driver: local
  postgres_backup:
    driver: local
  redis_data:
    driver: local
  redis_conf:
    driver: local
  nginx_logs:
    driver: local
  pgadmin_data:
    driver: local
```

### 开发环境配置

```yaml title="docker-compose.dev.yml"
version: '3.8'

services:
  # 前端开发服务
  web:
    build:
      context: ./frontend
      dockerfile: Dockerfile.dev
    volumes:
      - ./frontend:/app
      - /app/node_modules
      - /app/.next
    environment:
      - NODE_ENV=development
      - CHOKIDAR_USEPOLLING=true
    command: npm run dev

  # 后端开发服务
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile.dev
    volumes:
      - ./backend:/app
      - /app/node_modules
    environment:
      - NODE_ENV=development
    command: npm run dev

  # Redis 开发配置
  redis:
    ports:
      - "6379:6379"
    command: redis-server --appendonly yes --appendfsync everysec

  # 数据库开发配置
  postgres:
    ports:
      - "5432:5432"
```

### 生产环境配置

```yaml title="docker-compose.prod.yml"
version: '3.8'

services:
  # 所有服务添加资源限制
  nginx:
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  backend:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 1G
        reservations:
          cpus: '1.0'
          memory: 512M
      replicas: 2
    restart_policy:
      condition: on-failure
      delay: 5s
      max_attempts: 3
      window: 120s

  # 其他服务类似配置...
```

## 网络配置

### Nginx 网关配置

```nginx title="nginx.conf"
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    access_log /var/log/nginx/access.log main;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;
    include /etc/nginx/conf.d/*.conf;
}
```

### API 反向代理配置

```nginx title="api.conf"
upstream backend_servers {
    least_conn;
    server backend:5001 max_fails=3 fail_timeout=30s;
    server backend_2:5001 max_fails=3 fail_timeout=30s;
    server backend_3:5001 max_fails=3 fail_timeout=30s;
}

server {
    listen 80;
    server_name api.yourdomain.com;

    # API 路由
    location /api/v1/ {
        proxy_pass http://backend_servers;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
```

## 环境变量

### .env 文件

```bash title=".env"
# 应用配置
NODE_ENV=production
APP_NAME=Microservices App

# 数据库配置
POSTGRES_DB=appdb
POSTGRES_USER=appuser
POSTGRES_PASSWORD=your_secure_password
POSTGRES_HOST=postgres
POSTGRES_PORT=5432

# Redis 配置
REDIS_URL=redis://redis:6379
REDIS_PASSWORD=

# 认证配置
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRATION=7d

# Nginx 配置
NGINX_HOST=yourdomain.com
NGINX_PORT=80

# pgAdmin 配置
PGADMIN_EMAIL=admin@yourdomain.com
PGADMIN_PASSWORD=your_pgadmin_password

# 日志配置
LOG_LEVEL=info
```

### .env.example 文件

```bash title=".env.example"
# 复制此文件为 .env 并填入实际值
cp .env.example .env

# 应用配置
NODE_ENV=development
APP_NAME=Microservices App

# 数据库配置
POSTGRES_DB=appdb
POSTGRES_USER=appuser
POSTGRES_PASSWORD=your_secure_password

# 认证配置
JWT_SECRET=your_jwt_secret_here

# ... 其他配置
```

## 部署步骤

### 1. 克隆项目

```bash
git clone https://github.com/your-repo/microservices-app.git
cd microservices-app
```

### 2. 配置环境变量

```bash
# 复制环境变量示例
cp .env.example .env

# 编辑环境变量
nano .env

# 或使用编辑器
vim .env
```

### 3. 构建和启动

```bash
# 开发环境
docker-compose -f docker-compose.dev.yml up -d

# 生产环境
docker-compose -f docker-compose.prod.yml up -d

# 查看日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f nginx
```

### 4. 验证部署

```bash
# 检查所有服务状态
docker-compose ps

# 检查健康状态
docker-compose exec nginx wget --quiet --tries=1 --spider http://localhost/health

# 进入容器调试
docker-compose exec backend sh

# 查看网络配置
docker network inspect microservices-app_frontend
```

## 监控和日志

### 日志管理

```bash
# 查看所有服务日志
docker-compose logs

# 实时跟踪日志
docker-compose logs -f nginx

# 查看最近 100 行日志
docker-compose logs --tail=100 backend

# 导出日志
docker-compose logs > logs.txt
```

### 健康检查

```bash
# 检查服务健康状态
curl http://localhost/health
curl http://localhost:8000/health
curl http://localhost:5001/health
curl http://localhost:5000/health
curl http://localhost:5002/health
```

## 常见问题

### Q1: 服务启动顺序问题

**症状**: 服务因依赖未就绪而启动失败。

**解决方案**:

```yaml
# 使用 depends_on 和条件
depends_on:
  postgres:
    condition: service_healthy

# 添加重试逻辑
restart: unless-stopped
restart_policy:
  condition: on-failure
  delay: 5s
  max_attempts: 3
```

### Q2: 服务间通信失败

**症状**: 服务无法相互访问。

**解决方案**:

```yaml
# 确保在同一网络
networks:
  - backend

# 使用服务名作为主机名
environment:
  - DATABASE_URL=postgresql://postgres:5432/appdb

# 检查网络连接
docker-compose exec backend ping postgres
```

## 最佳实践

### 1. 资源限制

```yaml
# 设置适当的资源限制
deploy:
  resources:
    limits:
      cpus: '1.0'
      memory: 512M
    reservations:
      cpus: '0.5'
      memory: 256M
```

### 2. 健康检查

```yaml
# 为所有服务配置健康检查
healthcheck:
  test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:3000"]
  interval: 30s
  timeout: 10s
  retries: 3
  start_period: 10s
```

### 3. 日志管理

```yaml
# 配置日志轮转
logging:
  driver: "json-file"
  options:
    max-size: "10m"
    max-file: "3"
```

## 下一步

完成 Docker Compose 编排后，你可以继续学习：

1. 🔍 [容器监控配置](/docs/cases/microservices/monitoring)
2. 📊 [ELK 日志管理](/docs/cases/microservices/logging)
3. 🔧 [API 网关配置](/docs/cases/microservices/gateway)

:::tip 提示

在生产环境部署前，建议：

1. 使用外部数据库和缓存服务
2. 配置 SSL/TLS 证书
3. 设置监控和告警
4. 配置日志收集和分析
5. 制定备份和恢复计划

:::

:::info 相关资源

- [Docker Compose 官方文档](https://docs.docker.com/compose/)
- [Nginx 配置参考](https://nginx.org/en/docs/)
- [微服务最佳实践](https://microservices.io/patterns/)

:::
