---
id: performance
title: 性能优化和资源限制
sidebar_label: 性能优化
description: Docker 容器性能优化策略，包括资源限制、镜像优化和系统调优
---

# 性能优化和资源限制

## 场景描述

本案例演示如何优化 Docker 容器的性能，包括 CPU、内存、磁盘 I/O 和网络资源的合理配置和调优。

### 应用场景

- 🚀 生产环境资源规划
- 📊 容器性能监控
- 🔧 系统资源调优
- 💾 镜像大小优化
- 🌐 网络性能优化

### 学习目标

通过本案例，你将学会：

- 配置容器资源限制
- 优化 Docker 镜像大小
- 调整系统内核参数
- 监控容器性能
- 优化存储和网络性能
- 排查性能瓶颈

## 资源限制

### CPU 限制

```yaml title="docker-compose.yml"
services:
  app:
    # CPU 份额（相对权重）
    cpu_shares: 512
    # CPU 核心数限制
    cpus: '2.0'
    # CPU 集合（绑定到特定 CPU）
    cpuset: '0,1'
    deploy:
      resources:
        limits:
          cpus: '2.0'
        reservations:
          cpus: '1.0'
```

### 内存限制

```yaml title="docker-compose.yml"
services:
  app:
    # 内存限制
    mem_limit: 512m
    # 内存保留
    mem_reservation: 256m
    # 内存交换限制
    memswap_limit: 1g
    deploy:
      resources:
        limits:
          memory: 512M
        reservations:
          memory: 256M
```

### 磁盘 I/O 限制

```yaml title="docker-compose.yml"
services:
  app:
    blkio_config:
      # 读取速率限制（每秒字节数）
      device_read_bps:
        - /dev/sda: 10485760  # 10MB/s
      # 读取 IOPS 限制
      device_read_iops:
        - /dev/sda: 1000
      # 写入速率限制
      device_write_bps:
        - /dev/sda: 10485760
      # 写入 IOPS 限制
      device_write_iops:
        - /dev/sda: 1000
      # 读写权重
      weight: 500
      weight_device:
        - /dev/sda:500
```

## 镜像优化

### 多阶段构建

```dockerfile title="Dockerfile.optimized"
# 构建阶段
FROM node:18-alpine AS builder

WORKDIR /app

# 仅复制 package 文件
COPY package*.json ./

# 安装依赖
RUN npm ci --only=production

# 复制源代码
COPY . .

# 构建应用
RUN npm run build

# 生产阶段
FROM node:18-alpine

# 删除开发依赖
RUN apk del .ruby-* \
    && apk del .py-* \
    && rm -rf /var/cache/apk/*

WORKDIR /app

# 从构建阶段复制
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/dist ./dist

# 创建非 root 用户
RUN addgroup -g 1001 -S nodejs && \
    adduser -S -u 1001 -G nodejs nodejs && \
    chown -R nodejs:nodejs /app

USER nodejs

# 健康检查
HEALTHCHECK --interval=30s --timeout=3s \
  CMD wget --quiet --tries=1 --spider http://localhost:3000/health

EXPOSE 3000
CMD ["node", "dist/index.js"]
```

### .dockerignore 优化

```text title=".dockerignore"
# 依赖
node_modules
npm-debug.log
yarn-error.log

# Git
.git
.gitignore
.gitattributes

# IDE
.vscode
.idea
*.swp
*.swo

# 测试
coverage
.nyc_output
.jest

# 文档
*.md
docs/

# 开发配置
.env.local
.env.*.local

# CI/CD
.github
.gitlab-ci.yml

# Docker
Dockerfile
docker-compose*.yml
.dockerignore
```

## 系统调优

### 内核参数优化

```bash title="/etc/sysctl.d/99-docker.conf"
# 网络参数
net.ipv4.ip_forward=1
net.ipv4.conf.all.forwarding=1

# 连接跟踪
net.netfilter.nf_conntrack_max=262144
net.netfilter.nf_conntrack_tcp_timeout_established=86400

# TCP 参数
net.ipv4.tcp_tw_reuse=1
net.ipv4.tcp_fin_timeout=30
net.ipv4.tcp_keepalive_time=600
net.ipv4.tcp_max_syn_backlog=8192

# 内存参数
vm.swappiness=10
vm.dirty_ratio=60
vm.dirty_background_ratio=1
```

### Docker 守护进程配置

```json title="/etc/docker/daemon.json"
{
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 64000,
      "Soft": 64000
    },
    "nproc": {
      "Name": "nproc",
      "Hard": 65535,
      "Soft": 65535
    }
  },
  "max-concurrent-downloads": 10,
  "max-concurrent-uploads": 5,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2",
  "storage-opts": [
    "overlay2.override_kernel_check=true",
    "overlay2.size=20G"
  ]
}
```

## 性能监控

### cAdvisor 部署

```yaml title="docker-compose.yml"
version: '3.8'

services:
  cadvisor:
    image: gcr.io/cadvisor/cadvisor:latest
    container_name: cadvisor
    ports:
      - "8080:8080"
    volumes:
      - /:/rootfs:ro
      - /var/run:/var/run:ro
      - /sys:/sys:ro
      - /var/lib/docker/:/var/lib/docker:ro
    privileged: true
    restart: unless-stopped
```

### Prometheus 配置

```yaml title="prometheus.yml"
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'docker'
    static_configs:
      - targets: ['cadvisor:8080']

  - job_name: 'containers'
    static_configs:
      - targets: ['node-exporter:9100']
```

## 性能优化建议

### 1. 容器启动优化

```dockerfile
# 使用轻量级基础镜像
FROM alpine:latest

# 合并 RUN 命令减少层数
RUN apk add --no-cache python3 \
    && pip3 install --no-cache-dir flask \
    && rm -rf /root/.cache

# 利用构建缓存
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 只复制必要文件
COPY app.py .
```

### 2. 网络性能优化

```yaml
# 使用 host 网络模式
network_mode: host

# 或使用自定义网络
networks:
  fast-net:
    driver: bridge
    driver_opts:
      com.docker.network.bridge.name: fast-net
```

### 3. 存储性能优化

```yaml
volumes:
  # 使用 tmpfs 提高速度
  cache:
    driver: local
    driver_opts:
      type: tmpfs
      device: tmpfs
      o: size=1g,uid=1000
```

## 常见问题

### Q1: 内存泄漏

**症状**: 容器内存使用持续增长。

**解决方案**:

```bash
# 监控内存使用
docker stats --no-stream

# 限制内存
docker update --memory="512m" container-name

# 优化应用代码
# 检查内存泄漏
```

### Q2: CPU 使用过高

**症状**: 容器 CPU 使用率 100%。

**解决方案**:

```yaml
# 限制 CPU
deploy:
  resources:
    limits:
      cpus: '2.0'

# 优化代码
# 使用多进程/多线程
```

## 最佳实践

### 1. 资源规划

```bash
# 评估应用资源需求
# 设置合理的限制
# 监控实际使用情况
# 根据需要调整
```

### 2. 监控告警

```yaml
# 设置监控指标
# 配置告警规则
# 定期检查性能
# 及时响应问题
```

## 下一步

完成性能优化后，你可以继续学习：

1. 🔐 [容器安全最佳实践](/docs/cases/prod/security)
2. 🔄 [部署策略配置](/docs/cases/prod/deployment)

:::tip 提示

生产环境性能优化建议：

1. 定期监控资源使用
2. 设置合理的资源限制
3. 优化镜像大小
4. 调整系统参数
5. 及时处理性能问题

:::

:::info 监控工具

推荐的性能监控工具：

- cAdvisor: 容器资源监控
- Prometheus: 指标收集和存储
- Grafana: 数据可视化
- Node Exporter: 系统指标收集

:::
