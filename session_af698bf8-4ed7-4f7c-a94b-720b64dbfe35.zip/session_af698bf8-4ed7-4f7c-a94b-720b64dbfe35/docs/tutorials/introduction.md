---
id: introduction
title: Docker 基础概念
sidebar_label: 基础概念
description: 了解 Docker 的核心概念，包括容器、镜像、仓库等基本术语，以及 Docker 与传统虚拟机的区别
---

# Docker 基础概念

在深入学习 Docker 之前，首先需要理解其核心概念和基本架构。Docker 通过容器化技术改变了应用的打包、分发和部署方式。

## 核心概念

### 🐳 容器 (Container)

容器是 Docker 的核心概念。容器是一个轻量级、独立、可执行的软件包，包含运行应用程序所需的所有内容：代码、运行时、系统工具、系统库和设置。

**容器特点：**

- **轻量级**: 容器共享主机操作系统内核，无需完整的操作系统
- **隔离性**: 容器之间相互隔离，拥有独立的进程空间
- **可移植性**: 容器可以在任何支持 Docker 的平台上运行
- **快速启动**: 容器启动时间通常在秒级

```bash
# 运行一个 Nginx 容器
docker run -d -p 80:80 --name my-webserver nginx
```

### 📦 镜像 (Image)

镜像是一个只读的模板，用于创建容器。它包含了运行应用所需的所有内容：代码、运行时环境、系统工具、库和配置文件。

**镜像特点：**

- **分层存储**: 镜像由多个只读层组成
- **不可变性**: 镜像构建后不可修改
- **可复用性**: 一个镜像可以创建多个容器
- **版本管理**: 支持标签系统管理不同版本

```bash
# 拉取 Ubuntu 镜像
docker pull ubuntu:22.04

# 查看本地镜像
docker images
```

### 🏪 仓库 (Registry)

仓库是存储和分发镜像的地方。Docker Hub 是 Docker 官方提供的公共仓库，你也可以搭建私有仓库。

**常用仓库：**

- **Docker Hub**: Docker 官方公共仓库
- **阿里云镜像仓库**: 国内访问速度快
- **私有仓库**: 企业内部部署的私有镜像存储

```bash
# 登录 Docker Hub
docker login

# 推送镜像到仓库
docker push username/imagename:tag
```

## Docker 架构

Docker 采用客户端-服务器 (C/S) 架构，主要组件包括：

### 架构组件

```mermaid
graph TB
    A[Client] -->|REST API| B[Docker Daemon]
    B --> C[Containers]
    B --> D[Images]
    B --> E[Registry]
    
    style A fill:#3498db
    style B fill:#2c3e50
    style C fill:#3498db
    style D fill:#3498db
    style E fill:#2ecc71
```

### 1. Docker 客户端 (Docker Client)

Docker 客户端是用户与 Docker 交互的主要接口，通过命令行或 API 与 Docker 守护进程通信。

**常用客户端命令：**
- `docker run` - 运行容器
- `docker build` - 构建镜像
- `docker pull` - 拉取镜像
- `docker push` - 推送镜像

### 2. Docker 守护进程 (Docker Daemon)

Docker 守护进程 (`dockerd`) 是 Docker 的核心组件，负责构建、运行和分发 Docker 容器。

**主要功能：**
- 管理容器和镜像
- 处理 API 请求
- 与容器运行时交互

### 3. Docker 镜像 (Docker Images)

Docker 镜像是只读模板，用于创建容器。镜像通过 Dockerfile 定义构建过程。

### 4. Docker 容器 (Docker Containers)

容器是从镜像创建的运行实例，可以启动、停止、删除。

### 5. Docker Registry (Docker 仓库)

Docker 仓库用于存储和分发 Docker 镜像。

## Docker 与虚拟机对比

### 架构差异

| 特性 | Docker 容器 | 传统虚拟机 |
|------|------------|----------|
| **操作系统** | 共享主机内核 | 独立完整的操作系统 |
| **启动时间** | 秒级 | 分钟级 |
| **资源占用** | 极小 | 较大 |
| **性能** | 接近原生 | 有一定损耗 |
| **隔离性** | 进程级隔离 | 硬件级隔离 |
| **可移植性** | 高 | 中 |

### 架构示意图

```mermaid
graph LR
    subgraph 容器架构
        A[基础设施] --> B[主机操作系统]
        B --> C[Docker 引擎]
        C --> D[容器1]
        C --> E[容器2]
        C --> F[容器3]
    end
    
    subgraph 虚拟机架构
        G[基础设施] --> H[虚拟化层]
        H --> I[客户操作系统]
        H --> J[客户操作系统]
        I --> K[应用1]
        J --> L[应用2]
    end
```

## 关键技术

### 1. 命名空间 (Namespaces)

命名空间提供了进程的隔离视图，包括：

- **PID 命名空间**: 隔离进程 ID
- **NET 命名空间**: 隔离网络栈
- **MNT 命名空间**: 隔离文件系统挂载点
- **IPC 命名空间**: 隔离进程间通信
- **UTS 命名空间**: 隔离主机名和域名

### 2. 控制组 (Cgroups)

控制组限制、记录和隔离进程组使用的物理资源（CPU、内存、磁盘 I/O 等）。

**使用示例：**

```bash
# 创建 cgroup 限制内存
cgcreate -g memory:/docker

# 设置内存限制为 512MB
echo 512M > /sys/fs/cgroup/memory/docker/memory.limit_in_bytes
```

### 3. 联合文件系统 (UnionFS)

联合文件系统允许将多个文件系统层叠在一起，形成一个统一的文件系统视图。

**特点：**
- **分层存储**: 每层都是只读的
- **Copy-on-Write**: 写时复制机制
- **高效共享**: 多个容器可以共享相同的基础层

## Docker 生命周期

### 容器生命周期图

```mermaid
stateDiagram-v2
    [*] --> Created: docker create
    Created --> Running: docker start
    Running --> Paused: docker pause
    Paused --> Running: docker unpause
    Running --> Stopped: docker stop
    Stopped --> Running: docker start
    Stopped --> [*]: docker rm
    Running --> [*]: docker kill
```

### 常用生命周期命令

```bash
# 创建容器
docker create -name my-container ubuntu

# 启动容器
docker start my-container

# 运行容器
docker run -it ubuntu bash

# 停止容器
docker stop my-container

# 重启容器
docker restart my-container

# 删除容器
docker rm my-container
```

## Dockerfile 基础

Dockerfile 是用于构建 Docker 镜像的文本文件。

### 基本结构

```dockerfile
# 基础镜像
FROM ubuntu:22.04

# 维护者信息
LABEL maintainer="yourname@example.com"

# 设置工作目录
WORKDIR /app

# 复制文件
COPY . /app

# 安装依赖
RUN apt-get update && \
    apt-get install -y python3 python3-pip

# 设置环境变量
ENV PYTHONUNBUFFERED=1

# 暴露端口
EXPOSE 8080

# 运行命令
CMD ["python3", "app.py"]
```

### 常用指令说明

| 指令 | 说明 | 示例 |
|------|------|------|
| `FROM` | 指定基础镜像 | `FROM ubuntu:22.04` |
| `RUN` | 执行命令 | `RUN apt-get update` |
| `COPY` | 复制文件到镜像 | `COPY . /app` |
| `ADD` | 复制文件或解压压缩包 | `ADD archive.tar.gz /app` |
| `CMD` | 容器启动时执行命令 | `CMD ["python3", "app.py"]` |
| `ENTRYPOINT` | 配置容器启动入口 | `ENTRYPOINT ["python3"]` |
| `ENV` | 设置环境变量 | `ENV PATH=/app/bin` |
| `EXPOSE` | 声明容器暴露的端口 | `EXPOSE 8080` |
| `VOLUME` | 创建挂载点 | `VOLUME ["/data"]` |
| `WORKDIR` | 设置工作目录 | `WORKDIR /app` |

## 实践示例

### 1. 构建简单的 Web 应用

```bash
# 创建项目目录
mkdir docker-demo && cd docker-demo

# 创建 HTML 文件
cat > index.html << EOF
<!DOCTYPE html>
<html>
<head>
    <title>Docker Demo</title>
</head>
<body>
    <h1>Hello, Docker!</h1>
    <p>This is a simple Docker demo.</p>
</body>
</html>
EOF

# 创建 Dockerfile
cat > Dockerfile << EOF
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/index.html
EOF

# 构建镜像
docker build -t my-web-app .

# 运行容器
docker run -d -p 8080:80 --name my-web my-web-app
```

### 2. 运行交互式容器

```bash
# 运行交互式 Ubuntu 容器
docker run -it ubuntu:22.04 bash

# 在容器内执行命令
root@container:/# apt-get update
root@container:/# apt-get install -y vim
root@container:/# exit

# 使用已退出的容器创建新镜像
docker commit container-name new-image-name
```

## 最佳实践

### 1. 镜像构建

- **使用官方基础镜像**: 选择官方维护的基础镜像
- **优化层结构**: 合并相关命令减少层数
- **最小化镜像大小**: 清理不必要的文件和缓存
- **使用 .dockerignore**: 排除不必要的文件

```bash
# 创建 .dockerignore 文件
cat > .dockerignore << EOF
.git
node_modules
npm-debug.log
Dockerfile
docker-compose.yml
.gitignore
EOF
```

### 2. 容器运行

- **使用非 root 用户**: 提高安全性
- **设置资源限制**: 防止容器占用过多资源
- **使用数据卷**: 持久化重要数据
- **健康检查**: 配置容器健康检查

```bash
# 运行带资源限制的容器
docker run -d \
  --name my-app \
  --memory="512m" \
  --cpus="1.0" \
  -v /data:/app/data \
  my-image
```

### 3. 网络配置

- **使用自定义网络**: 提高容器间通信效率
- **限制容器网络**: 减少安全风险
- **使用服务发现**: 简化容器间通信

```bash
# 创建自定义网络
docker network create my-network

# 运行容器并加入网络
docker run -d --network my-network --name app1 app1-image
docker run -d --network my-network --name app2 app2-image
```

## 常见问题

### Q1: 容器和虚拟机有什么区别？

容器共享主机操作系统内核，更加轻量级；虚拟机需要完整的操作系统，资源占用更大。容器启动更快，更适合微服务架构。

### Q2: 如何选择合适的基础镜像？

- 选择官方维护的镜像
- 使用稳定版本标签
- 考虑使用 Alpine 等轻量级镜像
- 定期更新基础镜像

### Q3: 如何查看容器日志？

```bash
# 查看容器日志
docker logs container-name

# 实时跟踪日志
docker logs -f container-name

# 查看最近 100 行日志
docker logs --tail 100 container-name
```

### Q4: 如何进入运行中的容器？

```bash
# 使用 exec 命令进入容器
docker exec -it container-name /bin/bash

# 或者使用 /bin/sh
docker exec -it container-name /bin/sh
```

## 下一步

掌握了 Docker 的基础概念后，你可以：

1. 📚 学习 [Docker 架构](/docs/tutorials/architecture)
2. 💻 查看 [安装指南](/docs/installation/)
3. 🔧 掌握 [Docker 命令](/docs/tutorials/commands/)
4. 🎯 尝试 [实战案例](/docs/cases/)

:::tip 提示

建议在学习基础概念后，先在本地环境安装 Docker 并运行几个示例容器，通过实践加深理解。

:::

:::info 推荐资源

- [Docker 官方文档](https://docs.docker.com/)
- [Docker Hub](https://hub.docker.com/)
- [Docker 最佳实践](https://docs.docker.com/develop/dev-best-practices/)

:::