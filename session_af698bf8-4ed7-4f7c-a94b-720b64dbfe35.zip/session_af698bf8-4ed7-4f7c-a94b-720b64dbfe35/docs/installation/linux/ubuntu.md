---
id: ubuntu
title: Ubuntu/Debian 安装 Docker
sidebar_label: Ubuntu/Debian
description: 在 Ubuntu 或 Debian 系统上安装 Docker 的详细指南
---

# 在 Ubuntu/Debian 上安装 Docker

本指南将帮助你在 Ubuntu 或 Debian 系统上安装 Docker Engine。我们将介绍多种安装方法，包括使用官方仓库、便捷脚本和手动安装。

## 系统要求

在开始安装之前，请确保你的系统满足以下要求：

### 支持的 Ubuntu 版本

- Ubuntu Mantic 23.10
- Ubuntu Lunar 23.04
- Ubuntu Jammy 22.04 LTS
- Ubuntu Focal 20.04 LTS
- Ubuntu Bionic 18.04 LTS

### 支持的 Debian 版本

- Debian Bookworm 12
- Debian Bullseye 11
- Debian Buster 10

### 硬件要求

- **架构**: x86_64 (amd64), armhf, arm64, s390x, ppc64le
- **内核**: 3.10 或更高版本
- **内存**: 至少 2GB RAM（推荐 4GB 或更多）
- **磁盘空间**: 至少 20GB 可用空间
- **网络**: 稳定的互联网连接

## 准备工作

### 1. 更新系统包索引

首先，更新系统的包索引并安装必要的依赖：

```bash
# 更新包索引
sudo apt-get update

# 安装必要的依赖
sudo apt-get install -y \
    ca-certificates \
    curl \
    gnupg \
    lsb-release
```

### 2. 卸载旧版本

如果系统中已安装旧版本的 Docker，请先卸载：

```bash
# 卸载旧版本的 Docker
sudo apt-get remove docker docker-engine docker.io containerd runc

# 清理相关配置文件
sudo apt-get purge docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 清理未使用的依赖
sudo apt-get autoremove -y

# 清理包缓存
sudo apt-get clean
```

## 方法一：使用官方仓库安装（推荐）

这是推荐的安装方法，可以确保你获得最新的稳定版本，并且便于日后升级。

### 1. 添加 Docker 官方 GPG 密钥

```bash
# 创建密钥环目录
sudo install -m 0755 -d /etc/apt/keyrings

# 下载 Docker GPG 密钥
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

# 设置密钥权限
sudo chmod a+r /etc/apt/keyrings/docker.gpg
```

对于 Debian 系统，使用以下命令：

```bash
# 下载 Docker GPG 密钥
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

# 设置密钥权限
sudo chmod a+r /etc/apt/keyrings/docker.gpg
```

### 2. 设置 Docker 仓库

```bash
# 添加 Docker 仓库到 APT 源
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
```

对于 Debian 系统：

```bash
# 添加 Docker 仓库到 APT 源
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
```

### 3. 安装 Docker Engine

```bash
# 更新包索引
sudo apt-get update

# 安装 Docker Engine 及相关组件
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 安装特定版本（可选）
# 首先列出可用版本
# apt-cache madison docker-ce | awk '{print $3}'

# 安装特定版本，例如 24.0.7
# sudo apt-get install docker-ce=5:24.0.7-1~ubuntu.22.04~jammy docker-ce-cli=5:24.0.7-1~ubuntu.22.04~jammy containerd.io
```

## 方法二：使用便捷脚本安装

Docker 提供了一个便捷安装脚本，适合在测试或开发环境中快速安装 Docker。

```bash
# 下载并运行安装脚本
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 将当前用户添加到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行
newgrp docker
```

:::warning 注意

便捷安装脚本仅适用于开发和测试环境。在生产环境中，建议使用官方仓库安装方法。

:::

## 方法三：手动下载和安装 DEB 包

如果你无法访问 Docker 官方仓库，可以手动下载 DEB 包进行安装。

### 1. 下载 DEB 包

访问 [Docker 官方下载页面](https://download.docker.com/linux/ubuntu/dists/) 或 [Debian 下载页面](https://download.docker.com/linux/debian/dists/) 下载以下包：

- `containerd.io_<version>_<arch>.deb`
- `docker-ce_<version>_<arch>.deb`
- `docker-ce-cli_<version>_<arch>.deb`
- `docker-buildx-plugin_<version>_<arch>.deb`
- `docker-compose-plugin_<version>_<arch>.deb`

### 2. 安装 DEB 包

```bash
# 安装下载的 DEB 包
sudo dpkg -i ./containerd.io_<version>_<arch>.deb \
  ./docker-ce_<version>_<arch>.deb \
  ./docker-ce-cli_<version>_<arch>.deb \
  ./docker-buildx-plugin_<version>_<arch>.deb \
  ./docker-compose-plugin_<version>_<arch>.deb

# 解决依赖问题（如果有）
sudo apt-get install -f
```

## 安装后配置

### 1. 启动 Docker 服务

```bash
# 启动 Docker 服务
sudo systemctl start docker

# 设置 Docker 开机自启
sudo systemctl enable docker

# 查看 Docker 服务状态
sudo systemctl status docker
```

### 2. 配置用户权限

为了避免每次使用 Docker 命令都需要 sudo，将当前用户添加到 docker 组：

```bash
# 添加用户到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行以下命令使更改生效
newgrp docker

# 验证组权限
groups $USER
```

### 3. 验证安装

```bash
# 查看 Docker 版本
docker --version

# 查看 Docker 详细信息
docker info

# 运行测试容器
docker run hello-world
```

如果看到类似以下输出，说明安装成功：

```text
Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.
```

## 配置镜像加速

为了加快镜像下载速度，特别是对于中国用户，可以配置镜像加速器。

```bash
# 创建 Docker 配置目录（如果不存在）
sudo mkdir -p /etc/docker

# 配置镜像加速器
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.ccs.tencentyun.com"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
EOF

# 重启 Docker 服务
sudo systemctl daemon-reload
sudo systemctl restart docker

# 验证配置
docker info | grep -A 10 "Registry Mirrors"
```

## 配置 Docker 守护进程

你可以通过编辑 `/etc/docker/daemon.json` 文件来配置 Docker 守护进程。

### 基本配置示例

```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2",
  "data-root": "/var/lib/docker",
  "exec-opts": ["native.cgroupdriver=systemd"],
  "live-restore": true,
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 64000,
      "Soft": 64000
    }
  }
}
```

### 应用配置更改

```bash
# 重新加载配置
sudo systemctl daemon-reload

# 重启 Docker 服务
sudo systemctl restart docker

# 验证配置
sudo docker info
```

## 升级 Docker

使用官方仓库安装的 Docker 可以轻松升级到最新版本：

```bash
# 更新包索引
sudo apt-get update

# 升级 Docker
sudo apt-get upgrade docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 或者直接安装最新版本
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

## 卸载 Docker

如果需要卸载 Docker，执行以下步骤：

```bash
# 卸载 Docker 软件包
sudo apt-get purge docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 删除 Docker 配置文件和数据
sudo rm -rf /var/lib/docker
sudo rm -rf /var/lib/containerd
sudo rm -rf /etc/docker

# 删除 Docker 用户组
sudo groupdel docker

# 清理未使用的依赖
sudo apt-get autoremove -y

# 清理包缓存
sudo apt-get clean
```

## 常见问题与解决方案

### 问题 1: 权限被拒绝

**症状**: 运行 Docker 命令时出现 "permission denied while trying to connect to the Docker daemon socket"。

**解决方案**:

```bash
# 将用户添加到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行
newgrp docker

# 如果问题仍然存在，检查 docker.sock 权限
sudo ls -l /var/run/docker.sock

# 修复权限
sudo chmod 666 /var/run/docker.sock
```

### 问题 2: 无法连接到 Docker 守护进程

**症状**: 出现 "Cannot connect to the Docker daemon" 错误。

**解决方案**:

```bash
# 检查 Docker 服务状态
sudo systemctl status docker

# 如果服务未运行，启动它
sudo systemctl start docker

# 查看服务日志
sudo journalctl -u docker.service -n 50

# 重启 Docker 服务
sudo systemctl restart docker
```

### 问题 3: 镜像下载速度慢

**症状**: 拉取镜像时速度很慢或连接超时。

**解决方案**:

```bash
# 配置国内镜像加速器
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com"
  ]
}
EOF

# 重启 Docker 服务
sudo systemctl daemon-reload
sudo systemctl restart docker
```

### 问题 4: 存储空间不足

**症状**: Docker 占用过多磁盘空间。

**解决方案**:

```bash
# 查看 Docker 磁盘使用情况
sudo docker system df

# 清理未使用的镜像、容器、网络和构建缓存
sudo docker system prune -a

# 清理所有未使用的数据
sudo docker system prune -a --volumes

# 清理特定类型的资源
sudo docker image prune -a
sudo docker container prune
sudo docker volume prune
sudo docker network prune
```

### 问题 5: 端口冲突

**症状**: 启动容器时出现 "port is already allocated" 错误。

**解决方案**:

```bash
# 查看已使用的端口
sudo netstat -tulpn | grep LISTEN

# 或者使用 ss 命令
sudo ss -tulpn | grep LISTEN

# 停止占用端口的容器
docker stop <container-name>

# 删除占用端口的容器
docker rm <container-name>

# 使用其他端口启动容器
docker run -d -p 8081:80 --name my-nginx nginx
```

### 问题 6: DNS 解析问题

**症状**: 容器内无法解析域名。

**解决方案**:

```bash
# 编辑 Docker 配置
sudo nano /etc/docker/daemon.json

# 添加 DNS 配置
{
  "dns": ["8.8.8.8", "8.8.4.4"]
}

# 重启 Docker 服务
sudo systemctl restart docker

# 验证 DNS 配置
docker run --rm alpine nslookup google.com
```

### 问题 7: WSL2 权限问题 (适用于 WSL2)

**症状**: 在 WSL2 中运行 Docker 时遇到权限问题。

**解决方案**:

```bash
# 在 Windows PowerShell 中以管理员身份运行
wsl --update

# 在 WSL2 中将用户添加到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行
newgrp docker
```

## 安全最佳实践

### 1. 使用非 root 用户

```bash
# 将用户添加到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行
newgrp docker
```

### 2. 限制 Docker 守护进程访问

```bash
# 编辑 systemd 服务文件
sudo systemctl edit docker

# 添加以下内容
[Service]
ExecStart=
ExecStart=/usr/bin/dockerd -H fd:// -H tcp://127.0.0.1:2375

# 重启服务
sudo systemctl daemon-reload
sudo systemctl restart docker
```

### 3. 启用内容信任

```bash
# 启用 Docker Content Trust
export DOCKER_CONTENT_TRUST=1

# 仅拉取经过验证的镜像
docker pull nginx:latest
```

### 4. 扫描镜像漏洞

```bash
# 使用 Docker Scout 扫描镜像
docker scout quickview nginx:latest

# 使用 Trivy 扫描镜像
trivy image nginx:latest
```

## 性能优化

### 1. 配置存储驱动

```bash
# 编辑 Docker 配置
sudo nano /etc/docker/daemon.json

# 添加存储驱动配置
{
  "storage-driver": "overlay2",
  "storage-opts": [
    "overlay2.override_kernel_check=true"
  ]
}

# 重启 Docker 服务
sudo systemctl restart docker
```

### 2. 限制日志大小

```bash
# 编辑 Docker 配置
sudo nano /etc/docker/daemon.json

# 添加日志配置
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}

# 重启 Docker 服务
sudo systemctl restart docker
```

### 3. 配置资源限制

```bash
# 创建具有资源限制的容器
docker run -d \
  --name limited-container \
  --memory="512m" \
  --memory-swap="1g" \
  --cpus="1.0" \
  --pids-limit 100 \
  nginx
```

## 下一步

安装完成后，你可以：

1. 📚 阅读 [Docker 基础概念](/docs/tutorials/introduction)
2. 🔧 学习 [Docker 常用命令](/docs/tutorials/commands/)
3. 🚀 尝试 [运行第一个容器](/docs/usage/containers/run)
4. 🎯 查看 [实战案例](/docs/cases/)

:::tip 提示

安装完成后，建议运行 `docker run hello-world` 验证安装是否成功，然后尝试运行一些实用容器如 Nginx、Redis 等，以便熟悉 Docker 的基本操作。

:::

:::info Docker 版本

本指南适用于 Docker 24.0 及以上版本。如果你需要安装特定版本，可以使用 `apt-cache madison docker-ce` 查看可用版本，然后使用 `sudo apt-get install docker-ce=<VERSION>` 安装指定版本。

:::

:::warning 注意

在生产环境中，建议：

1. 使用官方仓库安装方法
2. 定期更新 Docker 到最新稳定版本
3. 配置日志轮转和监控
4. 实施安全加固措施
5. 定期备份重要数据

:::

## 其他资源

- [Docker 官方文档](https://docs.docker.com/engine/install/ubuntu/)
- [Docker Hub](https://hub.docker.com/)
- [Docker GitHub](https://github.com/docker/docker-ce)
- [Ubuntu Docker 安装指南](https://ubuntu.com/tutorials/install-docker-on-ubuntu)