---
id: intel
title: 在 Intel 芯片的 macOS 上安装 Docker
sidebar_label: Intel 芯片
description: 在 Intel 芯片的 macOS 系统上安装 Docker Desktop 的详细指南
---

# 在 Intel 芯片的 macOS 上安装 Docker Desktop

本指南将帮助你在 Intel 芯片的 macOS 系统上安装和配置 Docker Desktop。Docker Desktop 是 macOS 上的 Docker 官方桌面应用，提供了图形化界面和完整的容器管理功能。

## 系统要求

### macOS 版本要求

Docker Desktop for Mac (Intel 芯片) 支持以下 macOS 版本：

- **Sonoma** (14)
- **Ventura** (13)
- **Monterey** (12)
- **Big Sur** (11)

### 硬件要求

| 组件 | 要求 |
|------|------|
| **处理器** | Intel 处理器（Core i3 或更高） |
| **内存** | 至少 4GB RAM（推荐 8GB 或更多） |
| **磁盘空间** | 至少 4GB 可用空间（推荐 20GB 或更多） |
| **网络** | 稳定的互联网连接 |

### 虚拟化要求

- macOS 内置 Hypervisor.framework，无需额外配置
- 确保 Mac 支持虚拟化功能
- 系统偏好设置中"安全性与隐私"应允许虚拟化

## 准备工作

### 1. 更新 macOS

确保你的 macOS 系统是最新版本：

```bash
# 检查当前 macOS 版本
sw_vers

# 通过系统偏好设置或 App Store 更新 macOS
```

### 2. 卸载旧版本

如果系统中已安装旧版本的 Docker，请先卸载：

```bash
# 停止 Docker Desktop
killall Docker

# 运行 Docker Desktop 自带的卸载程序
# /Applications/Docker.app/Contents/MacOS/uninstall

# 或者手动删除
sudo rm -rf /Applications/Docker.app
sudo rm -rf /usr/local/bin/docker
sudo rm -rf /usr/local/bin/docker-compose
sudo rm -rf /usr/local/bin/docker-machine
sudo rm -rf /usr/local/bin/docker-credential-osxkeychain
sudo rm -rf /usr/local/etc/docker
sudo rm -rf ~/.docker
sudo rm -rf ~/Library/Containers/com.docker.docker
```

## 下载 Docker Desktop

### 官方下载

1. 访问 [Docker Desktop 官方下载页面](https://www.docker.com/products/docker-desktop/)
2. 选择 "Mac with Intel chip"
3. 点击 "Download for Mac - Intel chip"

### 使用命令行下载

```bash
# 创建下载目录
mkdir -p ~/Downloads/docker
cd ~/Downloads/docker

# 使用 curl 下载最新版本
curl -L -o Docker.dmg "https://desktop.docker.com/mac/main/amd64/Docker.dmg"

# 使用 wget 下载（如果已安装）
wget -O Docker.dmg "https://desktop.docker.com/mac/main/amd64/Docker.dmg"
```

## 安装 Docker Desktop

### 图形界面安装

1. **打开下载的 DMG 文件**

   双击下载的 `Docker.dmg` 文件

2. **拖拽到应用程序文件夹**

   将 Docker 图标拖拽到"应用程序"文件夹

3. **启动 Docker Desktop**

   从"启动台"或"应用程序"文件夹打开 Docker

4. **完成初始配置**

   首次启动时，按照屏幕提示完成设置：
   - 阅读 Docker 服务协议
   - 登录或创建 Docker 账号（可选）
   - 配置 Docker 首选项

### 命令行安装

```bash
# 挂载 DMG 文件
hdiutil attach ~/Downloads/docker/Docker.dmg

# 复制到应用程序文件夹
sudo cp -R /Volumes/Docker/Docker.app /Applications/

# 卸载 DMG 文件
hdiutil detach /Volumes/Docker

# 启动 Docker Desktop
open /Applications/Docker.app
```

## 初始配置

### 1. Docker Desktop 首选项

首次启动 Docker Desktop 后，打开首选项进行配置：

```bash
# 通过命令行打开 Docker Desktop 首选项
open -a Docker --args --preferences
```

#### 通用设置

- **自动启动**: 开机自动启动 Docker Desktop
- **自动更新检查**: 自动检查更新
- **自动发送使用统计**: 帮助改进 Docker

#### 资源设置

1. 打开 Docker Desktop 首选项
2. 选择"Resources"
3. 配置以下资源：

**内存限制**:
```json
{
  "memoryMiB": 8192  // 8GB RAM
}
```

**CPU 限制**:
```json
{
  "cpuCount": 4  // 4 个 CPU 核心
}
```

**磁盘空间**:
```json
{
  "diskSizeMiB": 51200  // 50GB
}
```

### 2. 配置共享文件夹

1. 打开 Docker Desktop 首选项
2. 选择"Resources" → "File sharing"
3. 添加要共享的文件夹
4. 设置适当的访问权限

### 3. 配置代理（如果需要）

1. 打开 Docker Desktop 首选项
2. 选择"Resources" → "Proxies"
3. 配置 HTTP 和 HTTPS 代理

示例：

```json
{
  "http": "http://proxy.example.com:8080",
  "https": "http://proxy.example.com:8080",
  "noProxy": "localhost,127.0.0.1"
}
```

### 4. 配置镜像加速（中国用户）

1. 打开 Docker Desktop 首选项
2. 选择"Docker Engine"
3. 添加以下配置：

```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.ccs.tencentyun.com"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

4. 点击"Apply & Restart"应用更改

### 5. 配置 Kubernetes（可选）

Docker Desktop 内置了单节点 Kubernetes 集群。

#### 启用 Kubernetes

1. 打开 Docker Desktop 首选项
2. 选择"Kubernetes"
3. 勾选"Enable Kubernetes"
4. 点击"Apply & Restart"
5. 等待 Kubernetes 集群启动

#### 验证 Kubernetes

```bash
# 查看 Kubernetes 状态
kubectl cluster-info

# 查看节点
kubectl get nodes

# 查看所有命名空间
kubectl get namespaces

# 部署测试应用
kubectl create deployment nginx --image=nginx
kubectl expose deployment nginx --port=80 --type=NodePort
kubectl get services
```

## 验证安装

### 1. 检查 Docker 版本

在终端中运行：

```bash
# 查看 Docker 版本
docker --version

# 查看 Docker Compose 版本
docker-compose --version

# 查看 Docker 详细信息
docker info
```

### 2. 运行测试容器

```bash
# 运行 Hello World 容器
docker run hello-world

# 运行 Nginx 容器
docker run -d -p 80:80 --name webserver nginx

# 查看运行的容器
docker ps

# 访问 Nginx
open http://localhost

# 停止容器
docker stop webserver

# 删除容器
docker rm webserver
```

### 3. 测试 Docker Compose

```bash
# 创建测试目录
mkdir ~/docker-test && cd ~/docker-test

# 创建 docker-compose.yml 文件
cat > docker-compose.yml << EOF
version: '3.8'
services:
  web:
    image: nginx:latest
    ports:
      - "8080:80"
  redis:
    image: redis:alpine
EOF

# 启动服务
docker-compose up -d

# 查看运行的服务
docker-compose ps

# 停止服务
docker-compose down
```

## 高级配置

### 1. 使用守护进程配置文件

Docker Desktop 的守护进程配置文件位于：

```
~/.docker/daemon.json
```

#### 常用配置示例

```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2",
  "exec-opts": ["native.cgroupdriver=systemd"],
  "live-restore": true,
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 64000,
      "Soft": 64000
    }
  },
  "features": {
    "buildkit": true
  },
  "builder": {
    "gc": {
      "enabled": true,
      "defaultKeepStorage": "10GB"
    }
  }
}
```

### 2. 配置 Shell 补全

#### Bash 补全

```bash
# 安装 Bash 补全
curl -L https://raw.githubusercontent.com/docker/docker-ce/master/components/cli/contrib/completion/bash/docker -o /usr/local/etc/bash_completion.d/docker

# 或使用 Homebrew 安装
brew install bash-completion

# 在 ~/.bash_profile 中添加
if [ -f $(brew --prefix)/etc/bash_completion ]; then
    . $(brew --prefix)/etc/bash_completion
fi
```

#### Zsh 补全

```bash
# 安装 Zsh 补全
curl -L https://raw.githubusercontent.com/docker/docker-ce/master/components/cli/contrib/completion/zsh/_docker -o ~/.zsh/completion/_docker

# 或使用 Homebrew 安装
brew install zsh-completions

# 在 ~/.zshrc 中添加
fpath=(/usr/local/share/zsh-completions $fpath)
autoload -U compinit && compinit
```

### 3. 配置环境变量

#### Shell 配置文件

在 `~/.bash_profile` 或 `~/.zshrc` 中添加：

```bash
# Docker 相关环境变量
export DOCKER_CLI_EXPERIMENTAL=enabled
export DOCKER_BUILDKIT=1
export COMPOSE_DOCKER_CLI_BUILD=1

# Docker Hub 认证
export DOCKER_ID_USER="your-username"
```

#### 应用环境变量

```bash
# 重新加载 Shell 配置
source ~/.bash_profile
# 或
source ~/.zshrc

# 验证环境变量
echo $DOCKER_CLI_EXPERIMENTAL
echo $DOCKER_BUILDKIT
```

### 4. 使用 Docker Contexts

Docker Contexts 允许你在不同的 Docker 环境之间切换。

```bash
# 列出当前 contexts
docker context ls

# 创建新 context
docker context create my-context --docker "unix:///var/run/docker.sock"

# 切换 context
docker context use my-context

# 删除 context
docker context rm my-context

# 查看当前 context
docker context inspect current
```

### 5. 配置 BuildKit

BuildKit 是 Docker 的下一代构建工具，提供更好的性能和功能。

```bash
# 启用 BuildKit（全局）
export DOCKER_BUILDKIT=1

# 或在 Docker Desktop 首选项中启用
# 选择 "Docker Engine" → 添加：
{
  "features": {
    "buildkit": true
  }
}

# 使用 BuildKit 构建
docker build --build-arg BUILDKIT_INLINE_CACHE=1 -t myapp .
```

## 常见问题与解决方案

### 问题 1: Docker Desktop 无法启动

**症状**: Docker Desktop 启动后立即关闭。

**解决方案**:

```bash
# 检查日志
cat ~/Library/Containers/com.docker.docker/Data/log/main.log

# 重置 Docker Desktop
rm -rf ~/Library/Containers/com.docker.docker
open /Applications/Docker.app
```

### 问题 2: 权限被拒绝

**症状**: 运行 Docker 命令时出现权限错误。

**解决方案**:

```bash
# 确保 Docker Desktop 正在运行
open /Applications/Docker.app

# 检查 Docker 套接字权限
ls -l /var/run/docker.sock

# 重新启动 Docker Desktop
killall Docker
open /Applications/Docker.app
```

### 问题 3: 内存不足

**症状**: 容器运行缓慢或崩溃。

**解决方案**:

1. 增加 Docker Desktop 分配的内存
2. 在"Docker Desktop" → "Preferences" → "Resources" → "Memory"中调整内存

```bash
# 查看当前内存使用
docker stats --no-stream

# 查看系统内存
vm_stat
```

### 问题 4: 磁盘空间不足

**症状**: Docker 占用过多磁盘空间。

**解决方案**:

```bash
# 查看 Docker 磁盘使用情况
docker system df

# 清理未使用的镜像、容器、网络和构建缓存
docker system prune -a

# 清理所有未使用的数据
docker system prune -a --volumes

# 清理特定类型的资源
docker image prune -a
docker container prune
docker volume prune
docker network prune

# 使用 Docker Desktop 清理
# Docker Desktop → Preferences → Resources → Disk image size → Clean / Purge
```

### 问题 5: 网络问题

**症状**: 容器无法访问网络或主机。

**解决方案**:

```bash
# 重启 Docker Desktop
killall Docker
sleep 5
open /Applications/Docker.app

# 检查网络设置
ifconfig | grep -A 1 docker0

# 重置网络（需要重启 Docker Desktop）
# Docker Desktop → Preferences → Resources → Network
```

### 问题 6: 端口冲突

**症状**: 启动容器时出现"port is already allocated"错误。

**解决方案**:

```bash
# 查看已使用的端口
lsof -i :80
# 或
netstat -an | grep :80

# 停止占用端口的容器
docker ps -a
docker stop <container-name>
docker rm <container-name>

# 使用其他端口启动容器
docker run -d -p 8081:80 --name my-nginx nginx
```

### 问题 7: 镜像下载失败

**症状**: 拉取镜像时连接超时或失败。

**解决方案**:

1. 配置国内镜像加速器
2. 检查网络连接
3. 尝试使用其他网络

```json
// Docker Engine 配置
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com"
  ]
}
```

### 问题 8: macOS 防火墙阻止

**症状**: 防火墙阻止 Docker 访问网络。

**解决方案**:

```bash
# 打开系统偏好设置
# 安全性与隐私 → 防火墙 → 防火墙选项
# 添加 /Applications/Docker.app 到允许列表
```

### 问题 9: Docker Compose 版本问题

**症状**: docker-compose 命令不存在或版本过低。

**解决方案**:

```bash
# 使用新版 docker compose 命令
docker compose version

# 或安装独立版 docker-compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# 验证安装
docker-compose --version
```

### 问题 10: 共享文件夹权限问题

**症状**: 容器无法访问共享文件夹中的文件。

**解决方案**:

1. 打开 Docker Desktop 首选项
2. 选择"Resources" → "File sharing"
3. 重新添加共享文件夹
4. 重启 Docker Desktop

## 性能优化

### 1. 优化资源分配

```json
// Docker Desktop 首选项配置
{
  "memoryMiB": 8192,      // 8GB 内存
  "cpuCount": 4,           // 4 CPU 核心
  "swapMiB": 2048,         // 2GB 交换空间
  "diskSizeMiB": 51200     // 50GB 磁盘空间
}
```

### 2. 优化存储性能

```json
{
  "storage-driver": "overlay2",
  "storage-opts": [
    "overlay2.override_kernel_check=true"
  ]
}
```

### 3. 优化日志配置

```json
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

### 4. 使用 BuildKit 加速构建

```bash
# 启用 BuildKit
export DOCKER_BUILDKIT=1

# 使用 BuildKit 构建
docker build --progress=plain -t myapp .
```

### 5. 优化容器启动速度

```bash
# 使用轻量级基础镜像
FROM alpine:latest

# 最小化层数
RUN apk add --no-cache python3 && \
    pip3 install --no-cache-dir flask

# 使用多阶段构建
FROM builder AS build
RUN ...

FROM alpine:latest
COPY --from=build /app /app
```

## 安全最佳实践

### 1. 使用非 root 用户

```dockerfile
# Dockerfile 示例
FROM alpine:latest

# 创建非 root 用户
RUN adduser -D appuser
USER appuser

# 设置工作目录
WORKDIR /home/appuser

# 复制文件
COPY --chown=appuser . .

# 运行应用
CMD ["python", "app.py"]
```

### 2. 使用 Docker Content Trust

```bash
# 启用 Docker Content Trust
export DOCKER_CONTENT_TRUST=1

# 仅拉取经过验证的镜像
docker pull nginx:latest
```

### 3. 扫描镜像漏洞

```bash
# 使用 Docker Scout 扫描镜像
docker scout quickview nginx:latest

# 使用 Trivy 扫描镜像
trivy image nginx:latest

# 安装 Trivy
brew install trivy
```

### 4. 限制容器权限

```bash
# 运行容器时限制权限
docker run -d \
  --read-only \
  --cap-drop ALL \
  --security-opt no-new-privileges \
  --user 1000:1000 \
  nginx
```

### 5. 使用最小化镜像

```dockerfile
# 使用 Alpine 基础镜像
FROM alpine:latest

# 或使用 Distroless 镜像
FROM gcr.io/distroless/python3
```

## 升级 Docker Desktop

### 手动升级

1. 从 Docker 官网下载最新版本
2. 运行安装程序
3. 覆盖现有安装

```bash
# 下载最新版本
curl -L -o Docker.dmg "https://desktop.docker.com/mac/main/amd64/Docker.dmg"

# 挂载 DMG 文件
hdiutil attach Docker.dmg

# 覆盖安装
sudo cp -R /Volumes/Docker/Docker.app /Applications/

# 重启 Docker Desktop
killall Docker && open /Applications/Docker.app
```

### 自动升级

Docker Desktop 会自动检查更新：

1. 打开 Docker Desktop
2. 点击"Preferences" → "General"
3. 勾选"Automatically check for updates"

## 卸载 Docker Desktop

### 完全卸载

```bash
# 停止 Docker Desktop
killall Docker

# 运行卸载程序
/Applications/Docker.app/Contents/MacOS/uninstall

# 或手动删除
sudo rm -rf /Applications/Docker.app
sudo rm -rf /usr/local/bin/docker
sudo rm -rf /usr/local/bin/docker-compose
sudo rm -rf ~/.docker
sudo rm -rf ~/Library/Containers/com.docker.docker
sudo rm -rf ~/Library/Application\ Support/Docker\ Desktop
sudo rm -rf ~/Library/Preferences/com.docker.docker.plist
sudo rm -rf ~/Library/Group\ Containers/group.com.docker
sudo rm -rf /Library/PrivilegedHelperTools/com.docker.vmnetd

# 清理网络设置
sudo rm -rf /Library/LaunchDaemons/com.docker.vmnetd.plist
```

### 使用脚本卸载

```bash
# 创建卸载脚本
cat > uninstall-docker.sh << 'EOF'
#!/bin/bash
# 停止 Docker Desktop
killall Docker

# 删除应用
sudo rm -rf /Applications/Docker.app

# 删除命令行工具
sudo rm -rf /usr/local/bin/docker
sudo rm -rf /usr/local/bin/docker-compose

# 删除配置文件
sudo rm -rf ~/.docker
sudo rm -rf ~/Library/Containers/com.docker.docker
sudo rm -rf ~/Library/Application\ Support/Docker\ Desktop
sudo rm -rf ~/Library/Preferences/com.docker.docker.plist
sudo rm -rf ~/Library/Group\ Containers/group.com.docker
sudo rm -rf /Library/PrivilegedHelperTools/com.docker.vmnetd

echo "Docker Desktop has been completely uninstalled."
EOF

# 使脚本可执行
chmod +x uninstall-docker.sh

# 运行卸载脚本
./uninstall-docker.sh
```

## 下一步

安装完成后，你可以：

1. 📚 阅读 [Docker 基础概念](/docs/tutorials/introduction)
2. 🔧 学习 [Docker 常用命令](/docs/tutorials/commands/)
3. 🚀 尝试 [运行第一个容器](/docs/usage/containers/run)
4. 🎯 查看 [实战案例](/docs/cases/)
5. 🐳 了解 [Apple Silicon 版本](./apple-silicon)

:::tip 提示

安装完成后，建议运行 `docker run hello-world` 验证安装是否成功，然后尝试运行一些实用容器如 Nginx、Redis 等，以便熟悉 Docker 的基本操作。

:::

:::info Docker 版本

本指南适用于 Docker Desktop 4.25.0 及以上版本。如果你需要安装特定版本，可以访问 [Docker Desktop 版本历史](https://docs.docker.com/desktop/release-notes/mac/)。

:::

:::warning 注意

在使用 Docker Desktop for Mac 时，请注意：

1. 确保系统满足最低要求
2. 定期更新 Docker Desktop 到最新版本
3. 配置适当的资源限制
4. 定期清理未使用的资源
5. 使用国内镜像加速器以提高下载速度

:::

## 其他资源

- [Docker Desktop 官方文档](https://docs.docker.com/desktop/mac/)
- [Docker Hub](https://hub.docker.com/)
- [Docker Desktop 下载](https://www.docker.com/products/docker-desktop/)
- [Docker GitHub](https://github.com/docker/docker-ce)