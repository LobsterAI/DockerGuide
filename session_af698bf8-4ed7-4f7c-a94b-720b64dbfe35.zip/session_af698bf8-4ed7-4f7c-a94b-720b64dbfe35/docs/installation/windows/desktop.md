---
id: desktop
title: Windows 上安装 Docker Desktop
sidebar_label: Docker Desktop
description: 在 Windows 系统上安装 Docker Desktop 的详细指南，包括 WSL2 后端配置和常见问题解决
---

# 在 Windows 上安装 Docker Desktop

本指南将帮助你在 Windows 10/11 系统上安装和配置 Docker Desktop。Docker Desktop 是 Windows 上的 Docker 官方桌面应用，提供了图形化界面和完整的容器管理功能。

## 系统要求

### Windows 版本要求

Docker Desktop 支持 Windows 10 和 Windows 11 的以下版本：

- **Windows 11**
  - Windows 11 21H2 或更高版本（家庭版、专业版、企业版、教育版）
  
- **Windows 10**
  - Windows 10 22H2（版本 19045）或更高版本
  - 家庭版、专业版、企业版、教育版
  - 家庭版需要启用 WSL 2

### 硬件要求

| 组件 | 要求 |
|------|------|
| **处理器** | 64位处理器，支持二级地址转换（SLAT） |
| **内存** | 至少 4GB RAM（推荐 8GB 或更多） |
| **磁盘空间** | 至少 10GB 可用空间（推荐 20GB 或更多） |
| **虚拟化** | BIOS 中启用虚拟化支持 |
| **Hyper-V** | Windows 专业版/企业版需要启用 Hyper-V |

### WSL 2 要求

- Windows 10 版本 1903 或更高（仅限内部版本 18362）
- Windows 10 版本 2004 或更高（内部版本 19041 或更高）
- Windows 11（所有版本）

## 准备工作

### 1. 启用 WSL 2

#### 使用 PowerShell 启用 WSL 2

以管理员身份打开 PowerShell，运行以下命令：

```powershell
# 启用适用于 Linux 的 Windows 子系统和虚拟机平台
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart

# 重启计算机
Restart-Computer
```

#### 使用命令提示符（CMD）启用 WSL 2

以管理员身份打开命令提示符，运行以下命令：

```cmd
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart
```

### 2. 设置 WSL 2 为默认版本

计算机重启后，以管理员身份打开 PowerShell，运行：

```powershell
# 将 WSL 2 设置为默认版本
wsl --set-default-version 2

# 验证 WSL 版本
wsl --list --verbose
```

### 3. 启用 Hyper-V（专业版/企业版）

#### 使用 PowerShell 启用 Hyper-V

```powershell
# 启用 Hyper-V
Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All

# 重启计算机
Restart-Computer
```

#### 使用控制面板启用 Hyper-V

1. 打开"控制面板" → "程序和功能"
2. 点击"启用或关闭 Windows 功能"
3. 勾选以下选项：
   - Hyper-V
   - Hyper-V 管理工具
   - Hyper-V 平台
4. 点击"确定"并重启计算机

### 4. BIOS 中启用虚拟化

如果虚拟化功能未启用，需要在 BIOS 中进行设置：

1. 重启计算机并进入 BIOS（通常按 F2、F10、Del 或 F12 键）
2. 找到"虚拟化"或"Intel VT-x/AMD-V"选项
3. 启用虚拟化功能
4. 保存并退出 BIOS

### 5. 验证虚拟化状态

打开"任务管理器"，切换到"性能"选项卡，查看"CPU"部分，确认"虚拟化"已启用。

## 下载 Docker Desktop

### 官方下载

1. 访问 [Docker Desktop 官方下载页面](https://www.docker.com/products/docker-desktop/)
2. 点击"Download for Windows"
3. 选择适合你系统的版本（Windows 10 或 Windows 11）

### 直接下载链接

```powershell
# 使用 PowerShell 下载最新版本
$webClient = New-Object System.Net.WebClient
$webClient.DownloadFile(
    "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe",
    "DockerDesktopInstaller.exe"
)
```

## 安装 Docker Desktop

### 标准安装步骤

1. **运行安装程序**

   双击下载的 `DockerDesktopInstaller.exe` 文件

2. **选择安装选项**

   在安装向导中，勾选以下选项：
   
   - [x] 使用 WSL 2 代替 Hyper-V（推荐）
   - [x] 将快捷方式添加到桌面
   - [x] 将快捷方式添加到启动文件夹

3. **完成安装**

   点击"Ok"按钮开始安装，等待安装完成

4. **重启计算机**

   安装完成后，重启计算机

5. **启动 Docker Desktop**

   重启后，从"开始"菜单启动 Docker Desktop

### 静默安装

对于企业部署或自动化安装，可以使用静默安装模式：

```powershell
# 静默安装 Docker Desktop
Start-Process -FilePath "DockerDesktopInstaller.exe" -ArgumentList "install --quiet" -Wait

# 静默安装并启用 WSL 2 后端
Start-Process -FilePath "DockerDesktopInstaller.exe" -ArgumentList "install --quiet --backend=wsl-2" -Wait
```

### 命令行参数

Docker Desktop 安装程序支持以下命令行参数：

| 参数 | 说明 |
|------|------|
| `install` | 执行安装 |
| `--quiet` | 静默模式 |
| `--backend=wsl-2` | 强制使用 WSL 2 后端 |
| `--backend=hyper-v` | 强制使用 Hyper-V 后端 |
| `--accept-license` | 接受许可协议 |
| `--no-windows-containers` | 不安装 Windows 容器功能 |

示例：

```powershell
# 完整的静默安装命令
DockerDesktopInstaller.exe install --quiet --backend=wsl-2 --accept-license --no-windows-containers
```

## 初始配置

### 1. 首次启动

首次启动 Docker Desktop 时，会显示欢迎界面：

1. 接受 Docker 服务协议
2. 登录或创建 Docker 账号（可选）
3. 完成初始设置

### 2. 配置 WSL 2 集成

#### 启用 WSL 2 集成

1. 打开 Docker Desktop 设置
2. 进入"Resources" → "WSL Integration"
3. 启用"Enable integration with my default WSL distro"
4. 选择要集成的 WSL 发行版（Ubuntu、Debian 等）

#### 验证 WSL 2 集成

```powershell
# 查看集成的 WSL 发行版
wsl --list --verbose

# 在 WSL 中运行 Docker 命令
wsl
docker --version
```

### 3. 配置资源限制

在 Docker Desktop 设置中，可以配置以下资源：

#### 内存限制

1. 打开 Docker Desktop 设置
2. 进入"Resources" → "Advanced"
3. 设置"Memory"滑块（推荐 4GB-8GB）

#### 处理器限制

1. 在"Resources" → "Advanced"中
2. 设置"CPUs"滑块（推荐 2-4 核）

#### 磁盘空间

1. 在"Resources" → "Disk image size"中
2. 设置磁盘镜像大小（推荐 20GB-50GB）

### 4. 配置共享驱动

1. 打开 Docker Desktop 设置
2. 进入"Resources" → "File sharing"
3. 添加要共享的驱动器（如 C:, D:）
4. 授予文件系统访问权限

### 5. 配置代理（如果需要）

1. 打开 Docker Desktop 设置
2. 进入"Resources" → "Proxies"
3. 配置 HTTP 和 HTTPS 代理

示例：

```json
{
  "http": "http://proxy.example.com:8080",
  "https": "http://proxy.example.com:8080",
  "noProxy": "localhost,127.0.0.1"
}
```

### 6. 配置镜像加速（中国用户）

1. 打开 Docker Desktop 设置
2. 进入"Docker Engine"
3. 添加以下配置：

```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.ccs.tencentyun.com"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

4. 点击"Apply & Restart"应用更改

## 验证安装

### 1. 检查 Docker 版本

在 PowerShell 中运行：

```powershell
# 查看 Docker 版本
docker --version

# 查看 Docker 详细信息
docker info
```

### 2. 运行测试容器

```powershell
# 运行 Hello World 容器
docker run hello-world

# 运行 Nginx 容器
docker run -d -p 80:80 --name webserver nginx

# 查看运行的容器
docker ps

# 停止容器
docker stop webserver

# 删除容器
docker rm webserver
```

### 3. 测试 WSL 2 集成

```powershell
# 启动 WSL
wsl

# 在 WSL 中运行 Docker
docker run hello-world

# 退出 WSL
exit
```

## 高级配置

### 1. 使用守护进程配置文件

Docker Desktop 的守护进程配置文件位于：

```
%USERPROFILE%\.docker\daemon.json
```

#### 常用配置示例

```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2",
  "data-root": "/var/lib/docker",
  "exec-opts": ["native.cgroupdriver=systemd"],
  "live-restore": true,
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 64000,
      "Soft": 64000
    }
  },
  "features": {
    "buildkit": true
  },
  "builder": {
    "gc": {
      "enabled": true,
      "defaultKeepStorage": "10GB"
    }
  }
}
```

### 2. 配置 Kubernetes

Docker Desktop 内置了单节点 Kubernetes 集群。

#### 启用 Kubernetes

1. 打开 Docker Desktop 设置
2. 进入"Kubernetes"
3. 勾选"Enable Kubernetes"
4. 点击"Apply & Restart"
5. 等待 Kubernetes 集群启动

#### 验证 Kubernetes

```powershell
# 查看 Kubernetes 状态
kubectl cluster-info

# 查看节点
kubectl get nodes

# 查看所有命名空间
kubectl get namespaces

# 部署测试应用
kubectl create deployment nginx --image=nginx
kubectl expose deployment nginx --port=80 --type=NodePort
kubectl get services
```

### 3. 配置 Docker Compose

Docker Desktop 自动包含 Docker Compose。

```powershell
# 查看 Docker Compose 版本
docker-compose --version

# 或使用新语法
docker compose version

# 创建 docker-compose.yml 文件
@"
version: '3.8'
services:
  web:
    image: nginx:latest
    ports:
      - "80:80"
  db:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: example
"@ | Out-File -FilePath docker-compose.yml

# 启动服务
docker-compose up -d

# 查看运行的服务
docker-compose ps

# 停止服务
docker-compose down
```

## 常见问题与解决方案

### 问题 1: WSL 2 安装失败

**症状**: 出现"WSL 2 installation is incomplete"错误。

**解决方案**:

```powershell
# 更新 WSL 内核
wsl --update

# 重启 WSL
wsl --shutdown

# 重新启动
wsl
```

### 问题 2: Hyper-V 冲突

**症状**: Docker Desktop 无法启动，提示 Hyper-V 冲突。

**解决方案**:

1. 禁用冲突的虚拟化软件（如 VirtualBox、VMware）
2. 或使用 WSL 2 后端而不是 Hyper-V

```powershell
# 禁用 Hyper-V
bcdedit /set hypervisorlaunchtype off

# 重新启用 Hyper-V
bcdedit /set hypervisorlaunchtype auto
```

### 问题 3: 权限被拒绝

**症状**: 运行 Docker 命令时出现权限错误。

**解决方案**:

```powershell
# 以管理员身份运行 PowerShell
# 重新安装 Docker Desktop
Start-Process -FilePath "DockerDesktopInstaller.exe" -Verb RunAs
```

### 问题 4: 虚拟化未启用

**症状**: 提示"Virtualization is disabled in BIOS"。

**解决方案**:

1. 进入 BIOS 启用虚拟化
2. 确保 Hyper-V 功能已启用
3. 在 PowerShell 中运行：

```powershell
# 启用 Hyper-V
Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All
```

### 问题 5: 内存不足

**症状**: 容器运行缓慢或崩溃。

**解决方案**:

1. 增加 Docker Desktop 分配的内存
2. 在"Docker Desktop" → "Settings" → "Resources" → "Advanced"中调整内存

### 问题 6: 网络问题

**症状**: 容器无法访问网络或主机。

**解决方案**:

```powershell
# 重启 Docker Desktop
Get-Process "*Docker Desktop*" | Stop-Process -Force

# 重置网络适配器
netsh winsock reset
netsh int ip reset
ipconfig /release
ipconfig /renew

# 重新启动 Docker Desktop
Start-Process "C:\Program Files\Docker\Docker\Docker Desktop.exe"
```

### 问题 7: 磁盘空间不足

**症状**: Docker 占用过多磁盘空间。

**解决方案**:

```powershell
# 查看 Docker 磁盘使用情况
docker system df

# 清理未使用的资源
docker system prune -a

# 清理所有未使用的数据
docker system prune -a --volumes

# 清理特定类型的资源
docker image prune -a
docker container prune
docker volume prune
docker network prune
```

### 问题 8: Docker Desktop 无法启动

**症状**: Docker Desktop 启动后立即关闭。

**解决方案**:

```powershell
# 重置 Docker Desktop 数据
Remove-Item -Path "$env:APPDATA\Docker" -Recurse -Force
Remove-Item -Path "$env:LOCALAPPDATA\Docker" -Recurse -Force

# 重新启动 Docker Desktop
Start-Process "C:\Program Files\Docker\Docker\Docker Desktop.exe"
```

### 问题 9: 端口冲突

**症状**: 启动容器时出现"port is already allocated"错误。

**解决方案**:

```powershell
# 查看已使用的端口
netstat -ano | findstr :80

# 停止占用端口的容器
docker ps -a
docker stop <container-name>
docker rm <container-name>

# 使用其他端口启动容器
docker run -d -p 8081:80 --name my-nginx nginx
```

### 问题 10: 镜像下载失败

**症状**: 拉取镜像时连接超时或失败。

**解决方案**:

1. 配置国内镜像加速器
2. 检查网络连接
3. 尝试使用其他网络

```json
// Docker Engine 配置
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com"
  ]
}
```

## 性能优化

### 1. 优化资源分配

```json
// Docker Desktop 设置
{
  "memory": 8192,      // 8GB 内存
  "cpus": 4,           // 4 CPU 核心
  "swapMiB": 2048,     // 2GB 交换空间
  "diskSizeMiB": 51200  // 50GB 磁盘空间
}
```

### 2. 优化存储性能

```json
{
  "storage-driver": "overlay2",
  "storage-opts": [
    "overlay2.override_kernel_check=true"
  ]
}
```

### 3. 优化日志配置

```json
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

### 4. 使用 BuildKit 加速构建

```json
{
  "features": {
    "buildkit": true
  }
}
```

## 安全最佳实践

### 1. 使用 Docker Content Trust

```powershell
# 启用 Docker Content Trust
$env:DOCKER_CONTENT_TRUST = 1

# 仅拉取经过验证的镜像
docker pull nginx:latest
```

### 2. 扫描镜像漏洞

```powershell
# 使用 Docker Scout 扫描镜像
docker scout quickview nginx:latest

# 使用 Trivy 扫描镜像
trivy image nginx:latest
```

### 3. 配置访问控制

```powershell
# 配置 Docker daemon TLS
# 编辑 %USERPROFILE%\.docker\daemon.json
{
  "tls": true,
  "tlsverify": true,
  "tlscacert": "C:\\ProgramData\\docker\\certs.d\\ca.pem",
  "tlscert": "C:\\ProgramData\\docker\\certs.d\\server-cert.pem",
  "tlskey": "C:\\ProgramData\\docker\\certs.d\\server-key.pem",
  "hosts": ["tcp://0.0.0.0:2376"]
}
```

## 升级 Docker Desktop

### 手动升级

1. 从 Docker 官网下载最新版本
2. 运行安装程序
3. 覆盖现有安装

### 自动升级

Docker Desktop 会自动检查更新：

1. 打开 Docker Desktop
2. 点击"Settings" → "General"
3. 勾选"Always check for updates"

## 卸载 Docker Desktop

### 完全卸载

```powershell
# 停止 Docker Desktop
Get-Process "*Docker Desktop*" | Stop-Process -Force

# 卸载 Docker Desktop
& "C:\Program Files\Docker\Docker\Docker Desktop.exe" uninstall

# 删除 Docker 数据
Remove-Item -Path "$env:APPDATA\Docker" -Recurse -Force
Remove-Item -Path "$env:LOCALAPPDATA\Docker" -Recurse -Force
Remove-Item -Path "$env:PROGRAMDATA\Docker" -Recurse -Force

# 删除 WSL 发行版
wsl --unregister docker-desktop
wsl --unregister docker-desktop-data

# 重启计算机
Restart-Computer
```

## 下一步

安装完成后，你可以：

1. 📚 阅读 [Docker 基础概念](/docs/tutorials/introduction)
2. 🔧 学习 [Docker 常用命令](/docs/tutorials/commands/)
3. 🚀 尝试 [运行第一个容器](/docs/usage/containers/run)
4. 🎯 查看 [实战案例](/docs/cases/)
5. 🐳 了解 [WSL 2 后端配置](./wsl2)

:::tip 提示

安装完成后，建议运行 `docker run hello-world` 验证安装是否成功，然后尝试运行一些实用容器如 Nginx、Redis 等，以便熟悉 Docker 的基本操作。

:::

:::info Docker 版本

本指南适用于 Docker Desktop 4.25.0 及以上版本。如果你需要安装特定版本，可以访问 [Docker Desktop 版本历史](https://docs.docker.com/desktop/release-notes/)。

:::

:::warning 注意

在使用 Docker Desktop 时，请注意：

1. 确保系统满足最低要求
2. 在 BIOS 中启用虚拟化
3. 定期更新 Docker Desktop 到最新版本
4. 配置适当的资源限制
5. 定期清理未使用的资源

:::

## 其他资源

- [Docker Desktop 官方文档](https://docs.docker.com/desktop/windows/)
- [WSL 2 文档](https://docs.microsoft.com/en-us/windows/wsl/)
- [Docker Hub](https://hub.docker.com/)
- [Docker Desktop 下载](https://www.docker.com/products/docker-desktop/)