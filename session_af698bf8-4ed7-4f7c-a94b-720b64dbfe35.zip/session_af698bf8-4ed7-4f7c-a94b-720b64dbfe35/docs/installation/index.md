---
id: index
title: 安装指南概览
sidebar_label: 安装概览
description: Docker 安装完整指南，涵盖 Linux、Windows、macOS 等多个平台的安装方法和步骤
---

import DocCardList from '@theme/DocCardList';
import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

# Docker 安装指南

本指南将帮助你在各种操作系统上安装和配置 Docker。Docker 支持多个平台，包括 Linux、Windows 和 macOS。

## 系统要求

在开始安装之前，请确保你的系统满足以下基本要求：

### 最低要求

| 组件 | 要求 |
|------|------|
| **操作系统** | Ubuntu 20.04+, Debian 11+, Windows 10/11, macOS 11+ |
| **CPU** | 64位处理器，支持虚拟化 |
| **内存** | 至少 4GB RAM（推荐 8GB 或更多） |
| **磁盘空间** | 至少 20GB 可用空间 |
| **网络** | 稳定的互联网连接（用于下载镜像和包） |

### Linux 特定要求

- **内核版本**: 3.10 或更高
- **架构**: x86_64, arm64, s390x, ppc64le
- **存储驱动**: Overlay2（推荐）
- **Cgroup**: cgroup v1 或 v2

### Windows 特定要求

- **Windows 版本**: Windows 10/11 专业版、企业版或教育版
- **WSL 2**: 启用 WSL 2 功能
- **虚拟化**: BIOS 中启用虚拟化支持
- **Hyper-V**: 启用 Hyper-V 功能

### macOS 特定要求

- **macOS 版本**: Big Sur (11) 或更高版本
- **芯片架构**: Intel 或 Apple Silicon (M1/M2/M3)

## 安装选项

<DocCardList />

## 快速安装

### Linux 快速安装

如果你使用的是 Linux 系统，可以使用官方提供的便捷安装脚本：

```bash
# 下载并运行安装脚本
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 将当前用户添加到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行
newgrp docker
```

### Windows 快速安装

1. 下载 [Docker Desktop for Windows](https://www.docker.com/products/docker-desktop/)
2. 运行安装程序
3. 按照安装向导完成安装
4. 重启计算机
5. 启动 Docker Desktop

### macOS 快速安装

1. 下载 [Docker Desktop for Mac](https://www.docker.com/products/docker-desktop/)
2. 打开下载的 `.dmg` 文件
3. 将 Docker 拖拽到应用程序文件夹
4. 从应用程序启动 Docker
5. 按照提示完成初始配置

## 验证安装

安装完成后，运行以下命令验证 Docker 是否正确安装：

```bash
# 查看 Docker 版本信息
docker --version

# 查看详细的系统信息
docker info

# 运行测试容器
docker run hello-world
```

如果看到类似以下输出，说明安装成功：

```text
Hello from Docker!
This message shows that your installation appears to be working correctly.
```

## 安装前检查清单

在开始安装之前，请完成以下检查：

### Linux 系统

- [ ] 确认系统满足最低要求
- [ ] 更新系统软件包
- [ ] 移除旧版本的 Docker（如果已安装）
- [ ] 检查系统内核和存储驱动
- [ ] 确保有足够的磁盘空间

### Windows 系统

- [ ] 确认 Windows 版本兼容
- [ ] 启用 WSL 2 功能
- [ ] 在 BIOS 中启用虚拟化
- [ ] 关闭 Hyper-V 冲突的软件（如 VirtualBox）
- [ ] 确保有足够的磁盘空间

### macOS 系统

- [ ] 确认 macOS 版本兼容
- [ ] 检查芯片架构类型（Intel 或 Apple Silicon）
- [ ] 确保有足够的磁盘空间
- [ ] 关闭其他虚拟化软件

## 选择合适的安装方法

根据你的使用场景，选择最合适的安装方法：

### 开发环境

对于日常开发，推荐使用：

- **Linux**: 使用包管理器安装（apt、yum、dnf）
- **Windows**: 使用 Docker Desktop
- **macOS**: 使用 Docker Desktop

### 生产环境

对于生产部署，推荐：

- **Linux**: 使用官方仓库或包管理器
- **容器编排**: 考虑使用 Kubernetes 或 Docker Swarm
- **安全加固**: 参考安全配置指南

### 云服务器

对于云服务器部署：

- **AWS**: 使用 EC2 容器服务或 ECS
- **Azure**: 使用容器实例或 AKS
- **阿里云**: 使用容器服务或 ACK
- **腾讯云**: 使用容器服务或 TKE

## 安装步骤概览

### 1. 准备工作

```bash
# 更新系统（Ubuntu/Debian）
sudo apt-get update
sudo apt-get upgrade -y

# 更新系统（CentOS/RHEL）
sudo yum update -y

# 或
sudo dnf update -y
```

### 2. 安装 Docker

根据你的操作系统选择相应的安装方法：

- [Linux 安装](./linux/) - 详细的 Linux 安装指南
- [Windows 安装](./windows/) - 详细的 Windows 安装指南
- [macOS 安装](./macos/) - 详细的 macOS 安装指南

### 3. 配置 Docker

安装完成后，需要进行基本配置：

```bash
# 启动 Docker 服务
sudo systemctl start docker
sudo systemctl enable docker

# 配置镜像加速（可选）
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com"
  ]
}
EOF

# 重启 Docker 服务
sudo systemctl daemon-reload
sudo systemctl restart docker
```

### 4. 验证安装

```bash
# 运行测试容器
docker run hello-world

# 运行 Nginx 容器
docker run -d -p 80:80 --name webserver nginx

# 查看运行的容器
docker ps
```

## 安装后配置

### 用户权限配置（Linux）

为了避免每次使用 `sudo`，将当前用户添加到 `docker` 组：

```bash
# 添加用户到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行
newgrp docker

# 验证组权限
groups $USER
```

### 启动 Docker 服务

```bash
# 启动 Docker
sudo systemctl start docker

# 设置开机自启
sudo systemctl enable docker

# 查看服务状态
sudo systemctl status docker
```

### 配置镜像加速（中国用户）

为了加速镜像下载，建议配置国内镜像源：

```bash
# 编辑 Docker 配置文件
sudo nano /etc/docker/daemon.json

# 添加以下内容
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.ccs.tencentyun.com"
  ]
}

# 重启 Docker
sudo systemctl daemon-reload
sudo systemctl restart docker
```

## 常见安装问题

### 问题 1: 权限被拒绝

**症状**: 运行 Docker 命令时出现 `permission denied` 错误。

**解决方案**:

```bash
# 将用户添加到 docker 组
sudo usermod -aG docker $USER

# 重新登录或运行
newgrp docker
```

### 问题 2: 无法连接到 Docker 守护进程

**症状**: 出现 `Cannot connect to the Docker daemon` 错误。

**解决方案**:

```bash
# 启动 Docker 服务
sudo systemctl start docker

# 检查服务状态
sudo systemctl status docker

# 查看日志
sudo journalctl -u docker.service
```

### 问题 3: Windows WSL 2 问题

**症状**: Docker Desktop 无法启动或连接到 WSL 2。

**解决方案**:

1. 确保已启用 WSL 2：
```powershell
wsl --set-default-version 2
```

2. 更新 WSL 2 内核：
```powershell
wsl --update
```

3. 重启计算机

### 问题 4: macOS 网络问题

**症状**: 容器无法访问网络或主机。

**解决方案**:

1. 重启 Docker Desktop
2. 重置网络设置
3. 检查防火墙设置
4. 重新安装 Docker Desktop

## 卸载 Docker

如果需要卸载 Docker，请参考 [卸载指南](./uninstall)。

## 下一步

安装完成后，建议继续学习：

1. 📖 阅读 [Docker 基础概念](/docs/tutorials/introduction)
2. 🔧 学习 [Docker 常用命令](/docs/tutorials/commands/)
3. 🚀 尝试 [运行第一个容器](/docs/usage/containers/run)
4. 🎯 查看 [实战案例](/docs/cases/)

:::tip 提示

安装完成后，建议先运行 `docker run hello-world` 验证安装是否成功，然后再进行其他操作。

:::

:::warning 注意

在 Linux 系统上，安装 Docker 前请先移除旧版本，以避免潜在冲突。详见 [卸载指南](./uninstall)。

:::

:::info Docker 版本

本指南适用于 Docker 24.0 及以上版本。如果你需要安装其他版本，请访问 [Docker 版本历史](https://docs.docker.com/engine/release-notes/)。

:::