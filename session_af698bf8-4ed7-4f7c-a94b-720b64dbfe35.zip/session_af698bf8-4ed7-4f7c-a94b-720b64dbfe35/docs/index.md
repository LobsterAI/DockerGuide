---
id: index
title: Docker 文档
sidebar_label: Docker 介绍
slug: /
description: Docker 容器技术完整指南 - 从基础概念到高级实战
---

import DocCardList from '@theme/DocCardList';
import {useCurrentSidebarCategory} from '@docusaurus/theme-common';
import Heading from '@theme/Heading';

# 欢迎使用 Docker 文档

欢迎使用 Docker 容器技术完整指南！本文档将帮助你从零开始掌握 Docker 容器技术，从基础概念到高级实战应用。

## Docker 简介

Docker 是一个开源的容器化平台，它允许开发者将应用及其依赖打包到一个轻量级、可移植的容器中，从而实现应用在任何环境中的一致运行。

### 核心优势

- **快速交付**: 通过容器化加速应用开发和部署流程
- **一致性运行**: 确保应用在不同环境中运行结果一致
- **资源隔离**: 提供轻量级的进程隔离机制
- **易于管理**: 简化应用的部署、升级和扩展流程
- **跨平台兼容**: 支持在 Linux、Windows 和 macOS 上运行

### 适用场景

- 🏢 **企业级应用**: 快速部署和扩展企业应用
- 🔧 **微服务架构**: 构建和管理微服务系统
- 💻 **开发环境**: 创建一致的开发和测试环境
- 📦 **应用分发**: 简化应用的分发和部署流程
- 🌐 **云原生应用**: 构建云原生应用和服务

## 快速开始

如果你是 Docker 新手，建议按照以下顺序学习：

1. 📖 阅读 [Docker 基础概念](/docs/tutorials/introduction)
2. 💻 根据你的操作系统查看 [安装指南](/docs/installation/)
3. 🚀 尝试运行你的第一个容器
4. 📚 学习 [Docker 常用命令](/docs/tutorials/commands/)
5. 🔨 通过 [实战案例](/docs/cases/)加深理解

## 文档导航

<DocCardList />

## 学习路径

我们为你规划了不同的学习路径，可以根据你的需求选择：

### 🆕 新手入门

```mermaid
graph LR
    A[基础概念] --> B[安装 Docker]
    B --> C[基本命令]
    C --> D[容器操作]
    D --> E[镜像管理]
```

### 🔧 进阶学习

```mermaid
graph LR
    A[网络配置] --> B[存储管理]
    B --> C[Docker Compose]
    C --> D[实战案例]
```

### 🎯 企业应用

```mermaid
graph LR
    A[微服务架构] --> B[性能优化]
    B --> C[安全实践]
    C --> D[生产部署]
```

## 技术支持

- 📚 [常见问题](/docs/help/faq) - 查找常见问题的解答
- 🔍 [故障排除](/docs/help/troubleshooting) - 解决常见技术问题
- 💬 [社区讨论](https://github.com/docker-docs/docker-docs/discussions) - 参与社区讨论
- 🐛 [提交问题](https://github.com/docker-docs/docker-docs/issues) - 报告 Bug 或功能请求

## 贡献指南

我们欢迎所有形式的贡献！如果你想帮助改进这个文档：

1. 查看 [贡献指南](/docs/contribute)
2. Fork 项目并创建你的特性分支
3. 提交你的更改
4. 发起 Pull Request

## 版本信息

当前文档版本：Docker 24.0

| 组件 | 版本 |
|------|------|
| Docker Engine | 24.0.7 |
| Docker Compose | 2.21.0 |
| Docker CLI | 24.0.7 |
| BuildKit | 0.12.3 |

---

:::tip 提示

如果你有任何问题或建议，请通过 [GitHub Issues](https://github.com/docker-docs/docker-docs/issues) 联系我们。我们非常乐意帮助你！

:::

:::info 最新动态

关注我们的 [更新日志](/changelog) 获取最新的功能更新和改进。

:::