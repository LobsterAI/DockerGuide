---
id: index
title: 镜像源配置概览
sidebar_label: 镜像源概览
description: Docker Hub、npm、pip、Homebrew等常用镜像源的配置指南，加速软件包下载
---

import DocCardList from '@theme/DocCardList';
import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

# 镜像源配置概览

镜像源（镜像加速器）可以帮助你加速从远程仓库下载软件包、Docker镜像和其他资源的速度。在中国大陆使用镜像源尤为重要，因为访问某些国际站点可能会遇到网络问题或速度较慢。

本指南将帮助你配置各种常用软件的镜像源，包括 Docker Hub、npm、pip、Homebrew 等。

## 为什么需要配置镜像源

使用镜像源的主要优势包括：

- **更快的下载速度**: 使用国内或本地镜像源可以显著提高下载速度
- **更高的稳定性**: 减少因网络问题导致的下载失败
- **节省带宽成本**: 减少跨地域流量消耗
- **改善开发体验**: 加快依赖包安装速度，提高开发效率

## 支持的镜像源类型

<DocCardList />

## 常用国内镜像源

### Docker 镜像源

| 镜像源 | 地址 | 说明 |
|--------|------|------|
| Docker Hub (官方) | https://registry-1.docker.io | Docker 官方镜像仓库 |
| 阿里云 | https://docker.mirrors.ustc.edu.cn | 中国科学技术大学镜像 |
| 网易 | https://hub-mirror.c.163.com | 网易提供的镜像加速 |
| 腾讯云 | https://mirror.ccs.tencentyun.com | 腾讯云 Docker 镜像 |
| DaoCloud | https://docker.m.daocloud.io | DaoCloud 镜像加速 |

### npm 镜像源

| 镜像源 | 地址 | 说明 |
|--------|------|------|
| npm (官方) | https://registry.npmjs.org | npm 官方仓库 |
| 淘宝 | https://registry.npmmirror.com | 淘宝提供的 npm 镜像 |
| 华为云 | https://mirrors.huaweicloud.com/repository/npm/ | 华为云 npm 镜像 |

### pip 镜像源

| 镜像源 | 地址 | 说明 |
|--------|------|------|
| PyPI (官方) | https://pypi.org/simple | Python 官方包索引 |
| 清华大学 | https://pypi.tuna.tsinghua.edu.cn/simple | 清华大学开源镜像站 |
| 阿里云 | https://mirrors.aliyun.com/pypi/simple/ | 阿里云 PyPI 镜像 |
| 中国科技大学 | https://pypi.mirrors.ustc.edu.cn/simple/ | 中科大开源镜像站 |

### Homebrew 镜像源

| 镜像源 | 地址 | 说明 |
|--------|------|------|
| Homebrew (官方) | https://formulae.brew.sh | Homebrew 官方仓库 |
| 清华大学 | https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/brew.git | 清华大学 Homebrew 镜像 |
| 中科大 | https://mirrors.ustc.edu.cn/homebrew-core.git | 中科大 Homebrew 镜像 |

## 快速配置指南

### Docker 镜像源配置

#### Linux/macOS

编辑 `/etc/docker/daemon.json` 文件：

```bash
sudo nano /etc/docker/daemon.json
```

添加以下配置：

```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.ccs.tencentyun.com"
  ]
}
```

重启 Docker 服务：

```bash
sudo systemctl daemon-reload
sudo systemctl restart docker
```

#### Windows (Docker Desktop)

1. 打开 Docker Desktop
2. 进入 Settings → Docker Engine
3. 添加上述 JSON 配置
4. 点击 Apply & Restart

### npm 镜像源配置

#### 临时使用

```bash
npm install --registry=https://registry.npmmirror.com
```

#### 永久配置

```bash
# 配置淘宝镜像
npm config set registry https://registry.npmmirror.com

# 验证配置
npm config get registry
```

#### 使用 nrm 管理

```bash
# 安装 nrm
npm install -g nrm

# 查看可用镜像源
nrm ls

# 切换到淘宝镜像
nrm use taobao

# 添加自定义镜像源
nrm add custom https://your-mirror-url
```

### pip 镜像源配置

#### 临时使用

```bash
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple package-name
```

#### 永久配置

##### 方法一：使用配置文件

创建或编辑 `~/.pip/pip.conf` (Linux/macOS) 或 `%USERPROFILE%\pip\pip.ini` (Windows)：

```ini
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple
trusted-host = pypi.tuna.tsinghua.edu.cn
```

##### 方法二：使用命令行

```bash
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

### Homebrew 镜像源配置

#### 安装 Homebrew 时使用镜像源

```bash
# 使用清华镜像安装 Homebrew
/bin/bash -c "$(curl -fsSL https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/install.git/raw/master/install.sh)"

# 或使用中科大镜像
/bin/bash -c "$(curl -fsSL https://mirrors.ustc.edu.cn/homebrew-core.git/raw/master/install.sh)"
```

#### 已安装 Homebrew 更换镜像源

```bash
# 切换 Homebrew 核心仓库
cd "$(brew --repo)/Library/Taps/homebrew/homebrew-core"
git remote set-url origin https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/homebrew-core.git

# 切换 Homebrew cask 仓库
cd "$(brew --repo)"/Library/Taps/homebrew/homebrew-cask
git remote set-url origin https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/homebrew-cask.git

# 更新 brew
brew update
```

## 验证配置

### 验证 Docker 镜像源

```bash
# 查看 Docker 信息
docker info

# 在输出中查找 registry-mirrors
docker info | grep -A 5 "Registry Mirrors"

# 测试拉取镜像
time docker pull nginx:latest
```

### 验证 npm 镜像源

```bash
# 查看当前镜像源
npm config get registry

# 测试下载速度
time npm install lodash
```

### 验证 pip 镜像源

```bash
# 查看当前配置
pip config list

# 测试下载速度
time pip install numpy
```

### 验证 Homebrew 镜像源

```bash
# 查看当前源
cd "$(brew --repo)/Library/Taps/homebrew/homebrew-core"
git remote -v

# 测试更新速度
time brew update
```

## 故障排除

### 问题 1: Docker 无法连接到镜像源

**症状**: 出现连接超时或拒绝连接错误。

**解决方案**:

1. 检查网络连接
2. 尝试切换到其他镜像源
3. 检查防火墙设置
4. 验证镜像源 URL 是否正确

```bash
# 测试镜像源连接
curl -I https://docker.mirrors.ustc.edu.cn/v2/

# 查看 Docker 日志
sudo journalctl -u docker.service
```

### 问题 2: npm 安装包失败

**症状**: 安装 npm 包时出现错误或超时。

**解决方案**:

```bash
# 清除 npm 缓存
npm cache clean --force

# 尝试使用其他镜像源
npm install --registry=https://mirrors.huaweicloud.com/repository/npm/

# 使用 --verbose 查看详细日志
npm install --verbose
```

### 问题 3: pip 安装包出错

**症状**: pip 安装包时出现 SSL 错误或连接失败。

**解决方案**:

```bash
# 升级 pip
python -m pip install --upgrade pip

# 临时禁用 SSL 验证（不推荐用于生产）
pip install --trusted-host pypi.tuna.tsinghua.edu.cn package-name

# 使用代理
pip install --proxy http://proxy.example.com:8080 package-name
```

### 问题 4: Homebrew 更新缓慢

**症状**: brew update 或 brew install 速度很慢。

**解决方案**:

```bash
# 尝试其他镜像源
cd "$(brew --repo)/Library/Taps/homebrew/homebrew-core"
git remote set-url origin https://mirrors.ustc.edu.cn/homebrew-core.git

# 清理缓存
brew cleanup

# 重新安装 Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

## 最佳实践

### 1. 选择合适的镜像源

- 选择地理位置最近的镜像源
- 选择更新及时的镜像源
- 定期检查镜像源可用性
- 准备备用镜像源

### 2. 定期更新配置

- 定期检查镜像源是否更新
- 关注镜像源公告
- 测试镜像源速度和稳定性

### 3. 安全考虑

- 使用 HTTPS 镜像源
- 验证镜像源证书
- 定期检查镜像源安全性
- 避免使用不明来源的镜像源

### 4. 企业环境

- 搭建私有镜像源
- 配置企业内部代理
- 使用统一镜像源配置
- 监控镜像源使用情况

## 自动化配置

### Docker 自动化配置脚本

```bash
#!/bin/bash
# docker-mirror-setup.sh

# 检查是否以 root 运行
if [ "$EUID" -ne 0 ]; then
  echo "请使用 sudo 运行此脚本"
  exit 1
fi

# Docker 镜像源列表
MIRRORS=(
  "https://docker.mirrors.ustc.edu.cn"
  "https://hub-mirror.c.163.com"
  "https://mirror.ccs.tencentyun.com"
)

# 创建配置目录
mkdir -p /etc/docker

# 生成配置文件
cat > /etc/docker/daemon.json <<EOF
{
  "registry-mirrors": [
$(printf '    "%s",\n' "${MIRRORS[@]}" | sed '$ s/,$//')
  ]
}
EOF

# 重启 Docker 服务
systemctl daemon-reload
systemctl restart docker

# 验证配置
echo "Docker 镜像源配置完成："
docker info | grep -A 5 "Registry Mirrors"
```

### npm 自动化配置脚本

```bash
#!/bin/bash
# npm-mirror-setup.sh

# npm 镜像源列表
NPM_MIRRORS=(
  "https://registry.npmmirror.com"
  "https://mirrors.huaweicloud.com/repository/npm/"
)

# 安装 nrm
if ! command -v nrm &> /dev/null; then
  npm install -g nrm
fi

# 添加镜像源
for mirror in "${NPM_MIRRORS[@]}"; do
  nrm add custom-$(echo $mirror | sed 's/[^a-zA-Z0-9]//g') $mirror
done

# 设置默认镜像源
nrm use taobao

# 验证配置
echo "npm 镜像源配置完成："
npm config get registry
```

### pip 自动化配置脚本

```bash
#!/bin/bash
# pip-mirror-setup.sh

# pip 镜像源列表
PIP_MIRRORS=(
  "https://pypi.tuna.tsinghua.edu.cn/simple"
  "https://mirrors.aliyun.com/pypi/simple/"
)

# 创建配置目录
mkdir -p ~/.pip

# 生成配置文件
cat > ~/.pip/pip.conf <<EOF
[global]
index-url = ${PIP_MIRRORS[0]}
extra-index-url = ${PIP_MIRRORS[1]}
trusted-host = 
    pypi.tuna.tsinghua.edu.cn
    mirrors.aliyun.com
EOF

# 验证配置
echo "pip 镜像源配置完成："
pip config list
```

### Homebrew 自动化配置脚本

```bash
#!/bin/bash
# homebrew-mirror-setup.sh

# Homebrew 镜像源列表
BREW_MIRRORS=(
  "https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/brew.git"
  "https://mirrors.ustc.edu.cn/homebrew-core.git"
)

# 切换 Homebrew 仓库
cd "$(brew --repo)"
git remote set-url origin ${BREW_MIRRORS[0]}

# 切换 Homebrew Core 仓库
cd "$(brew --repo)/Library/Taps/homebrew/homebrew-core"
git remote set-url origin ${BREW_MIRRORS[1]}

# 更新 brew
brew update

# 验证配置
echo "Homebrew 镜像源配置完成："
cd "$(brew --repo)/Library/Taps/homebrew/homebrew-core"
git remote -v
```

## 监控镜像源性能

### 使用 curl 测试镜像源速度

```bash
#!/bin/bash
# test-mirror-speed.sh

# 测试镜像源列表
MIRRORS=(
  "https://docker.mirrors.ustc.edu.cn"
  "https://hub-mirror.c.163.com"
  "https://mirror.ccs.tencentyun.com"
)

# 测试每个镜像源
for mirror in "${MIRRORS[@]}"; do
  echo "测试镜像源: $mirror"
  time curl -I $mirror
  echo "----------------------------------------"
done
```

### 使用 ping 测试延迟

```bash
#!/bin/bash
# test-mirror-latency.sh

# 获取镜像源域名
domains=(
  "docker.mirrors.ustc.edu.cn"
  "hub-mirror.c.163.com"
  "mirror.ccs.tencentyun.com"
)

# 测试每个域名的延迟
for domain in "${domains[@]}"; do
  echo "测试域名: $domain"
  ping -c 5 $domain
  echo "----------------------------------------"
done
```

## 企业级镜像源方案

### 搭建私有 Docker 镜像源

```bash
# 使用 Docker Registry
docker run -d \
  --name registry \
  --restart=always \
  -p 5000:5000 \
  -v /data/registry:/var/lib/registry \
  registry:2

# 使用 Harbor（企业级）
# 参考 https://goharbor.io/docs/
```

### 搭建私有 npm 镜像源

```bash
# 使用 Verdaccio
npm install -g verdaccio
verdaccio

# 使用 cnpmjs.org
# 参考 https://github.com/cnpm/cnpmjs.org
```

### 搭建私有 PyPI 镜像源

```bash
# 使用 devpi
pip install devpi-server
devpi-server --init
devpi-server --host 0.0.0.0 --port 3141 --start
```

## 下一步

配置好镜像源后，你可以：

1. 🐳 查看 [Docker Hub 镜像源配置](./docker-hub)
2. 📦 学习 [npm 镜像源配置](./npm)
3. 🐍 了解 [pip 镜像源配置](./pip)
4. 🍺 掌握 [Homebrew 镜像源配置](./homebrew)
5. 🔧 配置 [其他镜像源](./yum)

:::tip 提示

建议优先选择地理位置最近的镜像源，并定期测试不同镜像源的速度和可用性。在生产环境中，建议准备多个备用镜像源。

:::

:::info 自动化建议

对于企业或团队环境，建议使用自动化脚本或配置管理工具（如 Ansible、Chef、Puppet）来统一配置镜像源，确保所有开发环境使用相同的镜像源设置。

:::

:::warning 注意

使用镜像源时请注意：

1. 验证镜像源的可靠性和安全性
2. 定期检查镜像源是否同步更新
3. 在关键部署前测试镜像源可用性
4. 记录镜像源配置变更

:::

## 相关资源

- [Docker Hub](https://hub.docker.com/)
- [npm 官方文档](https://docs.npmjs.com/)
- [PyPI 官方网站](https://pypi.org/)
- [Homebrew 官方网站](https://brew.sh/)
- [清华大学开源镜像站](https://mirrors.tuna.tsinghua.edu.cn/)
- [中科大开源镜像站](https://mirrors.ustc.edu.cn/)