<tool_call>execute_command<arg_key>command</arg_key><arg_value>cd /home/wuying/autoglm/session_af698bf8-4ed7-4f7c-a94b-720b64dbfe35 && cat > LOCAL_SETUP_GUIDE.md << 'ENDOFFILE'
# Docker 文档网站 - 本地运行指南

## 目录
- [系统要求](#系统要求)
- [快速开始](#快速开始)
- [详细安装步骤](#详细安装步骤)
- [开发服务器](#开发服务器)
- [多语言版本](#多语言版本)
- [常见问题](#常见问题)
- [性能优化](#性能优化)
- [故障排除](#故障排除)

## 系统要求

### 必需软件

**Node.js**
- 版本要求：Node.js 18.x 或更高版本
- 推荐版本：Node.js 18.x LTS（长期支持版本）

**npm 或 yarn（二选一）**
- npm 版本要求：9.x 或更高版本
- yarn 版本要求：1.22 或更高版本
- 推荐使用 npm 以获得最佳兼容性

**Git**
- 版本要求：Git 2.30 或更高版本
- 用途：克隆项目、版本控制

**推荐的开发工具**
- VS Code：轻量级但功能强大的代码编辑器
- WebStorm：JetBrains 出品的全功能 IDE
- IntelliJ IDEA：JetBrains 出品的全功能 IDE
- Sublime Text：快速轻量的文本编辑器
- Vim/Neovim：高效的命令行编辑器

### 可选软件

**Docker（用于容器化部署）**
- Docker Desktop：适用于 Windows、macOS、Linux
- Docker Engine：适用于 Linux 服务器环境
- Docker Compose：用于多容器应用编排

**包管理器**
- Homebrew：macOS 最流行的包管理器
- Chocolatey：Windows 包管理器
- Scoop：Windows 下的命令行安装器

**Git 客户端**
- GitHub Desktop：GitHub 官方图形界面客户端
- GitKraken：跨平台 Git 客户端
- SourceTree：Atlassian 出品的可视化 Git 工具

**浏览器（开发测试用）**
- Google Chrome：推荐，有强大的开发者工具
- Firefox：优秀的选择，特别是对于前端开发
- Microsoft Edge：Chromium 内核，兼容性好
- Safari：macOS/iOS 的默认浏览器

## 快速开始

### 方法一：使用快速启动脚本（推荐）

如果您希望快速开始，可以使用我们提供的快速启动脚本：

```bash
# 1. 赋予脚本执行权限
chmod +x start-local.sh

# 2. 运行快速启动脚本
./start-local.sh

# 3. 按照提示选择语言和端口
```

该脚本将自动完成以下操作：
- 检查 Node.js 版本
- 检查 npm 版本
- 安装项目依赖
- 启动开发服务器
- 在浏览器中打开网站

### 方法二：手动启动

如果您需要更多控制，可以按照以下步骤手动启动：

```bash
# 1. 进入项目目录
cd /home/wuying/autoglm/session_af698bf8-4ed7-4f7c-a94b-720b64dbfe35

# 2. 安装依赖
npm install

# 3. 启动开发服务器（默认中文版本，端口 3000）
npm start

# 或者使用 yarn
yarn install
yarn start
```

### 方法三：使用 Docker 容器化运行

```bash
# 1. 使用 Docker Compose 启动
docker-compose up -d

# 2. 查看运行状态
docker-compose ps

# 3. 查看日志
docker-compose logs -f

# 4. 停止服务
docker-compose down
```

## 详细安装步骤

### 第一步：检查系统环境

#### 检查 Node.js 版本

在终端或命令提示符中运行以下命令检查 Node.js 版本：

```bash
# 检查 Node.js 是否已安装
node -v

# 如果未安装或版本过低，安装最新 LTS 版本
# macOS 使用 Homebrew 安装：
brew install node

# Windows 使用 Chocolatey 安装：
choco install nodejs-lts

# Ubuntu/Debian 安装：
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# CentOS/RHEL 安装：
sudo yum install -y nodejs
```

#### 检查 npm 版本

```bash
# 检查 npm 是否已安装
npm -v

# 如果与 Node.js 一起安装，则通常不需要单独安装
# 如需安装最新版本：
npm install -g npm@latest

# 验证 npm 版本
npm --version
```

#### 检查 Git 版本

```bash
# 检查 Git 是否已安装
git --version

# 如果未安装：
# macOS 使用 Homebrew：
brew install git

# Windows 使用 Chocolatey：
choco install git

# Ubuntu/Debian：
sudo apt-get update
sudo apt-get install -y git

# CentOS/RHEL：
sudo yum install -y git

# Arch Linux：
sudo pacman -S git
```

### 第二步：获取项目文件

#### 方法 A：克隆仓库

```bash
# 克隆项目到本地
git clone https://github.com/your-username/docker-docs.git

# 进入项目目录
cd docker-docs

# 查看项目内容
ls -la
```

#### 方法 B：下载压缩包

如果无法使用 Git 克隆，可以从 GitHub 下载项目的压缩包：

```bash
# 下载最新版本的压缩包（以 .zip 或 .tar.gz 格式）
wget https://github.com/your-username/docker-docs/archive/refs/heads/main.zip

# 或使用 curl
curl -L https://github.com/your-username/docker-docs/archive/refs/heads/main.zip -o docker-docs.zip

# 解压压缩包
unzip docker-docs.zip

# 或解压 tar.gz 包
tar -xzf docker-docs.tar.gz

# 进入项目目录
cd docker-docs
```

#### 方法 C：使用本地文件

如果您已经有项目文件：

```bash
# 确保您在正确的目录中
cd /home/wuying/autoglm/session_af698bf8-4ed7-4f7c-a94b-720b64dbfe35

# 列出项目文件
ls -la
```

### 第三步：安装项目依赖

#### 使用 npm 安装依赖

```bash
# 进入项目目录
cd /home/wuying/autoglm/session_af698bf8-4ed7-4f7c-a94b-720b64dbfe35

# 清理 npm 缓存（推荐）
npm cache clean --force

# 安装项目依赖
npm install

# 验证安装结果
npm list --depth=0

# 查看已安装的依赖包
npm list
```

#### 使用 yarn 安装依赖

如果您更喜欢使用 yarn 作为包管理器：

```bash
# 安装 yarn（如果尚未安装）
npm install -g yarn

# 使用 yarn 安装依赖
yarn install

# 验证安装结果
yarn list --depth=0

# 查看已安装的包
yarn global list
```

#### 安装常见问题及解决方法

问题1：npm install 失败

现象：
```
npm ERR! code ERESOLVE
npm ERR! network request failed
```

解决方案：

```bash
# 清理 npm 缓存
npm cache clean --force

# 使用国内镜像源
npm config set registry https://registry.npmmirror.com

# 再次尝试安装
npm install
```

问题2：权限错误

现象：
```
npm ERR! code EACCES
npm ERR! errno -13
npm ERR! syscall access
```

解决方案：

```bash
# 使用 sudo 安装（不推荐，仅限紧急情况）
sudo npm install

# 更改 npm 目录权限
sudo chown -R $USER:$USER ~/.npm
sudo chown -R $USER:$USER $(npm config get prefix)/{lib,node_modules}

# 使用 yarn（通常不需要 sudo）
yarn install
```

问题3：Python 版本问题

现象：
```
gyp ERR! stack Error: Error: `make` failed with exit code: 2
```

解决方案：

```bash
# 更新 Python 到最新版本
# macOS 使用 Homebrew
brew install python

# Windows 访问：https://www.python.org/downloads/

# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y python3 python3-pip

# CentOS/RHEL
sudo yum install -y python3 python3-pip
```

问题4：编译器版本问题

现象：
```
node-gyp ERR! build error
```

解决方案：

```bash
# 使用 Python 3
npm config set python python3

# 设置 npm 使用的构建工具
npm config set msvs_version 2019

# 或使用 yarn
yarn config set python python3
```

### 第四步：启动开发服务器

#### 启动默认语言（中文）版本

```bash
# 进入项目目录
cd /home/wuying/autoglm/session_af698bf8-4ed7-4f7c-a94b-720b64dbfe35

# 启动开发服务器（默认端口 3000）
npm start
```

#### 启动特定语言版本

```bash
# 启动英语版本
npm start --locale en

# 启动德语版本
npm start --locale de

# 启动法语版本
npm start --locale fr

# 启动西班牙语版本
npm start --locale es

# 启动日语版本
npm start --locale ja

# 启动韩语版本
npm start --locale ko
```

#### 使用不同的端口启动

如果默认端口 3000 被占用，可以使用其他端口：

```bash
# 使用端口 3001 启动
npm start -- --port 3001

# 或使用端口 8080 启动
npm start -- --port 8080
```

#### 使用 yarn 启动

```bash
# 使用 yarn 启动开发服务器
yarn start

# 使用 yarn 启动特定语言版本
yarn start --locale en
```

#### 使用 Docker 启动

```bash
# 使用 Docker Compose 启动
docker-compose up -d

# 查看容器状态
docker-compose ps

# 查看日志
docker-compose logs -f web
```

#### 指定主机启动

```bash
# 指定主机启动，只监听本地
npm start -- --host 127.0.0.1

# 指定主机和端口
npm start -- --host 127.0.0.1 --port 3000
```

#### 在后台启动

```bash
# 在后台启动开发服务器（输出重定向到文件）
nohup npm start > dev.log 2>&1 &

# 查看后台进程 ID
echo $!

# 查看日志
tail -f dev.log

# 停止后台服务
kill $!
```

### 第五步：验证服务器运行

#### 使用 curl 验证

```bash
# 检查服务器是否运行
curl http://localhost:3000

# 检查不同语言版本
curl http://localhost:3000/en
curl http://localhost:3000/de
curl http://localhost:3000/fr
curl http://localhost:3000/es
curl http://localhost:3000/ja
curl http://localhost:3000/ko

# 查看响应头
curl -I http://localhost:3000

# 查看详细响应
curl -v http://localhost:3000
```

#### 使用 wget 验证

```bash
# 下载首页
wget -O index.html http://localhost:3000

# 下载特定页面
wget -O introduction.html http://localhost:3000/docs/tutorials/introduction

# 显示下载进度
wget --progress=bar http://localhost:3000 -O test.html
```

#### 使用 telnet 验证

```bash
# 检查端口是否监听
telnet localhost 3000

# 如果端口 3000 无法连接，尝试其他端口
telnet localhost 3001
```

#### 浏览器访问

打开浏览器，访问以下地址之一：

- http://localhost:3000（默认，中文）
- http://localhost:3000/en（英语）
- http://localhost:3000/de（德语）
- http://localhosT:3000/fr（法语）
- http://localhost:3000/es（西班牙语）
- http://localhost:3000/ja（日语）
- http://localhost:3000/ko（韩语）

## 开发服务器

### 开发服务器特性

Docusaurus 开发服务器提供以下特性：

1. **热重载（Hot Module Replacement, HMR）**
   - 编辑文件后自动刷新浏览器
   - 支持所有类型的文件修改
   - 无需手动刷新页面

2. **快速构建**
   - 增量构建策略
   - 构建速度优化
   - 缓存机制减少构建时间

3. **错误提示**
   - 清晰的错误信息
   - 源代码位置提示
   - 构建警告和建议

4. **开发工具集成**
   - 内置开发者工具
   - 响应式调试工具
   - 实时日志输出

5. **多端口支持**
   - 支持指定启动端口
   - 自动选择可用端口
   - 端口冲突自动解决

### 开发服务器配置

#### 修改默认端口

在 docusaurus.config.js 中修改默认端口：

```javascript
// 在 docusaurus.config.js 的 devServer 配置中
module.exports = {
  // ...其他配置...

  devServer: {
    port: 3000,  // 默认端口
    open: true,  // 自动打开浏览器
    host: 'localhost',  // 监听的主机
  },
  
  // ...其他配置...
};
```

#### 修改浏览器打开行为

```javascript
// 在 docusaurus.config.js 中配置
module.exports = {
  // ...其他配置...

  devServer: {
    open: true,  // 启动时自动打开浏览器
    app: 'chrome',  // 指定浏览器：chrome, firefox, default 等
    openPageTimeout: 1000, // 浏览器打开超时时间（毫秒）
  },
  
  // ...其他配置...
};
```

#### 配置代理

```bash
# 设置 HTTP 代理
export HTTP_PROXY=http://your-proxy:8080
export HTTPS_PROXY=https://your-proxy:8443

# 设置 HTTPS 代理
export http_proxy=http://your-proxy:8080
export https_proxy=https://your-proxy:8443

# 在浏览器中访问
npm start
```

### 开发服务器调试

#### 查看详细日志

```bash
# 查看详细的构建和服务器日志
npm start -- --verbose

# 查看 webpack 构建统计
npm start -- --stats

# 查看警告信息
npm start -- --no-open
```

#### 清理缓存和重新构建

```bash
# 清理 Docusaurus 缓存
npm run clean

# 删除 node_modules 和重新安装
rm -rf node_modules package-lock.json
npm install

# 清理构建缓存
rm -rf .docusaurus

# 重新构建和启动
npm run build
npm start
```

## 多语言版本

### 切换语言版本

#### 通过 URL 切换

在浏览器地址栏中添加语言代码：

```bash
# 中文版本（默认）
http://localhost:3000/

# 英语版本
http://localhost:3000/en

# 德语版本
http://localhost:3000/de

# 法语版本
http://localhost:3000/fr

# 西班牙语版本
http://localhost:3000/es

# 日语版本
http://localhost:3000/ja

# 韩语版本
http://localhost:3000/ko
```

#### 通过启动参数切换

```bash
# 启动特定语言版本
npm start --locale en

# 使用不同的端口启动英语版本
npm start --locale en --port 3001
```

### 查看不同语言版本

#### 对比不同语言的内容

```bash
# 下载不同语言版本的首页
curl -O index-zh.html http://localhost:3000/
curl -O index-en.html http://localhost:3000/en
curl -O index-de.html http://localhost:3000/de
curl -O index-fr.html http://localhost:3000/fr
curl -O index-es.html http://localhost:3000/es
curl -o index-ja.html http://localhost:3000/ja
curl -o index-ko.html http://localhost:3000/ko
```

#### 使用浏览器开发者工具

1. 打开浏览器开发者工具（F12）
2. 在 Console 标签中查看语言代码：`window.localStorage.getItem('locale')`
3. 切换语言并观察变化
4. 在 Network 标签中查看资源加载情况
5. 在 Application 标签中查看本地存储

### 生成静态文件

#### 构建所有语言版本

```bash
# 构建所有语言版本
npm run write-translations

# 构建所有语言的生产版本
for lang in en de fr es ja ko; do
  npm run build --locale $lang
done
```

#### 构建特定语言版本

```bash
# 构建英语版本
npm run build --locale en

# 构建德语版本
npm run build --locale de

# 构建法语版本
npm run build --locale fr

# 构建西班牙语版本
npm run build --locale es

# 构建日语版本
npm run build --locale ja

# 构建韩语版本
npm run build --locale ko
```

## 常见问题

### 启动问题

#### 问题1：端口被占用

现象：
```
Error: listen EADDRINUSE: address already in use :::3000
```

解决方案：

```bash
# 查看占用端口的进程
lsof -ti:3000

# 或使用 netstat
netstat -an | grep :3000

# 停止占用端口的进程
kill -9 $(lsof -ti:3000 -t)

# 或使用其他端口启动
npm start -- --port 3001

# 使用自动端口分配
npm start -- --port 0  # 系统自动选择可用端口
```

#### 问题2：依赖安装失败

现象：
```
npm ERR! code ERESOLVE
npm ERR! network request failed
npm ERR! syscall connect
```

解决方案：

```bash
# 清理 npm 缓存
npm cache clean --force

# 检查网络连接
ping npmjs.org

# 配置国内镜像源
npm config set registry https://registry.npmmirror.com

# 更新 npm 到最新版本
npm install -g npm@latest

# 尝试使用 yarn
yarn install
```

#### 问题3：构建错误

现象：
```
Error: Build failed with errors
Module build failed
```

解决方案：

```bash
# 清理缓存并重新安装
npm run clean
rm -rf node_modules package-lock.json
npm install
npm run build
```

#### 问题4：内存不足错误

现象：
```
FATAL ERROR: Ineffective mark-compacts garbage collector
```

解决方案：

```bash
# 增加 Node.js 内存限制
export NODE_OPTIONS=--max-old-space-size=4096

# 在 Windows PowerShell 中设置
$env:NODE_OPTIONS="--max-old-space-size=4096"

# 在 Linux/macOS bash 中设置
export NODE_OPTIONS="--max-old-space-size=4096"

# 在 Windows CMD 中设置
set NODE_OPTIONS=--max-old-space-size=4096

# 使用增加内存限制启动
NODE_OPTIONS=--max-old-space-size=4096 npm start
```

#### 问题5：热重载不工作

现象：
```
HMR Hot Module Replacement is enabled
Hot reload will happen
```

但修改文件后页面没有自动刷新

解决方案：

```bash
# 1. 确认文件路径正确
pwd

# 2. 检查文件是否在正确目录中
ls -la

# 3. 重启开发服务器
# 按 Ctrl+C 停止服务器
npm start

# 4. 清除浏览器缓存
# 在浏览器中按 Ctrl+Shift+Delete（Chrome）
# 或 Ctrl+Shift+Del（Firefox）

# 5. 检查控制台错误
# 打开浏览器开发者工具查看错误信息

# 6. 尝试手动刷新
# 按 F5 或 Ctrl+R
```

#### 问题6：中文显示乱码

现象：
```中文字符显示为方框或乱码
```

解决方案：

```bash
# 1. 确保文件编码为 UTF-8
file --mime-type *.md

# 2. 在编辑器中设置文件编码
# VS Code: 右下角选择 UTF-8
# Vim: set encoding=utf-8

# 3. 在浏览器中设置字符编码
# Chrome: 设置 > 高级 > 语言 > 字体
# Firefox: 查看 > 页面信息 > 文字编码 > Unicode (UTF-8)
```

#### 问题7：图片不显示

现象：
```
图片显示为破损图标或无法加载
```

解决方案：

```bash
# 1. 检查图片路径
ls -la static/img/

# 2. 检查图片文件名
ls static/img/

# 3. 检查图片引用路径
grep -r "static/img/" docs/

# 4. 确保图片文件存在
ls -R static/img/

# 5. 检查构建后的图片路径
ls -la build/static/img/
```

### 运行时问题

#### 问题1：服务器启动失败

现象：
```
Server started on http://localhost:3000
Ready in 2.5 seconds
```

但无法在浏览器中访问

解决方案：

```bash
# 1. 检查服务器是否真正运行
ps aux | grep node

# 2. 检查端口是否监听
netstat -an | grep :3000

# 3. 检查防火墙设置
# Linux: sudo ufw status
# macOS: sudo pfctl status

# 4. 检查浏览器代理设置
# 在浏览器中禁用代理

# 5. 检查 hosts 文件
cat /etc/hosts | grep localhost

# 6. 重启服务器
# 按 Ctrl+C 停止
npm start
```

#### 问题2：构建速度慢

现象：
```
The build process takes more than 5 minutes
```

解决方案：

```bash
# 1. 使用增量构建
npm run build

# 2. 清理缓存
npm run clean

# 3. 优化图片资源
# 减小图片尺寸
# 使用 WebP 格式
# 压缩图片

# 4. 优化构建配置
# 在 docusaurus.config.js 中设置
module.exports = {
  siteConfig: {
    trailingSlash: false,
    organizationName: 'Docker Docs',
    projectName: 'docker-docs',
    deploymentBranch: 'gh-pages',
  },
  webpack: {
    jsMinifier: false,  // 开发模式不压缩
  },
};
```

#### 问题3：移动端显示异常

现象：
```
移动端布局错乱或不响应
```

解决方案：

```bash
# 1. 测试移动端视图
# 使用 Chrome 开发者工具的设备模拟器
# 按 F12 -> Ctrl+Shift+M (Chrome)

# 2. 检查响应式设计
# 调整浏览器窗口大小

# 3. 测试不同设备尺寸
# 使用 Chrome 开发者工具模拟
# 375x667 (iPhone 12/13 Pro Max)
# 390x844 (iPhone 14 Pro Max)

# 4. 查看控制台错误
# F12 -> Console 标签

# 4. 使用 Lighthouse 审查
# 在 Chrome 开发者工具中使用 Lighthouse
```

### Docker 相关问题

#### 问题1：Docker 容器无法启动

现象：
```
docker: Error response from daemon: Unexpected server response
```

解决方案：

```bash
# 1. 检查 Docker 状态
docker version

# 2. 检查 Docker 守护进程状态
sudo systemctl status docker

# 3. 重启 Docker 服务
sudo systemctl restart docker

# 4. 查看系统日志
sudo journalctl -u docker -n 50

# 5. 检查 Docker 守护进程日志
docker info

# 6. 清理 Docker 缓存
docker system prune -f
```

#### 问题2：端口冲突

现象：
```
docker: Error starting userland proxy: listen tcp 0.0.0.0:3000: bind: address already in use
```

解决方案：

```bash
# 1. 停止占用端口的容器
docker ps -a | grep :3000

# 停止容器
docker stop $(docker ps -a | grep :3000 | awk '{print $1}')

# 删除容器
docker rm $(docker ps -a | grep :3000 | awk '{print $1}')

# 或修改 docker-compose.yml 中的端口
# 将 "3000:3000" 改为 "3001:3000"
```

#### 问题3：容器无法访问网络

现象：
```
docker exec container ping google.com
```

显示：
```
ping: unknown host
```

解决方案：

```bash
# 1. 检查网络模式
docker network ls

# 2. 创建自定义网络
docker network create --driver bridge my-network

# 使用自定义网络启动容器
docker-compose up --network my-network

# 3. 检查容器网络配置
docker inspect <container_name> | grep -A 10 "NetworkSettings"
```

## 性能优化

### 开发环境优化

#### 1. 优化构建速度

```bash
# 使用缓存
npm start

# 跳过类型检查
# 在 docusaurus.config.js 中设置
module.exports = {
  webpack: {
    jsMinifier: false,
  },
};
```

#### 2. 优化启动速度

```bash
# 使用增量构建
npm start

# 减少构建文件数量
# 移除未使用的文件

# 优化依赖加载
# 减少依赖数量
# 使用更轻量级的替代方案
```

#### 3. 优化开发体验

```bash
# 使用 HMR 热功能
npm start

# 使用浏览器自动打开
# 在 docusaurus.config.js 中设置
module.exports = {
  devServer: {
    open: true,
  },
};
```

### 生产环境优化

#### 1. 优化构建产物大小

```bash
# 压缩静态资源
# 使用 image-webpack-plugin
npm install image-webpack-plugin --save-dev

# 在 docusaurus.config.js 中配置
module.exports = {
  plugins: [
    [
      require.resolve('@docusaurus/preset-classic'),
      [require.resolve('image-webpack-plugin')]
    ],
  },
};
```

#### 2. 启用 Gzip 压缩

```javascript
// 在 docus.config.js 中配置
module.exports = {
  plugins: [
    require.resolve('@docusaurus/preset-classic'),
    [
      require.resolve('@docusaurus/plugin-google-analytics'),
    {
        id: 'google-analytics',
        trackingID: 'G-XXXXXXXXXX',  // 替换为你的 GA 跟踪 ID
        anonymizeIP: true,
      },
    ],
  ],
};
```

#### 3. 优化资源加载

```javascript
// 在 docus.config.js 中配置
module.exports = {
  plugins: [
    require.resolve('@docusaurus/preset-classic'),
  ],
  presets: [
    [
      '@docusaurus/preset-classic',
      {
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      },
    ],
  ],
};
```

#### 4. 优化首屏加载

```javascript
// 在 docus.config.js 中配置
module.exports = {
  themeConfig: {
    prism: {
      additionalLanguages: ['dockerfile', 'yaml', 'json', 'bash'],
    },
  },
};
```

#### 5. 代码分割和懒加载

```javascript
// 在 docusaurus.config.js 中配置
module.exports = {
  plugins: [
    require.resolve('@docusaurus/plugin-client-redirects'),
  ],
};
```

### 灢复策略

#### 1. 版本回滚

```bash
# 使用 Git 回滚到上一个版本
git log --oneline -n 10

# 回滚到指定版本
git reset --hard <commit-hash>

# 查看历史提交
git log --graph --all
```

#### 2. 备份当前代码

```bash
# 创建备份分支
git checkout -b backup-$(date +%Y%m%d-%H%M%S)

# 提交所有更改
git add .
git commit -m "Backup before changes"

# 推送到远程
git push origin backup-$(date +%Y%m%d-%H%M%S)
```

#### 3. 恢复丢失的文件

```bash
# 查看提交历史
git reflog

# 恢复删除的文件
git checkout HEAD~1 -- path/to/file

# 从特定提交恢复
git checkout <commit-hash> -- path/to/file

# 从暂存区恢复
git restore path/to/file
```

#### 4. 紧急恢复流程

```bash
# 1. 保存当前更改
git stash

# 2. 回滚到上一个稳定版本
git reset --hard HEAD~1

# 3. 重新安装依赖
rm -rf node_modules package-lock.json
npm install

# 4. 重新启动
npm start
```

## 故障排除

### 查看系统信息

```bash
# 查看 Node.js 版本
node -v

# 查看 npm 版本
npm -v

# 查看 npm 配置
npm config list

# 查看已安装的全局包
npm list -g --depth=0
```

### 查看构建信息

```bash
# 查看构建配置
npm run build

# 查看构建详细信息
npm run build -- --debug

# 查看构建统计
npm run build -- --stats

# 清理构建缓存
npm run clean
```

### 查看运行时信息

```bash
# 查看 Node.js 进程
ps aux | grep node

# 查看 Node.js 内存使用
top -p node

# 查看 Node.js 环境变量
env | grep NODE

# 查看 npm 环境变量
npm config list | grep -E "registry|cache|prefix"
```

### 清理和重置

#### 清理缓存文件

```bash
# 清理 npm 缓存
npm cache clean --force

# 清理 Docusaurus 缓存
npm run clean

# 清理所有缓存
rm -rf .cache/
```

#### 重置项目状态

```bash
# 删除 node_modules
rm -rf node_modules

# 删除构建产物
rm -rf build/

# 删除 .docusaurus 缓存
rm -rf .docusaurus/

# 删除锁文件
rm -f package-lock.json
```

#### 完全重置

```bash
# 1. 删除所有自动生成的文件
rm -rf node_modules build .docusaurus .cache package-lock.json

# 2. 重新安装依赖
npm install

# 3. 清理浏览器缓存
# 在浏览器中按 Ctrl+Shift+Delete (Chrome)
# 或 Ctrl+Shift+Del (Firefox)

# 4. 重新启动
npm start
```

## 开发工作流

### 典型开发流程

```bash
# 1. 创建功能分支
git checkout -b feature/feature-name

# 2. 开发新功能
# 修改代码

# 3. 查看变化
git diff

# 4. 提交更改
git add .
git commit -m "Add feature"

# 5. 推送到远程
git push origin feature/feature-name

# 6. 创建 Pull Request
# 在 GitHub 上创建 PR
```

### 使用分支进行开发

```bash
# 查看所有分支
git branch -a

# 创建新分支
git branch feature/new-feature

# 切换到新分支
git checkout feature/new-feature

# 切换回主分支
git checkout main

# 删除分支
git branch -D feature/old-feature

# 重命名分支
git branch -m feature/old-name feature/new-name
```

### 代码审查流程

```bash
# 查看更改
git diff

# 查看特定文件的更改
git diff path/to/file

# 查看暂存区
git diff --cached

# 查看提交历史
git log --oneline -n 10

# 查看提交详情
git show <commit-hash>
```

### 合并和发布流程

```bash
# 合并功能分支
git merge feature/new-feature

# 解决冲突（如果有）
git status
git add .
git commit

# 推送到远程
git push origin main

# 创建标签
git tag -a v1.0.0
git push origin v1.0.0
```

## 进阶功能

### 多站点配置

#### 配置多个独立站点

```javascript
// 在 docusaurus.config.js 中配置
module.exports = {
  url: 'https://yourdomain.com',
  baseUrl: '/',
  
  plugins: [
    [
      '@docusaurus/plugin-client-redirects',
      {
        id: 'redirects',
        createRedirects: function(existingPath) {
          return [
            existingPath + '/index.html',
            existingPath + '/index.html/',
          ];
        },
      },
    ],
  ],
};
```

### 自定义主题

#### 使用自定义主题

```bash
# 安装主题
npm install @docusaurus/theme-classic

# Swizzle 组件
npm run swizzle @docusaurus/theme-classic Footer

# Swizzle 组件
npm run swizzle @docus/theme-classic Footer /components

# 还原默认主题
npm run swizzle @docus/theme-classic Footer -- --theme

# 清理未使用的 swizzled 组件
rm -rf src/theme
```

### 使用自定义组件

#### 创建自定义组件

```bash
# 创建组件目录
mkdir -p src/theme/Footer

# 创建组件文件
cat > src/theme/Footer/index.js << 'EOF'
import React from 'react';

export default function Footer() {
  return (
    <footer className="footer bg-slate-900 text-slate-300">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h4 className="font-bold mb-4">文档</h4>
            <ul>
              <li><a href="/docs/" className="text-gray-400 hover:text-white transition-colors">Docker 介绍</a></li>
              <li><a href="/docs/installation/" className="text-gray-400 hover:text-white transition-colors">安装指南</a></li>
              <li><a href="/docs/usage/" className="text-gray-400 hover:text-white transition-colors">使用指南</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">社区</h4>
            <ul>
              <li><a href="/community" className="text-gray-400 hover:text-white transition-colors">论坛</a></li>
              <li><a href="/community" className="text- </div>
              <li><a href="https://github.com" className="text-gray-400 hover:text-white transition-colors">GitHub</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">更多</h4>
            <ul>
              <li><a href="/blog" className="text-gray-400 hover:text-white transition-colors">博客</a></li>
              <li><a href="/changelog" className="text-gray-400 hover:text white transition-colors">更新日志</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">法律</h4>
            <ul>
              <li><a href="/privacy" className="text-gray-400 hover:text-white transition-colors">隐私政策</a></li>
              <li><a href="/terms" className="text-gray-400 hover:text white transition-colors">服务条款</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-700 mt-8 pt-8">
          <div className="text-center">
            <p className="text-gray-400">
              Copyright © {new Date().getFullYear()} Docker Docs. Built with Docusaurus.
            </p>
            <div className="mt-4 flex justify-center space-x-4">
              <a href="https://github.com/docker-docs/docker-docs" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-github text-2xl"></i>
              </a>
              <a href="https://twitter.com/docker" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-twitter text-2xl"></i>
              </a>
              <站点导航
              <nav className="flex flex-wrap justify-center gap-4">
                <a href="/" className="text-gray-400 hover:text-white transition-colors">首页</a>
                <a href="/docs/" className="text-gray-400 hover:text-white transition-colors">文档</a>
                <a href="/blog" className="text-400 hover:text-white transition-colors">博客</a>
                <a href="/community" className="text-gray-400 hover:400 hover:text-white transition-colors">社区</a>
              </nav>
              </div>
            </div>
        </div>
      </footer>
    );
}
EOF

# 创建样式文件
cat > src/theme/Footer/styles.module.css << 'EOF'
.footer {
  padding: 2rem 0;
  background: #0f172a;
  border-top: 1px solid #1e293b;
}

.container {
  max-width: 1280px;
}

.footer h4 {
  color: #f8fafc;
  margin-bottom: 1rem;
  font-size: 1rem;
  font-weight: 600;
}

.footer ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.footer li {
  margin-bottom: 0.5rem;
}

.footer a {
  text-decoration: none;
  color: #94a3b8;
  transition: color 0.3s;
}

.footer a:hover {
  color: #fff;
}

.text-center {
  text-align: center;
}

.mt-4 {
  margin-top: 1rem;
}

.mt-8 {
  margin-top: 2rem;
}

.space-x-4 {
  margin-right: 1rem;
}

.space-x-8 {
  margin-right: 2rem;
}

@media (max-width: 768px) {
  .grid {
    grid-template-columns: 1;
    gap: 2rem;
  }
}
EOF
```

```python
# Python 示例：自动化部署脚本
import os
import subprocess
import json
from pathlib import Path

# 确保项目目录正确
project_dir = Path("/home/wuying/autoglm/session_af698bf8-4ed7-4f7c-a94b-720b64dbfe35")
os.chdir(project_dir)

# 创建输出目录
output_dir = project_dir / "deployments"
output_dir.mkdir(exist_ok=True)

def build_site(language='zh'):
    """构建指定语言版本的网站"""
    cmd = f'npm run build --locale {language}'
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result

def deploy_site(language='zh'):
    """部署指定语言版本"""
    # 构建网站
    build_result = build_site(language)
    
    # 复制构建产物到部署目录
    src_dir = project_dir / 'build'
    dst_dir = output_dir / language
    if dst_dir.exists():
        import shutil
        shutil.rmtree(dst_dir)
    shutil.copytree(src_dir, dst_dir)
    
    # 生成部署报告
    report = {
        'language': language,
        'build_time': '2024-01-15 10:30:00',
        'build_status': 'success',
        'files_count': sum(1 for _ in (output_dir / language).glob('**/*') if (output_dir / language).is_dir()),
        'total_size': sum(f.stat(f).st_size for f in (output_dir / language).glob('**/*') if (output_dir / language).is_dir()),
    }
    
    report_file = output_dir / f'{language}_deployment_report.json'
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

# 构建所有语言
languages = ['zh', 'en', 'de', 'fr', 'es', 'ja', 'ko']

for lang in languages:
    print(f"Building and deploying {lang} version...")
    deploy_site(lang)

# 生成总报告
total_report = {
    'total_languages': len(languages),
    'deployment_time': '2024-01-15 11:00:00',
    'deploy_status': 'success',
    'languages': languages,
    'total_files': sum([sum(1 for _ in (output_dir / lang).glob('**/*') if (output_dir / lang).is_dir() for lang in languages]),
    'total_size': sum([sum(f.stat(f).st_size for f in (output_dir / lang).glob('```
ENDOFFILE
cat LOCAL_SETUP_GUIDE.md | wc -l</arg_value></tool_call>