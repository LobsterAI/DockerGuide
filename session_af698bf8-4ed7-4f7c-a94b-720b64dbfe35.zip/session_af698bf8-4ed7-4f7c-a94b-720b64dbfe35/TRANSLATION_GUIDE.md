# Docker 文档网站翻译指南

## 翻译文件结构

Docker 文档网站支持以下 6 种语言：

| 语言代码 | 语言名称 | 方向 |
|---------|---------|------|
| `en` | English (英语) | LTR |
| `de` | Deutsch (德语) | LTR |
| `fr` | Français (法语) | LTR |
| `es` | Español (西班牙语) | LTR |
| `ja` | 日本語 (日语) | LTR |
| `ko` | 한국어 (韩语) | LTR |

## 目录结构

```
i18n/
├── {language}/                    # 每种语言的目录
│   ├── docusaurus-plugin-content-docs/
│   │   └── current/           # 文档内容翻译
│   │       ├── index.json
│   │       ├── introduction.json
│   │       └── ...
│   └── docusaurus-theme-classic/   # 主题组件翻译
│       └── translations.json
```

## 翻译文件生成

### 使用脚本生成翻译文件

项目包含 `generate-translations.js` 脚本，可以快速生成所有语言的翻译文件。

```bash
# 生成所有语言的翻译文件
node generate-translations.js

# 只生成特定语言的翻译文件
node generate-translations.js en
node generate-translations.js de
node generate-translations.js fr
node generate-translations.js es
node generate-translations.js ja
node generate-translations.js ko
```

### 查看帮助信息

```bash
node generate-translations.js --help
node generate-translations.js -h
```

## 翻译规则

### 1. 键名规范

- 使用 `theme.{component}.{key}` 格式
- 保持键名一致性
- 使用有意义的键名
- 避免使用保留字

### 2. 变量和占位符

使用 `{{variable}}` 语法表示变量：

```json
{
  "site.title": "Docker Documentation - {{version}}",
  "theme.Footer.copyright": "Copyright © {{year}} Docker Docs"
}
```

### 3. 特殊字符转义

JSON 文件中需要转义以下字符：

```json
{
  "theme.admonition.warning": "注意：使用 \\"双引号\\" 和 \\'单引号\\'"
}
```

### 4. 日期和数字格式

考虑本地化格式：

```json
{
  "theme.blog.post.date": "{{date, MMMM D, YYYY}}",
  "theme.blog.post.readTime": "{{readingTime}} 分钟",
  "theme.blog.post.readingTime.plural": "One min read|{{readingTime}} min read"
}
```

## 翻译内容

### 导航和侧边栏

```json
{
  "theme.NavBar.navDocs.label": "文档",
  "theme.NavBar.navInstallation.label": "安装指南",
  "theme.NavBar.navUsage.label": "使用指南",
  "theme.NavBar.navCases.label": "实战案例",
  "theme.NavBar.navMirror.label": "镜像源配置",
  "theme.NavBar.navHelp.label": "帮助中心"
}
```

### 页面标题和描述

```json
{
  "docs.tutorials.introduction.title": "Docker 基础概念",
  "docs.tutorials.introduction.description": "学习 Docker 的核心概念，包括容器、镜像和注册表"
}
```

### 按钮和表单标签

```json
{
  "theme.common.copy": "复制",
  "theme.common.copied": "已复制",
  "theme.common.backToTop": "回到顶部",
  "theme.common.next": "下一页",
  "theme.common.previous": "上一页"
}
```

### 提示信息和错误消息

```json
{
  "theme.admonition.note": "提示",
  "theme.admonition.tip": "技巧",
  "theme.admonition.info": "信息",
  "theme.admonition.warning": "警告",
  "theme.admonition.caution": "注意",
  "theme.admonition.danger": "危险"
}
```

## 翻译文件示例

### 英语翻译示例 (i18n/en/docusaurus-theme-classic/translations.json)

```json
{
  "label": "English",
  "description": "English translation for Docker Documentation",
  "language": "en-US",
  "direction": "ltr",
  
  "theme.NavBar.navDocs.label": "Docs",
  "theme.NavBar.navInstallation.label": "Installation",
  "theme.NavBar.navUsage.label": "Usage",
  
  "theme.common.copy": "Copy",
  "theme.common.copied": "Copied",
  "theme.common.backToTop": "Back to top",
  
  "theme.admonition.note": "note",
  "theme.admonition.tip": "tip",
  "theme.admonition.info": "info",
  "theme.admonition.warning": "warning",
  "theme.admonition.danger": "danger",
  "theme.admonition.caution": "caution"
  
  "theme.SearchBar.search": "Search",
  "theme.SearchBar.label": "Search...",
  "theme.SearchBar.noResults": "No results found"
}
```

### 德语翻译示例 (i18n/de/docusaurus-theme-classic/translations.json)

```json
{
  "label": "Deutsch",
  "description": "German translation for Docker Documentation",
  "language": "de-DE",
  "direction": "ltr",
  
  "theme.NavBar.navDocs.label": "Dokumentation",
  "theme.NavBar.navInstallation.label": "Installation",
  "theme.NavBar.navUsage.label": "Verwendung",
  
  "theme.common.copy": "Kopieren",
  "theme.common.copied": "Kopiert",
  "theme.common.backToTop": "Zurück nach oben",
  
  "theme.admonition.note": "Hinweis",
  "theme.admonition.tip": "Tipp",
  "theme.admonition.info": "Information",
  "theme.admonition.warning": "Warnung",
  "theme.admonition.danger": "Gefahr",
  "theme.admonition.caution": "Vorsicht"
  
  "theme.SearchBar.search": "Suchen",
  "theme.SearchBar.label": "Suchen...",
  "theme.SearchBar.noResults": "Keine Ergebnisse gefunden"
}
```

## 翻译工作流程

### 1. 添加新语言支持

1. 在 `docusaurus.config.js` 中添加语言配置
2. 使用 `generate-translations.js` 生成翻译文件
3. 翻译所有翻译键值
4. 提交翻译到版本控制

### 2. 更新现有翻译

1. 编辑对应语言的 `translations.json` 文件
2. 修改或添加需要翻译的键值
3. 运行 `npm run write-translations --locale {language}``
4. 验证翻译效果

### 3. 检查翻译完整性

```bash
# 使用 Docusaurus 命令检查翻译
npm run write-translations --locale en
npm run write-translations --locale de
npm run write-translations --locale fr
```

## 翻译最佳实践

### 1. 保持一致性

- 使用统一的术语表
- 保持相同概念的翻译一致
- 使用官方或标准的翻译

### 2. 考虑文化差异

- 注意不同地区的表达习惯
- 考虑日期、时间、货币格式
- 避免文化敏感的内容

### 3. 简洁准确

- 避免直译
- 保持简洁明了
- 使用目标语言的自然表达

### 4. 定期更新

- 定期检查过时的翻译
- 根据用户反馈改进翻译
- 同步新内容的翻译

## 质量检查清单

- [ ] 所有翻译键都有对应翻译
- [ ] 翻译符合目标语言习惯
- [ ] 没有拼写或语法错误
- [ ] 特殊字符正确转义
- [ ] 日期和数字格式正确
- [ ] 技术术语翻译准确
- [ ] 文本长度合理（不要太长或太短）
- [ ] 翻译风格一致

## 常见问题

### Q1: 翻译没有生效？

**解决方案**：

1. 检查 JSON 文件格式是否正确
2. 确保文件保存在正确目录
3. 清理缓存：`npm run clean && npm install`
4. 重启开发服务器：`npm start`
5. 检查浏览器语言设置

### Q2: 如何添加新的翻译键？

**解决方案**：

1. 在所有语言的 `translations.json` 中添加新键
2. 运行 `npm run write-translations` 生成未翻译的字符串
3. 翻译新添加的键值
4. 验证翻译效果

### Q3: 如何处理未翻译的内容？

**解决方案**：

1. 默认使用英语内容作为后备
2. 使用 `{{language}}` 变量显示当前语言
3. 在文档中添加"帮助翻译"链接
4. 鼓励社区贡献翻译

## 贡献翻译

我们欢迎社区贡献翻译改进：

1. Fork 项目到你的 GitHub
2. 修改或添加翻译
3. 提交 Pull Request
4. 描述翻译的改进内容

## 相关资源

- [Docusaurus 翻译文档](https://docusaurus.io/docs/i18n/introduction)
- [i18next 翻译框架](https://www.i18next.com/)
- [本地化最佳实践](https://www.w3.org/International/)

## 联系方式

如有翻译相关问题，请通过以下方式联系：

- GitHub Issues: [提交问题](https://github.com/docker-docs/docker-docs/issues)
- Email: translations@docker-docs.com
- 社区论坛: [Docker 翻译讨论](https://forums.docker.com/)

---

**最后更新**: 2024-01-01  
**维护者**: Docker Docs Team
