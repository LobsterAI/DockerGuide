/** @type {import('@docusaurus/types').Config} */
const {themes} = require('prism-react-renderer');

module.exports = {
  title: 'Docker 文档',
  tagline: 'Docker 容器技术完整指南',
  url: 'https://your-docker-docs.com',
  baseUrl: '/',
  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',
  onDuplicateRoutes: 'warn',
  favicon: 'img/favicon.ico',
  organizationName: 'docker-docs',
  projectName: 'docker-docs',
  deploymentBranch: 'gh-pages',

  i18n: {
    defaultLocale: 'zh',
    locales: ['zh', 'en', 'de', 'fr', 'es', 'ja', 'ko'],
    localeConfigs: {
      zh: {
        label: '简体中文',
        htmlLang: 'zh-CN',
      },
      en: {
        label: 'English',
        htmlLang: 'en-US',
      },
      de: {
        label: 'Deutsch',
        htmlLang: 'de-DE',
      },
      fr: {
        label: 'Français',
        htmlLang: 'fr-FR',
      },
      es: {
        label: 'Español',
        htmlLang: 'es-ES',
      },
      ja: {
        label: '日本語',
        htmlLang: 'ja-JP',
      },
      ko: {
        label: '한국어',
        htmlLang: 'ko-KR',
      },
    },
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: require.resolve('./sidebars.js'),
          editUrl: 'https://github.com/docker-docs/docker-docs/edit/main/',
          showLastUpdateAuthor: true,
          showLastUpdateTime: true,
          routeBasePath: 'docs',
          versions: {
            current: {
              label: '24.0',
              path: '/',
            },
          },
        },
        blog: {
          showReadingTime: true,
          editUrl: 'https://github.com/docker-docs/docker-docs/edit/main/blog/',
          postsPerPage: 5,
        },
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      // 搜索配置
      algolia: {
        appId: 'YOUR_APP_ID',
        apiKey: 'YOUR_API_KEY',
        indexName: 'docker-docs',
        contextualSearch: true,
        searchParameters: {},
        searchPagePath: 'search',
        insights: true,
      },

      // 颜色方案
      colorMode: {
        defaultMode: 'dark',
        disableSwitch: false,
        respectPrefersColorScheme: true,
      },

      // 网站元数据
      metadata: [
        {name: 'keywords', content: 'docker, 容器, container, devops, kubernetes, 微服务'},
        {name: 'description', content: 'Docker 容器技术完整指南，从基础概念到高级实战'},
        {property: 'og:title', content: 'Docker 文档'},
        {property: 'og:description', content: 'Docker 容器技术完整指南'},
        {property: 'og:type', content: 'website'},
        {property: 'og:url', content: 'https://your-docker-docs.com'},
        {property: 'og:image', content: 'https://your-docker-docs.com/img/og-image.png'},
        {name: 'twitter:card', content: 'summary_large_image'},
        {name: 'twitter:title', content: 'Docker 文档'},
        {name: 'twitter:description', content: 'Docker 容器技术完整指南'},
        {name: 'twitter:image', content: 'https://your-docker-docs.com/img/og-image.png'},
      ],

      navbar: {
        title: 'Docker 文档',
        logo: {
          alt: 'Docker Logo',
          src: 'img/logo.svg',
        },
        items: [
          {
            type: 'doc',
            docId: 'index',
            position: 'left',
            label: '教程',
          },
          {
            type: 'doc',
            docId: 'installation/index',
            position: 'left',
            label: '安装指南',
          },
          {
            type: 'doc',
            docId: 'usage/index',
            position: 'left',
            label: '使用指南',
          },
          {
            type: 'doc',
            docId: 'cases/index',
            position: 'left',
            label: '实战案例',
          },
          {
            type: 'doc',
            docId: 'mirror/index',
            position: 'left',
            label: '镜像源配置',
          },
          {
            type: 'doc',
            docId: 'help/index',
            position: 'left',
            label: '帮助中心',
          },
          {
            type: 'docsVersionDropdown',
            position: 'right',
            dropdownItemsAfter: [
              {
                to: '/versions',
                label: '所有版本',
              },
            ],
            dropdownActiveClassDisabled: true,
          },
          {
            type: 'localeDropdown',
            position: 'right',
          },
          {
            type: 'search',
            position: 'right',
          },
          {
            href: 'https://github.com/docker-docs/docker-docs',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },

      footer: {
        style: 'dark',
        links: [
          {
            title: '文档',
            items: [
              {
                label: '教程',
                to: '/docs/',
              },
              {
                label: '安装指南',
                to: '/docs/installation/',
              },
              {
                label: '使用指南',
                to: '/docs/usage/',
              },
              {
                label: '实战案例',
                to: '/docs/cases/',
              },
            ],
          },
          {
            title: '社区',
            items: [
              {
                label: 'GitHub',
                href: 'https://github.com/docker-docs/docker-docs',
              },
              {
                label: 'Stack Overflow',
                href: 'https://stackoverflow.com/questions/tagged/docker',
              },
              {
                label: 'Discord',
                href: 'https://discord.gg/docker',
              },
              {
                label: 'Twitter',
                href: 'https://twitter.com/docker',
              },
            ],
          },
          {
            title: '更多',
            items: [
              {
                label: '博客',
                to: '/blog',
              },
              {
                label: '更新日志',
                to: '/changelog',
              },
              {
                label: '贡献指南',
                to: '/docs/contribute',
              },
            ],
          },
        ],
        copyright: `Copyright © ${new Date().getFullYear()} Docker Docs. Built with Docusaurus.`,
      },

      prism: {
        theme: themes.oceanic,
        darkTheme: themes.palenight,
        additionalLanguages: [
          'bash',
          'dockerfile',
          'yaml',
          'json',
          'typescript',
          'javascript',
          'go',
          'python',
          'java',
          'php',
          'ruby',
          'shell',
        ],
        magicComments: [
          {
            className: 'theme-code-block-highlighted-line',
            line: 'highlight-next-line',
            block: {start: 'highlight-start', end: 'highlight-end'},
          },
          {
            className: 'code-block-focus-line',
            line: 'focus-next-line',
            block: {start: 'focus-start', end: 'focus-end'},
          },
        ],
      },

      docs: {
        sidebar: {
          hideable: true,
          autoCollapseCategories: false,
        },
      },
    }),

  plugins: [
    [
      '@docusaurus/plugin-client-redirects',
      {
        createRedirects: function (existingPath) {
          return [
            existingPath + '/index.html',
          ];
        },
      },
    ],
    [
      '@docusaurus/plugin-sitemap',
      {
        changefreq: 'weekly',
        priority: 0.5,
        trailingSlash: false,
      },
    ],
  ],

  // 自定义主题颜色
  customFields: {
    primaryColor: '#3498db',
    secondaryColor: '#2c3e50',
  },
};