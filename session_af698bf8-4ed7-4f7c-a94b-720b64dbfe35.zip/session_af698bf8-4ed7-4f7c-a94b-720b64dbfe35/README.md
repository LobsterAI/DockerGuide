# Docker 文档网站

基于 Docusaurus 框架构建的 Docker 容器技术完整文档网站，支持多语言、暗色/亮色主题切换，提供 Docker 教程、安装指南、使用指南、实战案例等内容。

## ✨ 特性

- 🌍 **多语言支持**: 中文、英语、德语、法语、西班牙语、日语、韩语
- 🎨 **主题切换**: 支持暗色和亮色主题
- 🔍 **全文搜索**: 基于 Algolia 的强大搜索功能
- 📱 **响应式设计**: 完美适配桌面端和移动端
- 🚀 **快速构建**: 基于 Docusaurus 3.x，构建速度快
- 🎯 **SEO 优化**: 针对搜索引擎优化的元数据和结构
- 📦 **Docker 支持**: 提供 Dockerfile 和 Docker Compose 配置
- 🔄 **自动部署**: 支持 GitHub Actions、Vercel、Netlify、Cloudflare Pages

## 📋 目录

- [快速开始](#快速开始)
- [本地开发](#本地开发)
- [构建部署](#构建部署)
- [多语言配置](#多语言配置)
- [主题定制](#主题定制)
- [贡献指南](#贡献指南)
- [许可证](#许可证)

## 🚀 快速开始

### 知识准备

在开始之前，请确保你的环境中已安装：

- [Node.js](https://nodejs.org/) 18.x 或更高版本
- [npm](https://www.npmjs.com/) 9.x 或更高版本
- [Git](https://git-scm.com/)

### 克隆项目

```bash
git clone https://github.com/your-username/docker-docs.git
cd docker-docs
```

### 安装依赖

```bash
npm install
```

### 启动开发服务器

```bash
npm start
```

访问 http://localhost:3000 查看网站。

## 💻 本地开发

### 开发命令

```bash
# 启动开发服务器
npm start

# 构建网站
npm run build

# 启动生产服务器
npm run serve

# 清理构建文件
npm run clean

# 生成翻译文件
npm run write-translations

# 生成标题 ID
npm run write-heading-ids

# 类型检查
npm run typecheck
```

### 开发环境配置

1. **安装开发依赖**

```bash
npm install
```

2. **启动开发服务器**

```bash
npm start
```

3. **自动打开浏览器**

开发服务器启动后会自动在浏览器中打开网站，默认地址为 `http://localhost:3000`。

4. **热模块替换**

修改文件后，页面会自动刷新，无需手动刷新浏览器。

### 调试技巧

- 使用浏览器开发者工具调试样式和脚本
- 查看 Docusaurus 控制台输出了解构建状态
- 使用 `--port` 参数指定开发服务器端口：
  ```bash
  npm start -- --port 8080
  ```

## 🏗️ 构建部署

### 构建网站

```bash
npm run build
```

构建产物将生成在 `build/` 目录中。

### 本地预览构建结果

```bash
npm run serve
```

### 部署到 GitHub Pages

1. **配置 GitHub Actions**

确保 `.github/workflows/deploy.yml` 文件存在并正确配置。

2. **设置 GitHub Secrets**

在 GitHub 仓库设置中添加以下 Secrets（如果需要）：
- `GITHUB_TOKEN`: 自动提供
- `VERCEL_TOKEN`: 用于 Vercel 部署（可选）
- `NETLIFY_AUTH_TOKEN`: 用于 Netlify 部署（可选）

3. **推送到 GitHub**

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

GitHub Actions 会自动构建并部署网站到 GitHub Pages。

### 部署到 Vercel

1. **安装 Vercel CLI**

```bash
npm install -g vercel
```

2. **部署到 Vercel**

```bash
vercel
```

按照提示完成部署配置。

3. **配置环境变量**

在 Vercel 控制台中配置必要的环境变量（如果需要）。

### 部署到 Netlify

1. **连接 Netlify**

在 Netlify 控制台中连接你的 GitHub 仓库。

2. **配置构建设置**

- **Build command**: `npm run build`
- **Publish directory**: `build`
- **Node version**: 18

3. **部署**

Netlify 会自动监听仓库变化并部署。

### 部署到 Cloudflare Pages

1. **安装 Wrangler CLI**

```bash
npm install -g wrangler
```

2. **构建并部署**

```bash
npm run build
wrangler pages deploy build
```

## 🐳 Docker 部署

### 使用 Dockerfile

```bash
# 构建镜像
docker build -t docker-docs .

# 运行容器
docker run -d -p 3000:3000 --name docker-docs docker-docs
```

### 使用 Docker Compose

```bash
# 启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

### 环境变量

可以通过环境变量配置应用：

```bash
docker run -d \
  -p 3000:3000 \
  -e NODE_ENV=production \
  -e PORT=3000 \
  --name docker-docs \
  docker-docs
```

## 🌍 多语言配置

### 添加新语言

1. **更新 docusaurus.config.js**

```javascript
i18n: {
  defaultLocale: 'zh',
  locales: ['zh', 'en', 'de', 'fr', 'es', 'ja', 'ko', 'your-locale'],
},
```

2. **创建翻译目录**

```bash
mkdir -p i18n/your-locale/docusaurus-plugin-content-docs/current
```

3. **复制并翻译文件**

```bash
cp -r docs/* i18n/your-locale/docusaurus-plugin-content-docs/current/
```

4. **生成翻译文件**

```bash
npm run write-translations --locale your-locale
```

### 翻译现有内容

1. **编辑翻译文件**

翻译 `i18n/{locale}/docusaurus-plugin-content-docs/current/` 目录下的 Markdown 文件。

2. **翻译配置文件**

翻译 `i18n/{locale}/docusaurus-theme-classic/` 目录下的 JSON 文件。

3. **测试翻译**

```bash
npm start --locale your-locale
```

## 🎨 主题定制

### 自定义颜色

编辑 `src/css/custom.css` 文件：

```css
:root {
  --ifm-color-primary: #3498db;
  --ifm-color-primary-dark: #2980b9;
  --ifm-color-primary-light: #5dade2;
}

[data-theme='dark'] {
  --ifm-color-primary: #5dade2;
  --ifm-color-primary-dark: #3498db;
}
```

### 自定义字体

在 `src/css/custom.css` 中添加：

```css
body {
  font-family: 'Your Font', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
```

### 自定义布局

创建自定义组件：

```bash
mkdir -p src/theme
```

创建 `src/theme/Footer/index.js`：

```javascript
import React from 'react';

export default function Footer() {
  return (
    <footer>
      {/* Your custom footer content */}
    </footer>
  );
}
```

## 📚 项目结构

```
docker-docs/
├── docs/                 # 文档内容
│   ├── introduction.md    # 介绍页面
│   ├── installation/     # 安装指南
│   └── usage/           # 使用指南
├── i18n/               # 多语言翻译文件
├── src/                # 源代码
│   ├── css/            # 自定义样式
│   ├── js/             # 自定义脚本
│   └── theme/          # 自定义主题组件
├── static/             # 静态资源
├── docusaurus.config.js # Docusaurus 配置
├── sidebars.js         # 侧边栏配置
├── package.json        # 项目依赖
├── Dockerfile          # Docker 镜像配置
├── docker-compose.yml   # Docker Compose 配置
├── vercel.json        # Vercel 部署配置
├── netlify.toml       # Netlify 部署配置
└── README.md          # 项目说明
```

## 🤝 贡献指南

我们欢迎所有形式的贡献！

### 贡献方式

1. **报告问题**: 在 GitHub Issues 中报告 Bug 或提出功能请求
2. **提交代码**: Fork 项目，创建特性分支，提交 Pull Request
3. **改进文档**: 修复错别字、改进示例、添加新内容
4. **翻译文档**: 帮助将文档翻译成更多语言

### 开发流程

1. **Fork 项目**

```bash
# Fork 并克隆你的 Fork
git clone https://github.com/your-username/docker-docs.git
cd docker-docs
```

2. **创建特性分支**

```bash
git checkout -b feature/your-feature-name
```

3. **进行修改**

```bash
# 编辑文件
vim docs/example.md

# 查看更改
git diff
```

4. **提交更改**

```bash
git add .
git commit -m "Add your feature"
```

5. **推送到 GitHub**

```bash
git push origin feature/your-feature-name
```

6. **创建 Pull Request**

在 GitHub 上创建 Pull Request，描述你的更改。

### 代码规范

- 使用 2 空格缩进
- 使用单引号
- 遵循 ESLint 配置
- 编写有意义的提交信息

### 文档规范

- 使用清晰的标题结构
- 提供代码示例
- 添加适当的链接
- 包含必要的截图

## 📝 内容组织

### 文档结构

- **教程**: Docker 基础概念和入门指南
- **安装**: 各平台安装指南
- **使用**: 容器、镜像、网络、存储等使用指南
- **案例**: 实战案例和最佳实践
- **镜像源**: 镜像加速配置
- **帮助**: 常见问题和故障排除

### 编写指南

1. **使用 Markdown**

使用 Markdown 语法编写文档，Docusaurus 支持 MDX。

2. **添加元数据**

在 Markdown 文件顶部添加 frontmatter：

```markdown
---
id: your-page-id
title: Your Page Title
description: A brief description of the page
---

# Your Content
```

3. **代码块**

使用代码块时指定语言：

````
\```bash
docker run hello-world
\```
````

4. **使用组件**

Docusaurus 提供了许多内置组件：

```mdx
import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

<Tabs>
  <TabItem value="linux" label="Linux">
    Linux specific content
  </TabItem>
  <TabItem value="windows" label="Windows">
    Windows specific content
  </TabItem>
</Tabs>
```

## 🛠️ 故障排除

### 常见问题

**问题 1: 构建失败**

```bash
# 清理缓存并重新构建
npm run clean
npm install
npm run build
```

**问题 2: 依赖冲突**

```bash
# 删除 node_modules 和 package-lock.json
rm -rf node_modules package-lock.json
npm install
```

**问题 3: 端口被占用**

```bash
# 使用其他端口
npm start -- --port 8080
```

### 获取帮助

- 查看 [Docusaurus 文档](https://docusaurus.io/)
- 在 GitHub 上 [提交 Issue](https://github.com/docker-docs/docker-docs/issues)
- 加入 [Discord 社区](https://discord.gg/docusaurus)

## 📄 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

## 🙏 致谢

- [Docusaurus](https://docusaurus.io/) - 强大的文档网站框架
- [Docker](https://www.docker.com/) - 优秀的容器化平台
- 所有贡献者 - 感谢你们的贡献

## 📞 联系方式

- GitHub: [docker-docs](https://github.com/docker-docs/docker-docs)
- Email: support@docker-docs.com
- 网站: https://your-docker-docs.com

---

**Made with ❤️ by CodeGeeX**
