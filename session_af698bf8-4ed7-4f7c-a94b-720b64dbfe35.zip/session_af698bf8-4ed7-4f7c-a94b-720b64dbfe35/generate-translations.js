#!/usr/bin/env node

/**
 * Docker 文档网站翻译文件生成脚本
 * 
 * 使用方法:
 * node generate-translations.js [language]
 * 
 * 参数:
 *   language - 可选，指定要生成的语言（默认所有语言）
 */

const fs = require('fs');
const path = require('path');

// 支持的语言列表
const LANGUAGES = ['en', 'de', 'fr', 'es', 'ja', 'ko'];

// 语言显示名称
const LANGUAGE_NAMES = {
  en: 'English',
  de: 'Deutsch',
  fr: 'Français',
  es: 'Español',
  ja: '日本語',
  ko: '한국어'
};

// 翻译内容模板
const translationTemplate = {
  // 导航和侧边栏
  'theme.NavBar.navDocs.label': {
    en: 'Docs',
    de: 'Dokumentation',
    fr: 'Documentation',
    es: 'Documentación',
    ja: 'ドキュメント',
    ko: '문서'
  },
  'theme.NavBar.navInstallation.label': {
    en: 'Installation',
    de: 'Installation',
    fr: 'Installation',
    es: 'Instalación',
    ja: 'インストール',
    ko: '설치'
  },
  'theme.NavBar.navUsage.label': {
    en: 'Usage',
    de: 'Verwendung',
    fr: 'Utilisation',
    es: 'Uso',
    ja: '使用法',
    ko: '사용법'
  },
  'theme.NavBar.navCases.label': {
    en: 'Cases',
    de: 'Fälle',
    fr: 'Cas',
    es: 'Casos',
    ja: '事例',
    ko: '사례'
  },
  'theme.NavBar.navMirror.label': {
    en: 'Mirror',
    de: 'Spiegel',
    fr: 'Miroir',
    es: 'Espejo',
    ja: 'ミラー',
    ko: '미러'
  },
  'theme.NavBar.navHelp.label': {
    en: 'Help',
    de: 'Hilfe',
    fr: 'Aide',
    es: 'Ayuda',
    ja: 'ヘルプ',
    ko: '도움말'
  },
  
  // 侧边栏 - 主要分类
  'sidebar.docs.category.index.label': {
    en: 'Docker Introduction',
    de: 'Docker Einführung',
    fr: 'Introduction à Docker',
    es: 'Introducción a Docker',
    ja: 'Docker入門',
    ko: 'Docker 소개'
  },
  'sidebar.docs.category.tutorials.label': {
    en: 'Docker Tutorials',
    de: 'Docker Tutorials',
    fr: 'Tutoriels Docker',
    es: 'Tutoriales de Docker',
    ja: 'Dockerチュートリアル',
    ko: 'Docker 튜토리얼'
  },
  'sidebar.docs.category.installation.label': {
    en: 'Installation Guide',
    de: 'Installationsanleitung',
    fr: 'Guide d\\'installation',
    es: 'Guía de instalación',
    ja: 'インストールガイド',
    ko: '설치 가이드'
  },
  'sidebar.docs.category.usage.label': {
    en: 'Usage Guide',
    de: 'Verwendungshandbuch',
    fr: 'Guide d\\'utilisation',
    es: 'Guía de uso',
    ja: '使用ガイド',
    ko: '사용 가이드'
  },
  'sidebar.docs.category.cases.label': {
    en: 'Practical Cases',
    de: 'Praktische Fälle',
    fr: 'Cas Pratiques',
    es: 'Casos Prácticos',
    ja: '実践事例',
    ko: '실용 사례'
  },
  'sidebar.docs.category.mirror.label': {
    en: 'Mirror Configuration',
    de: 'Mirror-Konfiguration',
    fr: 'Configuration Miroir',
    es: 'Configuración Espejo',
    ja: 'ミラー設定',
    ko: '미러 설정'
  },
  'sidebar.docs.category.help.label': {
    en: 'Help Center',
    de: 'Hilfezentrum',
    fr: 'Centre d\\'aide',
    es: 'Centro de ayuda',
    ja: 'ヘルプセンター',
    ko: '도움말 센터'
  },
  
  // 教程子分类
  'sidebar.docs.tutorials.category.introduction.label': {
    en: 'Basic Concepts',
    de: 'Grundkonzepte',
    fr: 'Concepts de base',
    es: 'Conceptos básicos',
    ja: '基本概念',
    ko: '기본 개념'
  },
  'sidebar.docs.tutorials.category.architecture.label': {
    en: 'Architecture',
    de: 'Architektur',
    fr: 'Architecture',
    es: 'Arquitectura',
    ja: 'アーキテクチャ',
    ko: '아키텍처'
  },
  'sidebar.docs.tutorials.category.commands.label': {
    en: 'Command Reference',
    de: 'Befehlsreferenz',
    fr: 'Référence des commandes',
    es: 'Referencia de comandos',
    ja: 'コマンドリファレンス',
    ko: '명령어 참조'
  },
  
  // 通用文本
  'theme.common.skipToMainContent': {
    en: 'Skip to main content',
    de: 'Zum Hauptinhalt springen',
    fr: 'Aller au contenu principal',
    es: 'Saltar al contenido principal',
    ja: 'メインコンテンツへスキップ',
    ko: '주요 콘텐츠로 건너뛰기'
  },
  'theme.common.heading.description': {
    en: 'Description',
    de: 'Beschreibung',
    fr: 'Description',
    es: 'Descripción',
    ja: '説明',
    ko: '설명'
  },
  'theme.common.heading.installation': {
    en: 'Installation',
    de: 'Installation',
    fr: 'Installation',
    es: 'Instalación',
    ja: 'インストール',
    ko: '설치'
  },
  'theme.common.heading.usage': {
    en: 'Usage',
    de: 'Verwendung',
    fr: 'Utilisation',
    es: 'Uso',
    ja: '使用法',
    ko: '사용법'
  },
  
  // 按钮和操作
  'theme.common.copy': {
    en: 'Copy',
    de: 'Kopieren',
    fr: 'Copier',
    es: 'Copiar',
    ja: 'コピー',
    ko: '복사'
  },
  'theme.common.copied': {
    en: 'Copied',
    de: 'Kopiert',
    fr: 'Copié',
    es: 'Copiado',
    ja: 'コピー済み',
    ko: '복사됨'
  },
  'theme.common.backToTop': {
    en: 'Back to top',
    de: 'Zurück nach oben',
    fr: 'Retour en haut',
    es: 'Volver arriba',
    ja: 'トップに戻る',
    ko: '맨 위로'
  },
  'theme.common.next': {
    en: 'Next',
    de: 'Weiter',
    fr: 'Suivant',
    es: 'Siguiente',
    ja: '次へ',
    ko: '다음'
  },
  'theme.common.previous': {
    en: 'Previous',
    de: 'Zurück',
    fr: 'Précédent',
    es: 'Anterior',
    ja: '前へ',
    ko: '이전'
  },
  'theme.common.learnMore': {
    en: 'Learn more',
    de: 'Mehr erfahren',
    fr: 'En savoir plus',
    es: 'Más información',
    ja: '詳細を見る',
    ko: '자세히 보기'
  },
  'theme.common.getStarted': {
    en: 'Get Started',
    de: 'Loslegen',
    fr: 'Commencer',
    es: 'Empezar',
    ja: '始める',
    ko: '시작하기'
  },
  'theme.common.tryNow': {
    en: 'Try Now',
    de: 'Jetzt ausprobieren',
    fr: 'Essayer maintenant',
    es: 'Probar ahora',
    ja: '今すぐ試す',
    ko: '지금 시도'
  },
  'theme.common.download': {
    en: 'Download',
    de: 'Herunterladen',
    fr: 'Télécharger',
    es: 'Descargar',
    ja: 'ダウンロード',
    ko: '다운로드'
  },
  'theme.common.viewSource': {
    en: 'View Source',
    de: 'Quellcode anzeigen',
    fr: 'Voir la source',
    es: 'Ver fuente',
    ja: 'ソースを表示',
    ko: '소스 보기'
  },
  'theme.common.editPage': {
    en: 'Edit this page',
    de: 'Diese Seite bearbeiten',
    fr: 'Modifier cette page',
    es: 'Editar esta página',
    ja: 'このページを編集',
    ko: '이 페이지 편집'
  },
  
  // 提示和警告
  'theme.admonition.note': {
    en: 'note',
    de: 'Hinweis',
    fr: 'note',
    es: 'nota',
    ja: 'メモ',
    ko: '참고'
  },
  'theme.admonition.tip': {
    en: 'tip',
    de: 'Tipp',
    fr: 'astuce',
    es: 'consejo',
    ja: 'ヒント',
    ko: '팁'
  },
  'theme.admonition.info': {
    en: 'info',
    de: 'Information',
    fr: 'information',
    es: 'información',
    ja: '情報',
    ko: '정보'
  },
  'theme.admonition.warning': {
    en: 'warning',
    de: 'Warnung',
    fr: 'avertissement',
    es: 'advertencia',
    ja: '警告',
    ko: '경고'
  },
  'theme.admonition.danger': {
    en: 'danger',
    de: 'Gefahr',
    fr: 'danger',
    es: 'peligro',
    ja: '危険',
    ko: '위험'
  },
  'theme.admonition.caution': {
    en: 'caution',
    de: 'Vorsicht',
    fr: 'prudence',
    es: 'precaución',
    ja: '注意',
    ko: '주의'
  },
  
  // 搜索相关
  'theme.SearchBar.search': {
    en: 'Search',
    de: 'Suchen',
    fr: 'Rechercher',
    es: 'Buscar',
    ja: '検索',
    ko: '검색'
  },
  'theme.SearchBar.label': {
    en: 'Search...',
    de: 'Suchen...',
    fr: 'Rechercher...',
    es: 'Buscar...',
    ja: '検索...',
    ko: '검색...'
  },
  'theme.SearchBar.noResults': {
    en: 'No results found',
    de: 'Keine Ergebnisse gefunden',
    fr: 'Aucun résultat trouvé',
    es: 'No se encontraron resultados',
    ja: '結果が見つかりません',
    ko: '검색 결과가 없습니다'
  },
  
  // 分页
  'theme.Paginator.navAriaLabel': {
    en: 'Blog list page navigation',
    de: 'Blog-Listen-Seitennavigation',
    fr: 'Navigation de la liste des pages du blog',
    es: 'Navegación de la lista de páginas del blog',
    ja: 'ブログ一覧ページナビゲーション',
    ko: '블로그 목록 페이지 탐색'
  },
  'theme.Paginator.navPrevious': {
    en: 'Previous',
    de: 'Zurück',
    fr: 'Précédent',
    es: 'Anterior',
    ja: '前へ',
    ko: '이전'
  },
  'theme.Paginator.navNext': {
    en: 'Next',
    de: 'Weiter',
    fr: 'Suivant',
    es: 'Siguiente',
    ja: '次へ',
    ko: '다음'
  },
  
  // 页脚
  'theme.Footer.copyright': {
    en: 'Copyright © {{year}} Docker Docs. Built with Docusaurus.',
    de: 'Urheberrecht © {{year}} Docker-Dokumentation. Erstellt mit Docusaurus.',
    fr: 'Copyright © {{year}} Documentation Docker. Construit avec Docusaurus.',
    es: 'Derechos de autor © {{year}} Documentación Docker. Construido con Docusaurus.',
    ja: 'Copyright © {{year}} Dockerドキュメント。Docusaurusで構築されています。',
    ko: '저작권 © {{year}} Docker 문서. Docusaurus로 구축되었습니다.'
  },
  'theme.Footer.link.title.documentation': {
    en: 'Documentation',
    de: 'Dokumentation',
    fr: 'Documentation',
    es: 'Documentación',
    ja: 'ドキュメント',
    ko: '문서'
  },
  'theme.Footer.link.title.community': {
    en: 'Community',
    de: 'Community',
    fr: 'Communauté',
    es: 'Comunidad',
    ja: 'コミュニティ',
    ko: '커뮤니티'
  },
  'theme.Footer.link.title.more': {
    en: 'More',
    de: 'Mehr',
    fr: 'En savoir plus',
    es: 'Más',
    ja: 'もっと見る',
    ko: '더보기'
  },
  
  // 版本选择器
  'theme.VersionsDropdown.label': {
    en: 'Version',
    de: 'Version',
    fr: 'Version',
    es: 'Versión',
    ja: 'バージョン',
    ko: '버전'
  },
  'theme.VersionsDropdown.title': {
    en: 'Docker versions',
    de: 'Docker-Versionen',
    fr: 'Versions de Docker',
    es: 'Versiones de Docker',
    ja: 'Dockerバージョン',
    ko: 'Docker 버전'
  },
  
  // 代码块
  'theme.CodeBlock.copyButtonAriaLabel': {
    en: 'Copy code to clipboard',
    de: 'Code in die Zwischenablage kopieren',
    fr: 'Copier le code dans le presse-papier',
    es: 'Copiar código al portapapeles',
    ja: 'コードをクリップボードにコピー',
    ko: '코드를 클립보드에 복사'
  },
  'theme.CodeBlock.copiedAriaLabel': {
    en: 'Copied',
    de: 'Kopiert',
    fr: 'Copié',
    es: 'Copiado',
    ja: 'コピー済み',
    ko: '복사됨'
  },
  
  // 错误页面
  'theme.NotFound.title': {
    en: 'Page Not Found',
    de: 'Seite nicht gefunden',
    fr: 'Page non trouvée',
    es: 'Página no encontrada',
    ja: 'ページが見つかりません',
    ko: '페이지를 찾을 수 없습니다'
  },
  'theme.NotFound.p1': {
    en: 'We could not find what you were looking for.',
    de: 'Wir konnten das Gewünschte nicht finden.',
    fr: 'Nous n\\'avons pas trouvé ce que vous cherchiez.',
    es: 'No pudimos encontrar lo que estabas buscando.',
    ja: 'お探しのものが見つかりませんでした。',
    ko: '찾으시는 것을 찾을 수 없습니다.'
  },
  'theme.NotFound.p2': {
    en: 'Please contact the owner of the site that linked you to the original URL and let them know their link is broken.',
    de: 'Bitte kontaktieren Sie den Betreiber der Website, die Sie hierher geführt hat, und teilen Sie ihnen mit, dass ihr Link defekt ist.',
    fr: 'Veuillez contacter le propriétaire du site qui vous a redirigé ici et lui faire savoir que son lien est cassé.',
    es: 'Por favor, contacte al propietario del sitio que te enlazó al URL original y hazle saber que su enlace está roto.',
    ja: '元のURLにリンクしたサイトの管理者に連絡し、リンクが壊れていることを知らせてください。',
    ko: '원본 URL에 연결한 사이트 소유자에게 문의하고 링크가 깨져 있다는 것을 알려주세요.'
  },
  
  // 文档侧边栏
  'docs.DocCard.categoryDescription': {
    en: 'Find out what you need to know to get started.',
    de: 'Erfahren Sie, was Sie wissen müssen, um loszulegen.',
    fr: 'Découvrez ce que vous devez savoir pour commencer.',
    es: 'Averigüe lo que necesita saber para comenzar.',
    ja: '始めるために知っておくべきことを確認してください。',
    ko: '시작하는 데 필요한 것을 알아보세요.'
  },
  'docs.DocCard.categoryTitle': {
    en: 'Docker Tutorial',
    de: 'Docker Tutorial',
    fr: 'Tutoriel Docker',
    es: 'Tutorial de Docker',
    ja: 'Dockerチュートリアル',
    ko: 'Docker 튜토리얼'
  },
  'docs.sidebar.docs.category.index.label': {
    en: 'Docker Introduction',
    de: 'Docker Einführung',
    fr: 'Introduction à Docker',
    es: 'Introducción a Docker',
    ja: 'Docker入門',
    ko: 'Docker 소개'
  },
  
  // 实战案例
  'cases.index.title': {
    en: 'Docker Practical Cases Overview',
    de: 'Übersicht der Docker Praxisfälle',
    fr: 'Vue d\\'ensemble des cas pratiques Docker',
    es: 'Resumen de casos prácticos de Docker',
    ja: 'Docker実践事例概要',
    ko: 'Docker 실용 사례 개요'
  },
  'cases.index.description': {
    en: 'Comprehensive collection of Docker practical cases, from simple web deployment to complex microservices architecture.',
    de: 'Umfassende Sammlung von Docker Praxisfällen, von einfacher Web-Bereitstellung bis hin zu komplexen Mikroservices-Architekturen.',
    fr: 'Collection complète de cas pratiques Docker, du déploiement web simple aux architectures microservices complexes.',
    es: 'Colección completa de casos prácticos de Docker, desde despliegues web simples hasta arquitecturas de microservicios complejas.',
    ja: 'シンプルなWebデプロイから複雑なマイクロサービスアーキテクチャまで、Docker実践事例の包括的なコレクション。',
    ko: '단순한 웹 배포부터 복잡한 마이크로서비스 아키텍처까지 Docker 실용 사례의 포괄적인 컬렉션입니다.'
  },
  
  // 网站标语
  'site.tagline': {
    en: 'Complete Guide to Docker Container Technology',
    de: 'Umfassender Leitfaden für Docker-Container-Technologie',
    fr: 'Guide complet de la technologie de conteneurs Docker',
    es: 'Guía completa de la tecnología de contenedores Docker',
    ja: 'Dockerコンテナ技術の包括的なガイド',
    ko: 'Docker 컨테이너 기술의 포괄적인 가이드'
  },
  
  // 标题
  'site.title': {
    en: 'Docker Documentation',
    de: 'Docker-Dokumentation',
    fr: 'Documentation Docker',
    es: 'Documentación de Docker',
    ja: 'Dockerドキュメント',
    ko: 'Docker 문서'
  },
  
  // 操作
  'theme.TOCCollapsible.toggleButtonLabel': {
    en: 'Toggle sidebar',
    de: 'Seitenleiste umschalten',
    fr: 'Basculer la barre latérale',
    es: 'Alternar barra lateral',
    ja: 'サイドバーを切り替え',
    ko: '사이드바 전환'
  },
  'theme.TOCCollapsible.expandButtonLabel': {
    en: 'Expand',
    de: 'Erweitern',
    fr: 'Développer',
    es: 'Expandir',
    ja: '展開',
    ko: '확장'
  },
  'theme.TOCCollapsible.collapseButtonLabel': {
    en: 'Collapse',
    de: 'Zusammenklappen',
    fr: 'Réduire',
    es: 'Contraer',
    ja: '折りたたむ',
    ko: '축소'
  },
  
  // 博客
  'theme.blog.paginator.navAriaLabel': {
    en: 'Blog list page navigation',
    de: 'Blog-Listen-Seitennavigation',
    fr: 'Navigation de la liste des pages du blog',
    es: 'Navegación de la lista de páginas del blog',
    ja: 'ブログ一覧ページナビゲーション',
    ko: '블로그 목록 페이지 탐색'
  },
  'theme.blog.paginator.navPrevious': {
    en: 'Previous',
    de: 'Zurück',
    fr: 'Précédent',
    es: 'Anterior',
    ja: '前へ',
    ko: '이전'
  },
  'theme.blog.paginator.navNext': {
    en: 'Next',
    de: 'Weiter',
    fr: 'Suivant',
    es: 'Siguiente',
    ja: '次へ',
    ko: '다음'
  },
  'theme.blog.post.readingTime.plural': {
    en: 'One min read|{{readingTime}} min read',
    de: 'Eine Minute Lesezeit|{{readingTime}} Minuten Lesezeit',
    fr: 'Une minute de lecture|{{readingTime}} minutes de lecture',
    es: 'Un minuto de lectura|{{readingTime}} minutos de lectura',
    ja: '読むのに1分|{{readingTime}}分で読める',
    ko: '읽는 데 1분|{{readingTime}}분 소요'
  },
  'theme.blog.post.readMore': {
    en: 'Read More',
    de: 'Mehr lesen',
    fr: 'Lire la suite',
    es: 'Leer más',
    ja: '続きを読む',
    ko: '더 읽기'
  },
  'theme.blog.post.title': {
    en: '{{title}}',
    de: '{{title}}',
    fr: '{{title}}',
    es: '{{title}}',
    ja: '{{title}}',
    ko: '{{title}}'
  },
  'theme.blog.post.date': {
    en: '{{date}}',
    de: '{{date}}',
    fr: '{{date}}',
    es: '{{date}}',
    ja: '{{date}}',
    ko: '{{date}}'
  },
  'theme.blog.post.readTime': {
    en: '{{readingTime}} min read',
    de: '{{readingTime}} Minuten Lesezeit',
    fr: '{{readingTime}} minutes de lecture',
    es: '{{readingTime}} minutos de lectura',
    ja: '{{readingTime}}分で読める',
    ko: '읽는 데 {{readingTime}}분 소요'
  },
  'theme.blog.post.tags': {
    en: 'Tags',
    de: 'Schlagwörter',
    fr: 'Tags',
    es: 'Etiquetas',
    ja: 'タグ',
    ko: '태그'
  },
  'theme.blog.archive.title': {
    en: 'Archive',
    de: 'Archiv',
    fr: 'Archive',
    es: 'Archivo',
    ja: 'アーカイブ',
    ko: '아카이브'
  },
  'theme.blog.archive.description': {
    en: 'Archive',
    de: 'Archiv',
    fr: 'Archive',
    es: 'Archivo',
    ja: 'アーカイブ',
    ko: '아카이브'
  },
  
  // 反馈
  'theme_feedback_docs_issue': {
    en: 'Create issue',
    de: 'Issue erstellen',
    fr: 'Créer une issue',
    es: 'Crear issue',
    ja: 'Issueを作成',
    ko: 'Issue 생성'
  },
  'theme_feedback_success': {
    en: 'Thank you for your feedback!',
    de: 'Danke für Ihr Feedback!',
    fr: 'Merci pour votre retour!',
    es: '¡Gracias por sus comentarios!',
    ja: 'フィードバックありがとうございます！',
    ko: '피드백 주셔서 감사합니다!'
  },
  'theme_feedback_successTitle': {
    en: 'Feedback sent!',
    de: 'Feedback gesendet!',
    fr: 'Feedback envoyé!',
    es: '¡Comentarios enviados!',
    ja: 'フィードバックが送信されました！',
    ko: '피드백이 전송되었습니다!'
  },
  
  // 首页
  'homepage.welcome': {
    en: 'Welcome to Docker Documentation',
    de: 'Willkommen in der Docker-Dokumentation',
    fr: 'Bienvenue dans la Documentation Docker',
    es: 'Bienvenido a la Documentación de Docker',
    ja: 'Dockerドキュメントへようこそ',
    ko: 'Docker 문서에 오신 것을 환영합니다'
  },
  'homepage.getStarted': {
    en: 'Get Started',
    de: 'Loslegen',
    fr: 'Commencer',
    es: 'Empezar',
    ja: '始める',
    ko: '시작하기'
  },
  'homepage.whyDocker': {
    en: 'Why Docker?',
    de: 'Warum Docker?',
    fr: 'Pourquoi Docker?',
    es: '¿Por qué Docker?',
    ja: 'なぜDockerなのか？',
    ko: '왜 Docker인가?'
  },
  'homepage.learnMore': {
    en: 'Learn More',
    de: 'Mehr erfahren',
    fr: 'En savoir plus',
    es: 'Más información',
    ja: '詳細を見る',
    ko: '자세히 보기'
  },
  
  // 教程页面
  'docs.tutorials.introduction.title': {
    en: 'Docker Basic Concepts',
    de: 'Docker Grundkonzepte',
    fr: 'Concepts de base de Docker',
    es: 'Conceptos básicos de Docker',
    ja: 'Docker基本概念',
    ko: 'Docker 기본 개념'
  },
  'docs.tutorials.introduction.description': {
    en: 'Learn the core concepts of Docker including containers, images, and registries.',
    de: 'Lernen Sie die Kernkonzepte von Docker kennen, einschließlich Container, Images und Registries.',
    fr: 'Apprenez les concepts fondamentaux de Docker, y compris les conteneurs, images et registres.',
    es: 'Aprenda los conceptos básicos de Docker, incluidos contenedores, imágenes y registros.',
    ja: 'コンテナ、イメージ、レジストリなど、Dockerの基本概念を学びます。',
    ko: '컨테이너, 이미지, 레지스트리 등 Docker의 기본 개념을 배우세요.'
  },
  
  // 安装页面
  'docs.installation.index.title': {
    en: 'Installation Guide Overview',
    de: 'Installationsanleitung Übersicht',
    fr: 'Vue d\\'ensemble du guide d\\'installation',
    es: 'Visión general de la guía de instalación',
    ja: 'インストールガイドの概要',
    ko: '설치 가이드 개요'
  },
  'docs.installation.index.description': {
    en: 'Complete guide for installing Docker on Linux, Windows, and macOS.',
    de: 'Vollständige Anleitung zur Installation von Docker unter Linux, Windows und macOS.',
    fr: 'Guide complet pour installer Docker sous Linux, Windows et macOS.',
    es: 'Guía completa para instalar Docker en Linux, Windows y macOS.',
    ja: 'Linux、Windows、macOSにDockerをインストールする完全なガイド。',
    ko: 'Linux, Windows, macOS에 Docker를 설치하는 완전한 가이드.'
  },
  
  // 使用页面
  'docs.usage.index.title': {
    en: 'Usage Guide Overview',
    de: 'Verwendungshandbuch Übersicht',
    fr: 'Vue d\\'ensemble du guide d\\'utilisation',
    es: 'Visión general de la guía de uso',
    ja: '使用ガイドの概要',
    ko: '사용 가이드 개요'
  },
  'docs.usage.index.description': {
    en: 'Learn how to use Docker for container management, networking, and storage.',
    de: 'Erfahren Sie, wie Sie Docker für Container-Verwaltung, Netzwerke und Speicher verwenden.',
    fr: 'Apprenez à utiliser Docker pour la gestion des conteneurs, les réseaux et le stockage.',
    es: 'Aprenda a usar Docker para la gestión de contenedores, redes y almacenamiento.',
    ja: 'コンテナ管理、ネットワーク、ストレージについてDockerを使用する方法を学びます。',
    ko: '컨테이너 관리, 네트워크, 스토리지에 Docker를 사용하는 방법을 배우세요.'
  },
  
  // 帮助页面
  'docs.help.index.title': {
    en: 'Help Center',
    de: 'Hilfezentrum',
    fr: 'Centre d\\'aide',
    es: 'Centro de ayuda',
    ja: 'ヘルプセンター',
    ko: '도움말 센터'
  },
  'docs.help.index.description': {
    en: 'Find answers to common questions, troubleshooting guides, and best practices.',
    de: 'Finden Sie Antworten auf häufige Fragen, Anleitungen zur Fehlerbehebung und bewährte Verfahren.',
    fr: 'Trouvez des réponses aux questions fréquentes, guides de dépannage et bonnes pratiques.',
    es: 'Encuentre respuestas a preguntas comunes, guías de solución de problemas y mejores prácticas.',
    ja: '一般的な質問への回答、トラブルシューティングガイド、ベストプラクティスを見つけます。',
    ko: '일반적인 질문에 대한 답변, 문제 해결 가이드, 모범 사례를 찾으세요.'
  }
};

/**
 * 生成指定语言的翻译文件
 * @param {string} lang - 语言代码
 */
function generateTranslationFile(lang) {
  const translations = {};
  
  // 遍历所有翻译键
  Object.keys(translationTemplate).forEach(key => {
    if (translationTemplate[key][lang]) {
      translations[key] = translationTemplate[key][lang];
    }
  });
  
  return translations;
}

/**
 * 生成所有语言的翻译文件
 */
function generateAllTranslationFiles() {
  console.log('Generating translation files for all languages...');
  
  LANGUAGES.forEach(lang => {
    const translationDir = path.join(__dirname, 'i18n', lang, 'docusaurus-theme-classic');
    const filePath = path.join(translationDir, 'translations.json');
    
    // 确保目录存在
    if (!fs.existsSync(translationDir)) {
      fs.mkdirSync(translationDir, { recursive: true });
    }
    
    // 生成翻译文件
    const translations = generateTranslationFile(lang);
    
    // 写入文件
    fs.writeFileSync(filePath, JSON.stringify(translations, null, 2), 'utf8');
    
    console.log(`Generated: ${filePath}`);
  });
  
  console.log('All translation files generated successfully!');
}

/**
 * 显示使用说明
 */
function showUsage() {
  console.log(`
Docker Documentation Translation Generator
=====================================

Usage:
  node generate-translations.js [language]

Arguments:
  language    Optional language code (en, de, fr, es, ja, ko)
              If not specified, generates all languages

Examples:
  node generate-translations.js        # Generate all languages
  node generate-translations.js en      # Generate English only
  node generate-translations.js de      # Generate German only

Supported Languages:
  ${LANGUAGES.map(lang => `- ${lang} (${LANGUAGE_NAMES[lang]})`).join('\\n  ')}
  `);
}

// 主函数
function main() {
  const args = process.argv.slice(2);
  const language = args[0];
  
  if (args.includes('--help') || args.includes('-h')) {
    showUsage();
    process.exit(0);
  }
  
  if (language) {
    if (!LANGUAGES.includes(language)) {
      console.error(`Error: Unknown language '${language}'`);
      console.error(`Supported languages: ${LANGUAGES.join(', ')}`);
      process.exit(1);
    }
    
    // 生成指定语言的翻译文件
    const translationDir = path.join(__dirname, 'i18n', language, 'docusaurus-theme-classic');
    const filePath = path.join(translationDir, 'translations.json');
    
    if (!fs.existsSync(translationDir)) {
      fs.mkdirSync(translationDir, { recursive: true });
    }
    
    const translations = generateTranslationFile(language);
    fs.writeFileSync(filePath, JSON.stringify(translations, null, 2), 'utf8');
    
    console.log(`Generated: ${filePath}`);
    console.log(`Language: ${LANGUAGE_NAMES[language]} (${language})`);
  } else {
    // 生成所有语言
    generateAllTranslationFiles();
  }
}

// 运行主函数
if (require.main === module) {
  main();
}

// 导出函数供其他模块使用
module.exports = {
  generateTranslationFile,
  generateAllTranslationFiles,
  LANGUAGES,
  LANGUAGE_NAMES
};
